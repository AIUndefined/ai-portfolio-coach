#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI 持股教練 — 黑客松 Demo Website"""

import os
import re
import sys
import time
import csv
import json
import random
import io
import tempfile
from datetime import datetime, timedelta
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, jsonify, send_from_directory
)

# Add News_DB path for imports (~ works on both macOS and Linux hosts)
_LOCAL_NEWS_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'news_db')
NEWS_DB_PATH = _LOCAL_NEWS_DB if os.path.exists(_LOCAL_NEWS_DB) else os.path.expanduser('~/code/News_DB/Data')
if os.path.exists(NEWS_DB_PATH):
    sys.path.insert(0, NEWS_DB_PATH)

# AWS Bedrock credentials (bedrock.env)
_BEDROCK_ENV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bedrock.env')
CLAUDE_ENV = None
if os.path.exists(_BEDROCK_ENV_FILE):
    CLAUDE_ENV = dict(os.environ)
    with open(_BEDROCK_ENV_FILE, 'r', encoding='utf-8') as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith('#') and '=' in _line:
                _k, _v = _line.split('=', 1)
                CLAUDE_ENV[_k.strip()] = _v.strip().strip('"')
    print('[app] AWS Bedrock credentials loaded (bedrock.env)', flush=True)

# 認證用環境變數（auth.env：Cognito / Google OAuth，未設定也可運作）
_AUTH_ENV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'auth.env')
if os.path.exists(_AUTH_ENV_FILE):
    with open(_AUTH_ENV_FILE, 'r', encoding='utf-8') as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith('#') and '=' in _line:
                _k, _v = _line.split('=', 1)
                os.environ[_k.strip()] = _v.strip().strip('"')
    print('[app] Auth OAuth settings loaded (auth.env)', flush=True)

BEDROCK_CHAT_MODEL = 'us.anthropic.claude-opus-4-6-v1'
BEDROCK_PARSE_MODEL = 'us.anthropic.claude-sonnet-4-5-20250929-v1:0'
BEDROCK_GLYPH_MODEL = 'us.anthropic.claude-opus-4-6-v1'


def _has_bedrock():
    return bool(CLAUDE_ENV and CLAUDE_ENV.get('AWS_ACCESS_KEY_ID'))


def _bedrock_converse(prompt, model_id='openai.gpt-oss-120b-1:0', max_tokens=4000, timeout=120, images=None, pdf=None):
    """Call the AWS Bedrock Converse API with manual SigV4 signing.

    boto3 is broken on this host's anaconda py3.8 (pyOpenSSL), so the
    request is signed by hand — only needs requests + stdlib.
    images: list of raw PNG/JPEG bytes attached before the text prompt;
    pdf: raw PDF bytes attached as a document block."""
    import base64, hashlib, hmac, requests as req
    from urllib.parse import quote
    env = CLAUDE_ENV or os.environ
    ak = env.get('AWS_ACCESS_KEY_ID')
    sk = env.get('AWS_SECRET_ACCESS_KEY')
    st = env.get('AWS_SESSION_TOKEN', '')
    region = env.get('AWS_REGION') or env.get('AWS_DEFAULT_REGION') or 'us-east-1'
    if not (ak and sk):
        raise RuntimeError('no AWS credentials (bedrock.env)')
    host = f'bedrock-runtime.{region}.amazonaws.com'
    encoded_model = quote(model_id, safe='')
    request_path = f'/model/{encoded_model}/converse'
    canonical_path = f'/model/{quote(encoded_model, safe="")}/converse'
    content = []
    for im in images or []:
        fmt = 'png' if im[:4] == b'\x89PNG' else 'jpeg'
        content.append({'image': {'format': fmt, 'source': {'bytes': base64.b64encode(im).decode('ascii')}}})
    if pdf:
        content.append({'document': {'format': 'pdf', 'name': 'statement', 'source': {'bytes': base64.b64encode(pdf).decode('ascii')}}})
    content.append({'text': prompt})
    body = json.dumps({
        'messages': [{'role': 'user', 'content': content}],
        'inferenceConfig': {'maxTokens': max_tokens},
    }).encode('utf-8')
    now = datetime.utcnow()
    amz_date = now.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = now.strftime('%Y%m%d')
    payload_hash = hashlib.sha256(body).hexdigest()
    to_sign = {'host': host, 'x-amz-date': amz_date}
    if st:
        to_sign['x-amz-security-token'] = st
    signed_headers = ';'.join(sorted(to_sign))
    canonical_headers = ''.join(f'{k}:{to_sign[k]}\n' for k in sorted(to_sign))
    canonical_request = f'POST\n{canonical_path}\n\n{canonical_headers}\n{signed_headers}\n{payload_hash}'
    scope = f'{date_stamp}/{region}/bedrock/aws4_request'
    string_to_sign = ('AWS4-HMAC-SHA256\n' + amz_date + '\n' + scope + '\n'
                      + hashlib.sha256(canonical_request.encode()).hexdigest())

    def _hsign(key, msg):
        return hmac.new(key, msg.encode(), hashlib.sha256).digest()

    k = _hsign(('AWS4' + sk).encode(), date_stamp)
    k = _hsign(k, region)
    k = _hsign(k, 'bedrock')
    k = _hsign(k, 'aws4_request')
    signature = hmac.new(k, string_to_sign.encode(), hashlib.sha256).hexdigest()
    headers = {
        'Authorization': f'AWS4-HMAC-SHA256 Credential={ak}/{scope}, SignedHeaders={signed_headers}, Signature={signature}',
        'X-Amz-Date': amz_date,
        'Content-Type': 'application/json',
    }
    if st:
        headers['X-Amz-Security-Token'] = st
    resp = req.post(f'https://{host}{request_path}', data=body, headers=headers,
                    timeout=timeout)
    if resp.status_code != 200:
        # Surface Bedrock's real error (ValidationException, throttling, ...)
        # instead of a bare HTTPError with no body.
        raise RuntimeError(f'Bedrock {resp.status_code}: {resp.text[:300]}')
    content = resp.json()['output']['message']['content']
    return '\n'.join(b['text'] for b in content if 'text' in b).strip()

app = Flask(__name__)
# Stable key so sessions survive restarts (NOT production-grade)
_KEY_PATH = os.path.join(os.path.dirname(__file__), '.flask_secret')
if os.path.exists(_KEY_PATH):
    with open(_KEY_PATH, 'rb') as _f:
        app.secret_key = _f.read()
else:
    app.secret_key = os.urandom(24)
    with open(_KEY_PATH, 'wb') as _f:
        _f.write(app.secret_key)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

# 認證系統（auth.py：本地帳密 + Cognito PKCE + Google Sign-In）
from auth import init_auth, login_required, current_user
init_auth(app)

# Transaction costs (Taiwan brokerage)
BROKER_FEE_RATE = 0.001425   # 買賣各收一次
SECURITIES_TAX_RATE = 0.003  # 僅賣出收

# Server-side trade storage (avoid 4KB cookie limit)
import uuid as _uuid
_trade_store = {}


def _save_session_data(trades, skipped=None):
    """Store trades server-side; only a tiny UUID goes into the cookie."""
    sid = session.get('_tsid')
    if not sid:
        sid = str(_uuid.uuid4())
        session['_tsid'] = sid
    _trade_store[sid] = {'trades': trades, 'skipped': skipped or []}


def _load_session_trades():
    sid = session.get('_tsid')
    if sid and sid in _trade_store:
        return _trade_store[sid].get('trades', [])
    return session.get('trades', [])  # fallback to old cookie


def _load_session_skipped():
    sid = session.get('_tsid')
    if sid and sid in _trade_store:
        return _trade_store[sid].get('skipped', [])
    return session.get('skipped_sells', [])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SAMPLE_CSV_PATH = os.path.join(os.path.dirname(__file__), 'sample_data', 'sample_statement.csv')

# Stock code → name lookup (cached)
_stock_name_cache = {}


def get_stock_name(code):
    """Look up stock name from code via TWSE/TPEX."""
    if not _stock_name_cache:
        _load_stock_names()
    return _stock_name_cache.get(code, code)


def _load_stock_names():
    """Load all stock names from TWSE + TPEX."""
    import requests
    import pandas as pd
    from io import StringIO
    try:
        # TWSE listed stocks
        resp = requests.get('https://isin.twse.com.tw/isin/C_public.jsp?strMode=2', timeout=10)
        resp.encoding = 'big5'
        tables = pd.read_html(StringIO(resp.text))
        for _, row in tables[0].iterrows():
            cell = str(row[0])
            if '\u3000' in cell:
                parts = cell.split('\u3000')
                if len(parts) == 2 and parts[0].strip().isdigit():
                    _stock_name_cache[parts[0].strip()] = parts[1].strip()
        # TPEX (OTC) stocks
        resp2 = requests.get('https://isin.twse.com.tw/isin/C_public.jsp?strMode=4', timeout=10)
        resp2.encoding = 'big5'
        tables2 = pd.read_html(StringIO(resp2.text))
        for _, row in tables2[0].iterrows():
            cell = str(row[0])
            if '\u3000' in cell:
                parts = cell.split('\u3000')
                if len(parts) == 2 and parts[0].strip().isdigit():
                    _stock_name_cache[parts[0].strip()] = parts[1].strip()
    except Exception:
        pass
    # Fallback common stocks
    fallbacks = {
        '1303': '南亞', '1402': '遠東新', '2303': '聯電', '2330': '台積電',
        '2344': '華邦電', '2379': '瑞昱', '2382': '廣達', '2409': '友達',
        '2454': '聯發科', '3189': '景碩', '3481': '群創', '6770': '力積電',
        '2408': '南亞科', '3231': '緯創', '2881': '富邦金', '2317': '鴻海',
        '2412': '中華電', '00878': '國泰永續高股息', '0050': '元大台灣50',
        '0056': '元大高股息', '2603': '長榮', '3008': '大立光',
    }
    for k, v in fallbacks.items():
        _stock_name_cache.setdefault(k, v)


def parse_csv(file_stream):
    """Parse uploaded CSV into list of trade dicts."""
    text = file_stream.read()
    if isinstance(text, bytes):
        text = text.decode('utf-8-sig')
    reader = csv.DictReader(io.StringIO(text))
    trades = []
    for row in reader:
        trades.append({
            'stock_code': row['stock_code'].strip(),
            'stock_name': row['stock_name'].strip(),
            'buy_date': row['buy_date'].strip(),
            'buy_price': float(row['buy_price']),
            'sell_date': row['sell_date'].strip(),
            'sell_price': float(row['sell_price']),
            'shares': int(row['shares']),
        })
    return trades


VISION_MIME_TYPES = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.webp': 'image/webp',
    '.heic': 'image/heic',
    '.heif': 'image/heic',
    '.pdf': 'application/pdf',
}

# AWS Bedrock Converse API hard limits (exceeding any of these returns
# ValidationException, which used to be silently swallowed downstream).
MAX_VISION_BANDS = 20            # max images per Converse request
MAX_VISION_IMAGE_BYTES = 3_750_000   # max bytes per image
MAX_VISION_EDGE = 8000           # max px on the longest edge
MAX_PDF_BYTES = 4_500_000        # max bytes for a document block


class UploadError(Exception):
    """User-facing upload/recognition error (rendered as HTTP 400)."""


def _boxes_to_grid(boxes, min_conf=0.5):
    """Rebuild table rows from OCR bounding boxes.

    Cluster tokens into rows by y-center, sort each row by x, and join with
    ' | '. This gives the LLM positional column structure instead of a flat
    text blob, so it can align cells to the right fields."""
    boxes = [b for b in boxes if b.get('conf', 0) >= min_conf]
    if not boxes:
        return ''
    heights = sorted(b['y2'] - b['y1'] for b in boxes)
    row_tol = max(8, heights[len(heights) // 2] * 0.6)
    boxes.sort(key=lambda b: (b['y1'] + b['y2']) / 2)
    rows = []
    for b in boxes:
        yc = (b['y1'] + b['y2']) / 2
        if rows and abs(yc - rows[-1][0]) < row_tol:
            rows[-1][1].append(b)
        else:
            rows.append([yc, [b]])
    lines = []
    for _, toks in rows:
        toks.sort(key=lambda b: b['x1'])
        lines.append(' | '.join(t['text'] for t in toks))
    return '\n'.join(lines)


def _ocr_text_quality(text):
    """Fraction of non-space chars that look like real statement content.

    EasyOCR on dense phone screenshots often outputs garbage symbols
    (#, =, [, `, ...). Clean OCR is > 0.95; garbled output is ~0.8."""
    import re
    stripped = re.sub(r'\s', '', text)
    if not stripped:
        return 0.0
    good = re.findall(
        r'[\u4e00-\u9fff0-9A-Za-z.,/%()\-:|·。、，；：（）％＊*]', stripped)
    return len(good) / len(stripped)


def _split_image_bands(file_bytes, band_px=600, overlap=100, scale=2):
    """Split a tall screenshot into overlapping horizontal bands, upscaled 2x.

    Claude vision downscales images to ~1568px on the longest edge, which makes
    dense statement tables illegible and causes hallucinated trades. Feeding
    upscaled bands keeps the text readable. Returns list of temp image paths.

    Enforces Bedrock Converse limits: max 20 images per request, max 3.75MB
    per image, max 8000px on the longest edge."""
    from PIL import Image, ImageOps
    img = Image.open(io.BytesIO(file_bytes))
    img = ImageOps.exif_transpose(img).convert('RGB')  # honor EXIF rotation
    w, h = img.size

    step = band_px - overlap
    n_bands = max(1, -(-(h - overlap) // step))  # ceil division
    if n_bands > MAX_VISION_BANDS:
        raise UploadError(
            f'截圖太長（會切成 {n_bands} 段，上限 {MAX_VISION_BANDS} 段），'
            '請先裁切成多張較短的截圖分次上傳。')

    # Cap the upscale so the widest edge stays within Bedrock's 8000px limit.
    eff_scale = min(scale, MAX_VISION_EDGE / max(w, band_px))
    paths = []
    y = 0
    while y < h:
        band = img.crop((0, y, w, min(y + band_px, h)))
        if eff_scale != 1:
            band = band.resize((max(1, round(band.width * eff_scale)),
                                max(1, round(band.height * eff_scale))),
                               Image.LANCZOS)
        buf = io.BytesIO()
        band.save(buf, format='PNG')
        data, suffix = buf.getvalue(), '.png'
        if len(data) > MAX_VISION_IMAGE_BYTES:
            # PNG too heavy for Bedrock: fall back to progressively lower JPEG.
            for quality in (95, 90, 84, 76, 68):
                buf = io.BytesIO()
                band.save(buf, format='JPEG', quality=quality)
                data, suffix = buf.getvalue(), '.jpg'
                if len(data) <= MAX_VISION_IMAGE_BYTES:
                    break
            else:
                raise UploadError('圖片壓縮後仍超過 3.75MB 上限，請縮小或裁切後重試。')
        tmp = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
        tmp.write(data)
        tmp.close()
        paths.append(tmp.name)
        if y + band_px >= h:
            break
        y += step
    return paths


STATEMENT_STRUCTURE_HINT = (
    '台灣券商對帳單結構說明：\n'
    '1. 「證券庫存」表：每列是一筆目前持股'
    '（庫存股數、平均成交價格、參考市價）。\n'
    '2. 「證券交易明細」表：每列是「單邊」的買進或賣出（看交易別欄，'
    '普買=買進、普賣=賣出）。股數欄是實際股數（零股不要乘以 1000），'
    '單價欄是每股價格，成交金額≈股數×單價。'
)

STATEMENT_ROWS_RULES = (
    '請把每一列忠實轉錄成 JSON，不要配對買賣、不要計算、不要跳列：\n'
    '庫存列 → {"type":"holding","name":"南亞","code":"1303","shares":8,'
    '"avg_cost":151.5,"market_price":166.5}\n'
    '明細列 → {"type":"buy" 或 "sell","date":"2026-06-02","name":"長榮",'
    '"code":"","shares":4,"price":227.0,"amount":908,"net":905}\n'
    '（date=成交日期，民國年+1911 轉西元 YYYY-MM-DD；'
    'price=單價欄；amount=成交金額欄；'
    'net=該列最後的「客戶應收」或「客戶應付」金額，找不到就填 0）\n'
    '交易別的「買/賣」字常被 OCR 認錯，照你的最佳判斷填 type 即可，'
    '正確買賣方向會由 net 金額在程式端重新判定。\n'
    '例外：若表格每列本身就同時有買入與賣出的日期和價格（已配對的格式），'
    '改輸出 {"type":"trade","name":"台積電","code":"2330",'
    '"buy_date":"2026-01-15","buy_price":850,'
    '"sell_date":"2026-03-20","sell_price":920,"shares":1000}\n'
    '注意：name 一律照畫面原文逐字轉錄，即使看起來是 OCR 錯字也絕對不要改'
    '（例如畫面寫 数期科 就輸出 数期科）——'
    '錯字會由程式端比對官方股票清單與原圖修正，你自行「修正」反而會配錯公司。'
    'code 只在畫面上有代碼數字時才填，否則填 ""，絕對不要用名稱猜代碼。\n'
    '只回傳 JSON array，不要其他文字。'
)

HOLDINGS_STRUCTURE_HINT = (
    '這是台灣券商 APP 的「持股明細」或「庫存」畫面截圖。\n'
    '每一列代表一檔目前持有的股票，常見欄位包含：\n'
    '股票名稱（或代碼）、持有股數、平均成本（均價）、'
    '現價（市價/參考價）、未實現損益、報酬率等。\n'
    '不同券商的欄位順序與名稱可能不同，請依據畫面內容判斷。'
)

HOLDINGS_ROWS_RULES = (
    '請把每一列持股忠實轉錄成 JSON，不要計算、不要跳列：\n'
    '{"type":"holding","name":"台積電","code":"2330","shares":1000,'
    '"avg_cost":850.0,"market_price":920.0}\n'
    '欄位說明：\n'
    '- name: 股票名稱，照畫面原文逐字轉錄（即使是 OCR 錯字也不要改）\n'
    '- code: 股票代碼，畫面上有才填，否則填 ""\n'
    '- shares: 持有股數（整數）\n'
    '- avg_cost: 平均成本/均價（每股）\n'
    '- market_price: 現價/市價/參考價（每股），找不到就填 0\n'
    '只回傳 JSON array，不要其他文字。'
)


_s2t_converter = None


def _s2t(text):
    """PaddleOCR often reads traditional chars as simplified lookalikes
    (群創→群创, 國碩→圆硕). Normalize to traditional (Taiwan standard —
    plain s2t gives 羣創 which misses 群創) before matching the official
    stock list."""
    global _s2t_converter
    if _s2t_converter is None:
        try:
            from opencc import OpenCC
            _s2t_converter = OpenCC('s2tw')
        except Exception:
            _s2t_converter = False
    return _s2t_converter.convert(text) if _s2t_converter else text


def _match_key(name):
    """Canonical comparison key for stock names: traditional Taiwan chars,
    臺 folded to 台 (opencc yields 臺建電 but listed names use 台達電)."""
    return _s2t(str(name or '').strip()).replace('臺', '台')


_glyph_bitmap_cache = {}
_glyph_sim_cache = {}
_glyph_font = None


def _glyph_sim(a, b):
    """Visual similarity (pixel Jaccard) of two rendered CJK characters.

    Models what OCR actually confuses: 中國 has ~20 alphabetically-tied
    fuzzy candidates (中砂, 中工, ...) and only glyph shape says the
    misread 国 came from 鋼."""
    if a == b:
        return 1.0
    pair = (a, b) if a < b else (b, a)
    if pair in _glyph_sim_cache:
        return _glyph_sim_cache[pair]
    sim = 0.0
    try:
        from PIL import Image, ImageDraw, ImageFont
        import numpy as np
        global _glyph_font
        if _glyph_font is None:
            for p in ('/System/Library/Fonts/PingFang.ttc',
                      '/System/Library/Fonts/STHeiti Light.ttc',
                      '/System/Library/Fonts/Hiragino Sans GB.ttc',
                      # Linux (Ubuntu fonts-noto-cjk)
                      '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
                      '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc'):
                try:
                    _glyph_font = ImageFont.truetype(p, 32)
                    break
                except Exception:
                    continue
            if _glyph_font is None:
                _glyph_font = False
        if _glyph_font:
            bitmaps = []
            for ch in pair:
                bm = _glyph_bitmap_cache.get(ch)
                if bm is None:
                    im = Image.new('L', (40, 40), 0)
                    ImageDraw.Draw(im).text((4, 2), ch, fill=255,
                                            font=_glyph_font)
                    bm = np.array(im) > 96
                    _glyph_bitmap_cache[ch] = bm
                bitmaps.append(bm)
            union = (bitmaps[0] | bitmaps[1]).sum()
            if union:
                sim = float((bitmaps[0] & bitmaps[1]).sum()) / union
    except Exception:
        pass
    _glyph_sim_cache[pair] = sim
    return sim


def _name_candidates(key, key_to_name, n=8):
    """Rank official stock names as OCR-misread candidates for `key`.

    Plain difflib ratios favor short names (笙科 outranks 敦陽科 for 數期科),
    so score positional overlap — OCR misreads keep string length and
    character positions — using glyph similarity for mismatched positions,
    plus the difflib ratio as tiebreaker."""
    import difflib
    scored = []
    for k, name in key_to_name.items():
        # ETF-style truncations (台50 for 台灣50/富邦台50) fail the
        # positional model — admit containment matches directly.
        if len(key) >= 3 and (key in k or k in key):
            scored.append(
                (-2 - difflib.SequenceMatcher(None, key, k).ratio(), name))
            continue
        if abs(len(k) - len(key)) > 1:
            continue
        pos = sum(a == b for a, b in zip(key, k))
        if pos == 0:
            continue
        vis = sum(1.0 if a == b else _glyph_sim(a, b)
                  for a, b in zip(key, k))
        score = vis / max(len(k), len(key)) \
            + difflib.SequenceMatcher(None, key, k).ratio()
        scored.append((-score, name))
    scored.sort()
    return [name for _, name in scored[:n]]


def _resolve_stock(name, code=''):
    """Resolve a (possibly garbled OCR) stock name / code to canonical
    (code, name) via the official TWSE/TPEX list. Fuzzy-matches the name so
    OCR misreads like 台違電→台達電 still resolve. Returns ('', '') when
    nothing matches — callers should drop such rows instead of guessing."""
    import difflib
    if not _stock_name_cache:
        _load_stock_names()
    code = str(code or '').strip()
    if code in _stock_name_cache:
        return code, _stock_name_cache[code]
    key = _match_key(name)
    if not key:
        return '', ''
    key_to_name = {}
    for c, n in _stock_name_cache.items():
        key_to_name.setdefault(_match_key(n), n)
    name_to_code = {}
    for c, n in _stock_name_cache.items():
        name_to_code.setdefault(n, c)
    if key in key_to_name:
        n = key_to_name[key]
        return name_to_code[n], n
    # Single-char remnants (OCR ate the name) would fuzzy-match randomly
    if len(key) < 2:
        return '', ''
    match = difflib.get_close_matches(key, key_to_name.keys(), n=1, cutoff=0.5)
    if match:
        n = key_to_name[match[0]]
        return name_to_code[n], n
    return '', ''


def _dedupe_rows(rows):
    """Remove duplicate transcribed rows (overlapping image bands)."""
    seen = set()
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        key = json.dumps(r, sort_keys=True, ensure_ascii=False)
        if key not in seen:
            seen.add(key)
            out.append(r)
    return out


def _reocr_name_cell(img, box, ocr_url):
    """Re-OCR just the name cell at 4x. Usually still imperfect, but often
    recovers characters the full-page pass missed (效随科→敦随科 gets the
    敦 right), which puts the true stock into the candidate list."""
    import requests as req
    from PIL import Image
    pad = 4
    crop = img.crop((max(0, int(box['x1']) - pad), max(0, int(box['y1']) - pad),
                     int(box['x2']) + pad, int(box['y2']) + pad))
    crop = crop.resize((crop.width * 4, crop.height * 4), Image.LANCZOS)
    buf = io.BytesIO()
    crop.save(buf, format='PNG')
    try:
        r = req.post(ocr_url, files={'file': ('cell.png', buf.getvalue(),
                                              'image/png')}, timeout=30)
        bs = r.json().get('boxes') or []
        if bs:
            return str(max(bs, key=lambda b: b.get('conf', 0))['text']).strip()
    except Exception:
        pass
    return ''


def _verify_names_with_vision(rows, boxes, file_bytes, ocr_url=None):
    """Second-pass fix for garbled OCR stock names (数期科→敦陽科, 圆硕→國碩).

    The name cells are ~26x12 px: 4x re-OCR alone still misreads them and
    open-ended vision hallucinates plausible stocks (乾燥科/欣銓). What works
    is a multiple-choice question: show the model an upscaled crop of the
    statement row (context: date/price/amount) plus a candidate list built
    from fuzzy matching of both the original and a re-OCR'd alternate
    reading. Rewrites row['name']/row['code'] in place. One extra Claude
    call total, only when uncertain names exist."""
    import re
    if not boxes or not file_bytes:
        return rows
    if not _stock_name_cache:
        _load_stock_names()
    official = {}
    key_to_name = {}
    for c, n in _stock_name_cache.items():
        official.setdefault(n, c)
        key_to_name.setdefault(_match_key(n), n)

    # Names that appear verbatim (post-normalization) somewhere in the
    # statement — used to anchor garbled variants of the same stock.
    exact_names = set()
    for r in rows:
        if isinstance(r, dict):
            k = _match_key(str(r.get('name') or '').strip())
            if k in key_to_name:
                exact_names.add(key_to_name[k])

    # Distinct raw names whose match against the official list is uncertain
    suspect_names = []
    anchored = {}  # raw -> official name, no vision needed
    for r in rows:
        if not isinstance(r, dict):
            continue
        raw = str(r.get('name') or '').strip()
        if len(raw) < 2 or raw in suspect_names or raw in anchored:
            continue
        if str(r.get('code') or '').strip() in _stock_name_cache:
            continue  # row already carries a valid code
        if _match_key(raw) in key_to_name:
            continue
        # If fuzzy matching lands on a stock that also appears cleanly in
        # another row (举航 buy ↔ clean 華航 sell), that's a stronger
        # signal than a vision call, which occasionally picks a lookalike.
        _, resolved = _resolve_stock(raw)
        if resolved and resolved in exact_names:
            anchored[raw] = resolved
            continue
        suspect_names.append(raw)
    for r in rows:
        if isinstance(r, dict):
            raw = str(r.get('name') or '').strip()
            if raw in anchored:
                r['name'] = anchored[raw]
                r['code'] = official[anchored[raw]]
    if not suspect_names:
        return rows

    from PIL import Image
    img = Image.open(io.BytesIO(file_bytes)).convert('RGB')
    suspects = []  # [raw, box, alt_reading, candidates]
    for raw in suspect_names:
        box = None
        for b in boxes:
            t = str(b.get('text', ''))
            if t == raw or raw in t or (len(t) >= 2 and t in raw):
                if box is None or b.get('conf', 0) > box.get('conf', 0):
                    box = b
        if not box:
            continue
        cands = _name_candidates(_match_key(raw), key_to_name, n=8)
        # A second OCR reading of the cell often differs — union both
        # candidate lists so the true name survives one bad reading
        # (效随科 re-reads as 敦随科, whose list contains 敦陽科).
        alt = ''
        if ocr_url:
            alt = _reocr_name_cell(img, box, ocr_url)
            if alt and alt != raw:
                for c in _name_candidates(_match_key(alt), key_to_name, n=8):
                    if c not in cands:
                        cands.append(c)
        suspects.append([raw, box, alt, cands])

    # Two garbled variants of the same stock (效随科/数期科) rate different
    # candidates; pool lists across same-length suspects sharing a
    # positional character so both rows can resolve to the same name.
    for i, (raw_a, _, _, cands_a) in enumerate(suspects):
        key_a = _match_key(raw_a)
        for raw_b, _, _, cands_b in suspects[i + 1:]:
            key_b = _match_key(raw_b)
            if len(key_a) == len(key_b) \
                    and any(a == b for a, b in zip(key_a, key_b)):
                for c in cands_b:
                    if c not in cands_a:
                        cands_a.append(c)
                for c in cands_a:
                    if c not in cands_b:
                        cands_b.append(c)
    suspects = [(raw, box, alt, cands[:12])
                for raw, box, alt, cands in suspects if cands]
    if not suspects:
        return rows

    crops = []  # (raw_name, alt_reading, row_path, cell_path, candidates)
    tmp_paths = []

    def _save(im):
        tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
        im.save(tmp.name)
        tmp_paths.append(tmp.name)
        return tmp.name

    try:
        for raw, box, alt, cands in suspects:
            y1 = max(0, int(box['y1']) - 6)
            y2 = min(img.height, int(box['y2']) + 6)
            # Left portion of the row only: full-width crops get downscaled
            # by the vision pipeline, shrinking the characters back to
            # illegibility. 65% width keeps date/name/price/amount context.
            band = img.crop((0, y1, int(img.width * 0.65), y2))
            # Target ~2300px wide so upscaling survives vision downscaling
            scale = max(1, min(4, 2300 // band.width))
            band = band.resize(
                (band.width * scale, band.height * scale), Image.LANCZOS)
            # Plus an 8x close-up of just the name cell: needed to tell
            # apart single-character lookalikes (台達電 vs 台積電).
            cell = img.crop((max(0, int(box['x1']) - 3),
                             max(0, int(box['y1']) - 3),
                             int(box['x2']) + 3, int(box['y2']) + 3))
            cell = cell.resize((cell.width * 8, cell.height * 8),
                               Image.LANCZOS)
            crops.append((raw, alt, _save(band), _save(cell), cands))

        # Small batches: with 8+ rows (16+ images) in one call the model's
        # per-image attention drops and accuracy collapses; ≤4 rows per
        # call reads reliably. One retry round for suspects the first pass
        # left unanswered/rejected — answers vary run to run.
        fixed = {}
        pending = crops
        for _attempt in range(2):
            for start in range(0, len(pending), 4):
              chunk = pending[start:start + 4]
              lines = [
                  f'{i}. 列全景=第{2 * i + 1}張圖 名稱特寫=第{2 * i + 2}張圖 '
                  f'候選：{json.dumps(cands, ensure_ascii=False)}'
                  for i, (raw, alt, rp, cp, cands) in enumerate(chunk)
              ]
              read_instr = ('請依上面對應閱讀附上的圖片，'
                            '判斷每列「股票名稱」欄位')
              prompt = (
                  f'以下是台灣券商對帳單表格中裁切出來的 {len(chunk)} 個橫列，'
                  '每列有兩張圖：列全景（4倍放大）與股票名稱欄特寫（8倍放大），'
                  '原圖解析度低。\n'
                  '明細列大約是：成交日期 | 交易別 | 股票名稱 | 股數 | 單價 | '
                  '成交金額…；庫存列大約是：代碼 | 股票名稱 | 股數 | 平均成本 | '
                  '市價…。\n'
                  + read_instr
                  + '實際顯示的名稱：\n' + '\n'.join(lines)
                  + '\n\n'
                  '注意：\n'
                  '1. 候選清單來自模糊比對，可能不含正確答案；若候選都不符'
                  '但你能清楚辨識出其他真實台股上市櫃公司簡稱，'
                  '就填你辨識的名稱，不要遷就候選裡「比較像」的名稱。\n'
                  '2. 名稱「字數」必須和圖片裡顯示的字數一致。\n'
                  '3. 逐字比對字形部件再判斷（例如 積=禾+責 左右結構、'
                  '達=⻌部件有底部長捺、鋼=金部、砂=石部）。\n'
                  '4. 不確定就填 ""。\n'
                  '只輸出 JSON，格式 {"0":"名稱","1":"名稱",...}'
                  '（鍵是上面清單的編號）。'
              )
              imgs = []
              for raw, alt, rp, cp, cands in chunk:
                  with open(rp, 'rb') as f:
                      imgs.append(f.read())
                  with open(cp, 'rb') as f:
                      imgs.append(f.read())
              try:
                  out = _bedrock_converse(prompt, model_id=BEDROCK_GLYPH_MODEL,
                                          max_tokens=1000, timeout=180,
                                          images=imgs)
              except Exception:
                  continue
              # The answer JSON is flat; take the last parseable {...} so any
              # braces in the model's reasoning prose are skipped.
              ans = None
              for m in reversed(re.findall(r'\{[^{}]*\}', out)):
                  try:
                      ans = json.loads(m)
                      break
                  except ValueError:
                      continue
              if not isinstance(ans, dict):
                  continue
              for i, (raw, alt, rp, cp, cands) in enumerate(chunk):
                  choice = str(ans.get(str(i), '')).strip()
                  if not choice or choice not in official:
                      continue
                  # Off-list answers allowed only when they plausibly
                  # explain the OCR reading: same length, ≥1 char in the
                  # same position (misreads keep layout, hallucinations
                  # usually don't).
                  ck = _match_key(choice)
                  plaus = any(
                      len(ck) == len(k) and any(a == b
                                                for a, b in zip(ck, k))
                      for k in (_match_key(raw), _match_key(alt)) if k)
                  if choice in cands or plaus:
                      fixed[raw] = choice
            pending = [c for c in pending if c[0] not in fixed]
            if not pending:
                break
        for r in rows:
            if isinstance(r, dict):
                raw = str(r.get('name') or '').strip()
                if raw in fixed:
                    r['name'] = fixed[raw]
                    r['code'] = official[fixed[raw]]
    except Exception:
        pass
    finally:
        for p in tmp_paths:
            try:
                os.unlink(p)
            except OSError:
                pass
    return rows


def _rows_to_trades(rows):
    """Deterministically turn transcribed statement rows into paired trades.

    The LLM only transcribes rows; everything error-prone happens here where
    it can't be hallucinated: code resolution from the official stock list,
    price sanity (單價×股數 must ≈ 成交金額, else derive price from 成交金額),
    and FIFO pairing of single-sided 明細 rows."""
    from collections import defaultdict
    today = datetime.now().strftime('%Y-%m-%d')
    trades = []
    holdings = []
    events = defaultdict(list)  # code -> [(date, side, shares, price)]
    orphan_sells = []  # 明細 sells whose name cell OCR missed entirely
    skipped = []  # sells closing positions opened before the period
    dates = [r.get('date') for r in rows if isinstance(r, dict) and r.get('date')]
    period_start = min(dates) if dates else today

    for r in rows:
        if not isinstance(r, dict):
            continue
        rtype = r.get('type')
        code, name = _resolve_stock(r.get('name'), r.get('code'))
        if not code and rtype not in ('buy', 'sell'):
            continue
        try:
            shares = int(float(r.get('shares') or 0))
        except (TypeError, ValueError):
            continue
        if shares <= 0:
            continue

        if rtype == 'trade':
            try:
                # Missing sell side = still-open position, not a closed
                # trade — flag it so stats/backtest/logs don't treat the
                # fallback sell values as a real exit.
                is_open = not (r.get('sell_date') and r.get('sell_price'))
                trades.append({
                    'stock_code': code, 'stock_name': name,
                    'buy_date': r['buy_date'],
                    'buy_price': float(r['buy_price']),
                    'sell_date': r.get('sell_date') or today,
                    'sell_price': float(r.get('sell_price') or r['buy_price']),
                    'shares': shares,
                    'is_unrealized': is_open,
                })
            except (KeyError, TypeError, ValueError):
                continue
        elif rtype == 'holding':
            try:
                avg_cost = float(r.get('avg_cost') or 0)
                market = float(r.get('market_price') or 0)
            except (TypeError, ValueError):
                continue
            if avg_cost <= 0:
                continue
            holdings.append({'code': code, 'name': name, 'shares': shares,
                             'avg_cost': avg_cost,
                             'market_price': market or avg_cost})
        elif rtype in ('buy', 'sell'):
            try:
                price = float(r.get('price') or 0)
                amount = float(r.get('amount') or 0)
                net = float(r.get('net') or 0)
            except (TypeError, ValueError):
                continue
            # 單價×股數 must ≈ 成交金額; on mismatch the 單價 cell was
            # misread — 成交金額/股數 is the reliable per-share price.
            if amount > 0 and abs(price * shares - amount) > amount * 0.05:
                price = round(amount / shares, 2)
            if price <= 0:
                continue
            # The 買/賣 label is often OCR-garbled (普賣/普寶/晋買...), but
            # money tells the truth: 客戶應付 = 成交金額+費用 (buy),
            # 客戶應收 = 成交金額−費用−稅 (sell).
            side = rtype
            if amount > 0 and net > 0 and net != amount \
                    and abs(net - amount) < amount * 0.1:
                side = 'buy' if net > amount else 'sell'
            if not code:
                # OCR sometimes misses the whole name cell (聯穎/國碩 sell
                # rows). A sell can still be attributed below when exactly
                # one stock has a matching open lot; nameless buys stay
                # dropped — guessing would fabricate a position.
                if side == 'sell':
                    orphan_sells.append(
                        (r.get('date') or period_start, shares, price))
                continue
            events[code].append(
                (r.get('date') or period_start, side, shares, price, name))

    # Attribute nameless sells: a real sell must close an open buy. If
    # exactly one stock's surplus (buys − sells − shares the 庫存 section
    # says are still held) equals the orphan's share count, with a
    # same-size buy before the sell date, the match is unambiguous.
    if orphan_sells:
        held = {h['code']: h['shares'] for h in holdings}
        surplus = {}
        for code, evs in events.items():
            net_sh = sum(s if side == 'buy' else -s
                         for _, side, s, _, _ in evs)
            surplus[code] = net_sh - held.get(code, 0)
        for date, shares, price in sorted(orphan_sells):
            cands = [c for c, evs in events.items()
                     if surplus.get(c) == shares
                     and any(d < date and side == 'buy' and s == shares
                             for d, side, s, _, _ in evs)]
            if len(cands) == 1:
                code = cands[0]
                name = events[code][0][4]
                events[code].append((date, 'sell', shares, price, name))
                surplus[code] -= shares
            else:
                skipped.append({'stock_code': '', 'stock_name': '(無法辨識)',
                                'sell_date': date, 'sell_price': price,
                                'shares': shares})

    # FIFO-pair single-sided rows per stock
    leftover_buys = {}
    for code, evs in events.items():
        evs.sort(key=lambda e: (e[0], 0 if e[1] == 'buy' else 1))
        queue = []  # [date, price, remaining_shares]
        for date, side, shares, price, name in evs:
            if side == 'buy':
                queue.append([date, price, shares])
            else:
                rem = shares
                while rem > 0 and queue:
                    b = queue[0]
                    n_sh = min(b[2], rem)
                    trades.append({
                        'stock_code': code, 'stock_name': name,
                        'buy_date': b[0], 'buy_price': b[1],
                        'sell_date': date, 'sell_price': price,
                        'shares': n_sh,
                    })
                    b[2] -= n_sh
                    rem -= n_sh
                    if b[2] == 0:
                        queue.pop(0)
                # Sells with no in-period buy close a position opened
                # before the statement period — cost basis unknown, so
                # they're excluded from stats but reported for disclosure.
                if rem > 0:
                    skipped.append({'stock_code': code, 'stock_name': name,
                                    'sell_date': date, 'sell_price': price,
                                    'shares': rem})
        leftover_buys[code] = queue

    # Holdings become open trades (sell = today's reference market price);
    # unmatched 明細 buys give the real buy_date when available.
    # Flagged as unrealized so backtest / stats treat them separately.
    for h in holdings:
        rem = leftover_buys.get(h['code'], [])
        trades.append({
            'stock_code': h['code'], 'stock_name': h['name'],
            'buy_date': rem[0][0] if rem else period_start,
            'buy_price': h['avg_cost'],
            'sell_date': today, 'sell_price': h['market_price'],
            'shares': h['shares'],
            'is_unrealized': True,
        })
    skipped.sort(key=lambda s: s['sell_date'])
    return trades, skipped


def _dedupe_trades(trades):
    """Remove duplicates caused by overlapping image bands."""
    seen = set()
    out = []
    for t in trades:
        key = (str(t.get('stock_code')), t.get('buy_date'), t.get('buy_price'),
               t.get('sell_date'), t.get('sell_price'), t.get('shares'))
        if key not in seen:
            seen.add(key)
            out.append(t)
    return out


def parse_with_vision(file_bytes, mime_type, structure_hint=None, rows_rules=None):
    """Parse brokerage statement: try fast OCR+AI first, fallback to Claude vision."""
    import re
    import requests as req

    hint = structure_hint or STATEMENT_STRUCTURE_HINT
    rules = rows_rules or STATEMENT_ROWS_RULES

    trades = []
    skipped = []
    band_paths = []
    try:
        # --- Strategy 1: PaddleOCR (166) bbox grid + Sonnet (~60 sec) ---
        OCR_API_URL = 'http://192.168.10.166:5050/ocr'
        try:
            resp = req.post(
                OCR_API_URL,
                files={'file': ('statement.png', file_bytes, mime_type)},
                timeout=60,
            )
            resp.raise_for_status()
            data = resp.json()
            # Rebuild table structure from bbox coordinates when available
            if data.get('boxes'):
                ocr_text = _boxes_to_grid(data['boxes'])
            else:
                ocr_text = data.get('text', '')

            # Only trust OCR if the text is clean — garbled OCR makes the
            # LLM hallucinate plausible-looking but fake trades.
            if ocr_text.strip() and _ocr_text_quality(ocr_text) >= 0.93:
                prompt = (
                    '以下是券商對帳單的 OCR 辨識結果，已依座標重建為表格：'
                    '每行是一列，欄位以 | 分隔（可能有辨識雜訊或欄位錯位）。\n\n'
                    f'{hint}\n\n'
                    f'{rules}\n\n'
                    f'OCR 表格：\n---\n{ocr_text}\n---'
                )
                out = _bedrock_converse(prompt, model_id=BEDROCK_PARSE_MODEL,
                                        max_tokens=8000, timeout=180)
                json_match = re.search(r'\[[\s\S]*\]', out)
                if json_match:
                    rows = _dedupe_rows(json.loads(json_match.group()))
                    rows = _verify_names_with_vision(
                        rows, data.get('boxes') or [], file_bytes,
                        ocr_url=OCR_API_URL)
                    trades, skipped = _rows_to_trades(rows)
        except Exception as e:
            print(f'[vision] OCR strategy failed, falling back to vision: {e}',
                  flush=True)

        # --- Strategy 2: Claude Vision (if OCR+Sonnet got < 5 trades) ---
        if len(trades) < 5:
            if mime_type == 'application/pdf':
                # PDFs: pass the file directly
                tmp = tempfile.NamedTemporaryFile(suffix='.pdf', delete=False)
                tmp.write(file_bytes)
                tmp.close()
                band_paths = [tmp.name]
            else:
                band_paths = _split_image_bands(file_bytes)

            prompt = (
                '附上的圖片（或 PDF）是同一份券商持股或對帳單截圖'
                '（圖片已切成多個橫段，相鄰段有部分重疊），請依序閱讀，'
                '重疊區域的重複列只轉錄一次。\n\n'
                f'{hint}\n\n'
                f'{rules}'
            )
            try:
                if mime_type == 'application/pdf':
                    out = _bedrock_converse(prompt, model_id=BEDROCK_PARSE_MODEL,
                                            max_tokens=8000, timeout=300,
                                            pdf=file_bytes)
                else:
                    imgs = [open(p, 'rb').read() for p in band_paths]
                    out = _bedrock_converse(prompt, model_id=BEDROCK_PARSE_MODEL,
                                            max_tokens=8000, timeout=300,
                                            images=imgs)
            except Exception as e:
                print(f'[vision] Claude vision strategy failed: {e}', flush=True)
                out = ''
            json_match = re.search(r'\[[\s\S]*\]', out)
            if json_match:
                rows = json.loads(json_match.group())
                trades, skipped = _rows_to_trades(_dedupe_rows(rows))

    finally:
        for p in band_paths:
            try:
                os.unlink(p)
            except OSError:
                pass

    # Post-process safety nets (rows were already validated in _rows_to_trades)
    cleaned = []
    for t in _dedupe_trades(trades):
        # Fix common vision mistake on pre-paired 'trade' rows: sell_price
        # extracted from the 成交金額 column (= price × shares) instead of 單價.
        if t['shares'] > 1 and t['buy_price'] > 0:
            ratio = t['sell_price'] / t['buy_price']
            per_share = t['sell_price'] / t['shares']
            per_ratio = per_share / t['buy_price']
            if (ratio > 3 and 0.5 < per_ratio < 2) or \
               (ratio >= 1.5 and 0.93 < per_ratio < 1.07):
                t['sell_price'] = round(per_share, 2)
        # Degenerate rows (same day, same price) carry zero information.
        # Must run AFTER the correction above, which can create them.
        if t['buy_date'] == t['sell_date'] and t['buy_price'] == t['sell_price']:
            continue
        cleaned.append(t)

    # Drop breakeven rows that duplicate a richer record: unpaired 明細
    # buys get re-emitted as 庫存 with sell_price=buy_price, shadowing the
    # real holdings row (same code/shares/buy_price with a real sell_price).
    non_flat = {(t['stock_code'], t['shares'], t['buy_price'])
                for t in cleaned if t['sell_price'] != t['buy_price']}
    cleaned = [t for t in cleaned
               if t['sell_price'] != t['buy_price']
               or (t['stock_code'], t['shares'], t['buy_price']) not in non_flat]

    return cleaned, skipped


def calc_trade_stats(trades):
    """Calculate per-trade P&L including transaction costs."""
    results = []
    for t in trades:
        buy_amount = t['buy_price'] * t['shares']
        sell_amount = t['sell_price'] * t['shares']
        buy_fee = buy_amount * BROKER_FEE_RATE
        sell_fee = sell_amount * BROKER_FEE_RATE
        sell_tax = sell_amount * SECURITIES_TAX_RATE
        is_unrealized = t.get('is_unrealized', False)
        # Unrealized holdings: no sell-side costs yet
        if is_unrealized:
            friction = buy_fee
        else:
            friction = buy_fee + sell_fee + sell_tax
        pnl_gross = sell_amount - buy_amount
        pnl = pnl_gross - friction
        pnl_pct = pnl / buy_amount * 100 if buy_amount else 0
        buy_dt = datetime.strptime(t['buy_date'], '%Y-%m-%d')
        sell_dt = datetime.strptime(t['sell_date'], '%Y-%m-%d')
        hold_days = (sell_dt - buy_dt).days
        results.append({
            **t,
            'pnl': round(pnl),
            'pnl_pct': round(pnl_pct, 2),
            'pnl_gross': round(pnl_gross),
            'friction': round(friction),
            'hold_days': hold_days,
        })
    return results


def _roc_to_date(roc_str):
    """Convert ROC date '115/07/03' to datetime."""
    parts = roc_str.strip().split('/')
    if len(parts) == 3:
        y = int(parts[0]) + 1911
        return datetime(y, int(parts[1]), int(parts[2]))
    return None


def generate_turning_points(trade):
    """Find real turning points using get_stock_history()."""
    buy_dt = datetime.strptime(trade['buy_date'], '%Y-%m-%d')
    sell_dt = datetime.strptime(trade['sell_date'], '%Y-%m-%d')
    hold_days = max((sell_dt - buy_dt).days, 1)
    buy_price = trade['buy_price']
    sell_price = trade['sell_price']

    # Use existing get_stock_history() — it handles TWSE/TPEX automatically
    prices = []
    try:
        raw = get_stock_history(trade['stock_code'], days=hold_days + 30)
        for p in raw:
            # Normalize date: ROC '115/07/03' → '2026-07-03'
            d = p.get('date', '')
            if '/' in d:
                dt = _roc_to_date(d)
                if dt:
                    d = dt.strftime('%Y-%m-%d')
            if d >= trade['buy_date'] and d <= trade['sell_date']:
                prices.append({
                    'date': d,
                    'close': p.get('close', 0),
                    'high': p.get('high', 0),
                    'low': p.get('low', 0),
                })
    except Exception:
        pass

    if len(prices) >= 3:
        high_pt = max(prices, key=lambda p: p['high'])
        low_pt = min(prices, key=lambda p: p['low'])
        if high_pt['date'] == low_pt['date']:
            remaining = [p for p in prices if p['date'] != high_pt['date']]
            if remaining:
                low_pt = min(remaining, key=lambda p: p['low'])

        points = [
            {'date': trade['buy_date'], 'type': 'buy', 'price': buy_price, 'label': '買入'},
            {'date': high_pt['date'], 'type': 'high', 'price': high_pt['high'], 'label': '最高點'},
            {'date': low_pt['date'], 'type': 'drawdown', 'price': low_pt['low'], 'label': '最大回撤'},
            {'date': trade['sell_date'], 'type': 'sell', 'price': sell_price, 'label': '賣出'},
        ]
        points.sort(key=lambda p: p['date'])
        return points

    # Fallback if no price data at all
    return [
        {'date': trade['buy_date'], 'type': 'buy', 'price': buy_price, 'label': '買入'},
        {'date': trade['sell_date'], 'type': 'sell', 'price': sell_price, 'label': '賣出'},
    ]


_news_cache = {}

_FINANCE_NEWS_KEYWORDS = (
    '股', '盤', '漲', '跌', '營收', '財報', '法說', '外資', '投信', '自營商',
    'EPS', '每股', '盈餘', '獲利', '虧損', '訂單', '出貨', '產能', '毛利',
    '上市', '上櫃', '除息', '除權', '配息', '股利', '目標價', '評等',
    '買超', '賣超', '籌碼', '營運', '業績', '接單', '擴廠', '產線',
    '集團', '投資', '市值', '台股', '證交所', '董事會', '併購', '受惠',
)


# Longer entities that contain a stock's name as a substring — keyword
# news collection can't tell them apart（金寶 pulls in 金寶山 cemetery news）.
_NEWS_NAME_COLLISIONS = {
    '2312': ('金寶山',),
}


def _news_title_relevant(title, stock_code, stock_name=''):
    """News collected by name keyword pulls in unrelated entities that share
    the same characters（金寶 keyword → 金寶山 cemetery/celebrity news）.
    Strip known collision terms first; keep the title only if the company
    is still mentioned (code or name) or it carries a finance word."""
    title = str(title or '')
    if not title:
        return False
    if stock_code and str(stock_code) in title:
        return True
    for bad in _NEWS_NAME_COLLISIONS.get(str(stock_code), ()):
        title = title.replace(bad, '')
    if stock_name:
        if stock_name in title:
            return True
        # Media often truncate 4-char names（大立光電 → 大立光）
        if len(stock_name) >= 4 and stock_name[:3] in title:
            return True
    return any(k in title for k in _FINANCE_NEWS_KEYWORDS)


def _load_all_news_for_stock(stock_code):
    """Load all news for a stock from all available News_DB sources."""
    if stock_code in _news_cache:
        return _news_cache[stock_code]

    news_by_date = {}

    # 1) news_history.csv (has date, title, source, url)
    history_file = os.path.join(NEWS_DATA_DIR, 'news_history.csv')
    if os.path.exists(history_file):
        try:
            with open(history_file, 'r', encoding='utf-8-sig') as f:
                for row in csv.DictReader(f):
                    if row.get('stock_code', '').strip() == str(stock_code) \
                            and _news_title_relevant(row.get('title', ''),
                                                     stock_code,
                                                     row.get('stock_name', '')):
                        d = row.get('date', '').strip()
                        if d not in news_by_date:
                            news_by_date[d] = []
                        news_by_date[d].append({
                            'title': row.get('title', ''),
                            'source': row.get('source', ''),
                            'url': row.get('url', ''),
                        })
        except Exception:
            pass

    # 2) training_data.csv (has text, stock_code, stock_name — no date/url)
    if not news_by_date:
        training_file = os.path.join(NEWS_DATA_DIR, 'training_data.csv')
        if os.path.exists(training_file):
            try:
                with open(training_file, 'r', encoding='utf-8-sig') as f:
                    for row in csv.DictReader(f):
                        if row.get('stock_code', '').strip() == str(stock_code):
                            text = row.get('text', '').strip()
                            if not _news_title_relevant(
                                    text, stock_code,
                                    row.get('stock_name', '')):
                                continue
                            # Use first 80 chars as title
                            title = text[:80] + ('...' if len(text) > 80 else '')
                            d = 'training'
                            if d not in news_by_date:
                                news_by_date[d] = []
                            news_by_date[d].append({
                                'title': title,
                                'source': 'News_DB',
                                'url': '#',
                            })
            except Exception:
                pass

    # 3) Google News RSS：每則 <item> 都有 pubDate，按真實日期（台灣時間）
    #    歸檔後與本地資料合併，讓轉折點可以做「當天」精確比對。
    #    （本地 news_history 覆蓋率極低，故 RSS 永遠補抓，重複標題略過。）
    try:
        import requests as req
        from urllib.parse import quote
        from email.utils import parsedate_to_datetime
        name = get_stock_name(stock_code)
        q = quote(f'{name} {stock_code} 股票')
        url = f'https://news.google.com/rss/search?q={q}&hl=zh-TW&gl=TW&ceid=TW:zh-Hant'
        import re
        r = req.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        seen_titles = {n['title'] for arts in news_by_date.values() for n in arts}
        for item in re.findall(r'<item>(.*?)</item>', r.text, re.S)[:80]:
            tm = re.search(r'<title>(.+?)</title>', item, re.S)
            dm = re.search(r'<pubDate>(.+?)</pubDate>', item, re.S)
            if not tm or not dm:
                continue
            t = tm.group(1).strip()
            if t in seen_titles or not _news_title_relevant(t, stock_code, name):
                continue
            try:
                pub_dt = parsedate_to_datetime(dm.group(1).strip())
                d = (pub_dt + timedelta(hours=8)).strftime('%Y%m%d')  # GMT → 台灣時間
            except (TypeError, ValueError):
                continue
            lm = re.search(r'<link>(.+?)</link>', item, re.S)
            seen_titles.add(t)
            if d not in news_by_date:
                news_by_date[d] = []
            news_by_date[d].append({
                'title': t,
                'source': 'Google News',
                'url': lm.group(1).strip() if lm else '#',
            })
    except Exception:
        pass

    _news_cache[stock_code] = news_by_date
    return news_by_date


def generate_news_for_point(stock_name, stock_code, point_type, date_str, used_titles=None):
    """Find real news on the turning point date (exact day only).

    used_titles: 同一檔股票時間軸內已用過的新聞標題集合，避免重複。
    當天沒有（未用過的）新聞就回傳 None，不借用別天的新聞。
    """
    news_by_date = _load_all_news_for_stock(stock_code)
    if used_titles is None:
        used_titles = set()

    if news_by_date:
        try:
            target_dt = datetime.strptime(date_str, '%Y-%m-%d')
        except ValueError:
            return None
        key = target_dt.strftime('%Y%m%d')
        for n in news_by_date.get(key) or []:
            if n['title'] not in used_titles:
                used_titles.add(n['title'])
                return {
                    'title': n['title'],
                    'date': date_str,
                    'source': n['source'],
                    'url': n.get('url', '#'),
                    'summary': f'（{date_str}，{n["source"]}）{n["title"]}',
                    'real': True,
                }

    # No news on that exact date
    return None


def _stock_sector(code):
    """Rough Taiwan stock sector from code prefix."""
    c = str(code)
    if c.startswith('00'):
        return 'ETF'
    prefix = int(c[:2]) if len(c) >= 2 and c[:2].isdigit() else 0
    if prefix <= 12:
        return '傳產'       # cement, food, plastic, textile, electric
    if prefix <= 14:
        return '金融'       # finance, insurance
    if 23 <= prefix <= 24:
        return '半導體'     # TSMC, MediaTek...
    if 25 <= prefix <= 29:
        return '電子零組件'
    if 30 <= prefix <= 39:
        return 'OTC 電子'
    if 40 <= prefix <= 49:
        return 'OTC 其他'
    if 50 <= prefix <= 59:
        return 'OTC'
    if 60 <= prefix <= 69:
        return '生技'
    return '其他'


def generate_investor_profile(trades_with_stats):
    """Generate radar chart data and text profile from trades."""
    n = len(trades_with_stats)
    if n == 0:
        return {'radar': {}, 'description': '無交易資料'}

    avg_hold = sum(t['hold_days'] for t in trades_with_stats) / n
    codes = set(t['stock_code'] for t in trades_with_stats)

    # --- 1. 集中度: Herfindahl-like, based on position sizes ---
    total_amount = sum(t['buy_price'] * t['shares'] for t in trades_with_stats) or 1
    code_weights = {}
    for t in trades_with_stats:
        amt = t['buy_price'] * t['shares']
        code_weights[t['stock_code']] = code_weights.get(t['stock_code'], 0) + amt
    hhi = sum((w / total_amount) ** 2 for w in code_weights.values())
    # HHI: 1/N (perfectly diversified) to 1.0 (single stock)
    concentration = max(10, min(95, int(hhi * 100)))

    # --- 2. 換手率: trades per month of covered period ---
    all_dates = []
    for t in trades_with_stats:
        try:
            all_dates.append(datetime.strptime(t['buy_date'], '%Y-%m-%d'))
            all_dates.append(datetime.strptime(t['sell_date'], '%Y-%m-%d'))
        except (ValueError, KeyError):
            pass
    if len(all_dates) >= 2:
        span_days = max((max(all_dates) - min(all_dates)).days, 1)
        trades_per_month = n / (span_days / 30)
        turnover = max(10, min(95, int(trades_per_month * 15)))
    else:
        turnover = 50

    # --- 3. 停損紀律: among losers, % that exited before -5% ---
    losers = [t for t in trades_with_stats if t['pnl_pct'] < 0]
    if losers:
        disciplined = sum(1 for t in losers if t['pnl_pct'] > -5)
        discipline_score = max(10, min(95, int(disciplined / len(losers) * 100)))
    else:
        discipline_score = 80  # no losers = good discipline

    # --- 4. 追高頻率: check buy price vs 20-day high before buy ---
    chase_count = 0
    for t in trades_with_stats:
        try:
            raw = get_stock_history(t['stock_code'], days=30)
            pre_bars = []
            for p in raw:
                d = p.get('date', '')
                if '/' in d:
                    dt = _roc_to_date(d)
                    if dt:
                        d = dt.strftime('%Y-%m-%d')
                if d < t['buy_date']:
                    pre_bars.append(float(p.get('high') or 0))
            if pre_bars:
                recent_high = max(pre_bars[-20:]) if len(pre_bars) >= 20 else max(pre_bars)
                if recent_high > 0 and t['buy_price'] >= recent_high * 0.97:
                    chase_count += 1
        except Exception:
            pass
    chase_pct = max(5, min(95, int(chase_count / max(n, 1) * 100)))

    # --- 5. 產業分散度: count distinct sectors ---
    sectors = set(_stock_sector(c) for c in codes)
    n_sectors = len(sectors)
    if n_sectors >= 5:
        diversity = 90
    elif n_sectors >= 3:
        diversity = 65
    elif n_sectors >= 2:
        diversity = 40
    else:
        diversity = 15

    radar = {
        'labels': ['集中度', '換手率', '停損紀律', '追高頻率', '產業分散度'],
        'values': [concentration, turnover, discipline_score, chase_pct, diversity],
    }

    # Generate text description
    if avg_hold < 15:
        hold_desc = '短線交易者，偏好快進快出'
    elif avg_hold < 60:
        hold_desc = '波段操作者，持股週期適中'
    else:
        hold_desc = '中長線投資者，耐心持有'

    win_count = sum(1 for t in trades_with_stats if t['pnl'] > 0)
    win_rate = win_count / n * 100

    total_friction = sum(t.get('friction', 0) for t in trades_with_stats)

    description = (
        f'你是一位{hold_desc}。\n'
        f'平均持股 {avg_hold:.0f} 天，勝率 {win_rate:.0f}%。\n'
        f'交易摩擦成本合計 ${total_friction:,.0f}（手續費＋證交稅）。\n'
    )
    if concentration > 60:
        description += '持股集中度偏高，建議適度分散風險。\n'
    if chase_pct > 40:
        description += '追高頻率較高，買入價常接近近期高點。\n'
    if discipline_score < 40:
        description += '停損紀律不足，虧損交易常超過 -5% 才出場。\n'
    if turnover > 70:
        description += '交易頻率偏高，注意手續費對報酬的侵蝕。\n'
    if win_rate >= 60:
        description += '整體勝率不錯，但仍需注意虧損交易的控制。'
    else:
        description += '勝率有提升空間，建議加強進場時機的判斷。'

    return {'radar': radar, 'description': description}


_BARS_FETCH_CACHE = {}


def _fetch_history_bars(stock_code, days):
    """Fetch real daily OHLCV bars (ISO dates, oldest→newest), unfiltered.

    news_db 的 get_stock_history 寫死只抓最近 2 個月，EREM v3 等
    長週期指標暖機不夠；這裡直接按月抓 TWSE（上市）/ TPEX（上櫃）
    的月成交資訊，端點與 news_db 相同。"""
    import requests
    months = max(2, min(days // 30 + 1, 12))
    cache_key = (stock_code, months)
    if cache_key in _BARS_FETCH_CACHE:
        return _BARS_FETCH_CACHE[cache_key]

    def _f(x):
        try:
            return float(str(x).replace(',', ''))
        except (ValueError, TypeError):
            return 0.0

    headers = {'User-Agent': 'Mozilla/5.0'}
    today = datetime.now().date()
    raw = {}
    listed = None
    for off in range(months):
        y, m = today.year, today.month - off
        while m <= 0:
            m += 12
            y -= 1
        got = False
        if listed is not False:
            try:
                url = (f'https://www.twse.com.tw/exchangeReport/STOCK_DAY'
                       f'?response=json&date={y}{m:02d}01&stockNo={stock_code}')
                data = requests.get(url, headers=headers, timeout=10).json()
                rows = data.get('data') if data.get('stat') == 'OK' else None
                if rows:
                    listed = True
                    got = True
                    for r in rows:
                        if len(r) >= 7:
                            raw[r[0]] = (r[3], r[4], r[5], r[6], _f(r[1]))
            except Exception:
                pass
        if not got and listed is not True:
            try:
                url = (f'https://www.tpex.org.tw/www/zh-tw/afterTrading/'
                       f'tradingStock?code={stock_code}&date={y}/{m:02d}/01')
                data = requests.get(url, headers=headers, timeout=10).json()
                tables = data.get('tables') or [{}]
                rows = (tables[0].get('data') or []) if data.get('stat') == 'ok' else []
                if rows:
                    listed = False
                    for r in rows:
                        if len(r) >= 7:
                            raw[r[0]] = (r[3], r[4], r[5], r[6],
                                         _f(r[1]) * 1000)
            except Exception:
                pass
        time.sleep(0.15)
    bars = []
    for d, (o, h, lo, c, v) in raw.items():
        iso = d
        if '/' in iso:
            dt = _roc_to_date(iso)
            if dt:
                iso = dt.strftime('%Y-%m-%d')
        b = {'date': iso, 'open': _f(o), 'high': _f(h),
             'low': _f(lo), 'close': _f(c), 'volume': _f(v)}
        if b['close'] > 0:
            bars.append(b)
    bars.sort(key=lambda b: b['date'])
    _BARS_FETCH_CACHE[cache_key] = bars
    return bars


def _render_kline_png(bars, buy_idx, buy_price, sell_idx=None, sell_price=None,
                      user_sell_idx=None, user_sell_price=None):
    """Render a small candlestick chart (red up / green down, MA5/MA10,
    buy marker, optional AI/user sell markers) to PNG bytes."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    fig, ax = plt.subplots(figsize=(7, 3.2), dpi=110)
    for i, b in enumerate(bars):
        up = b['close'] >= b['open']
        color = '#d33' if up else '#1a9850'
        ax.vlines(i, b['low'], b['high'], color=color, linewidth=1)
        body_low = min(b['open'], b['close'])
        body_h = max(abs(b['close'] - b['open']),
                     (b['high'] - b['low']) * 0.02 + 1e-09)
        ax.add_patch(Rectangle((i - 0.32, body_low), 0.64, body_h,
                               facecolor=color, edgecolor=color))
    closes = [b['close'] for b in bars]
    for period, style, col in ((5, '-', '#ff9900'), (10, '--', '#3366cc')):
        if len(closes) >= period:
            xs = list(range(period - 1, len(closes)))
            ma = [sum(closes[j - period + 1:j + 1]) / period for j in xs]
            ax.plot(xs, ma, style, color=col, linewidth=1.2, label=f'MA{period}')
    ax.axhline(buy_price, color='#555', linewidth=0.8, linestyle=':')
    if 0 <= buy_idx < len(bars):
        ax.plot([buy_idx], [buy_price], marker='^', color='#06c', markersize=9)
        ax.annotate('BUY', (buy_idx, buy_price), ha='center', fontsize=8,
                    color='#06c', xytext=(0, -14), textcoords='offset points')
    if sell_idx is not None and 0 <= sell_idx < len(bars):
        sp = sell_price if sell_price else bars[sell_idx]['close']
        ax.plot([sell_idx], [sp], marker='v', color='#9400d3', markersize=9)
        ax.annotate('AI SELL', (sell_idx, sp), ha='center', fontsize=8,
                    color='#9400d3', xytext=(0, 8), textcoords='offset points')
    if user_sell_idx is not None and 0 <= user_sell_idx < len(bars):
        up_ = user_sell_price if user_sell_price else bars[user_sell_idx]['close']
        ax.plot([user_sell_idx], [up_], marker='v', color='#222', markersize=9)
        ax.annotate('MY SELL', (user_sell_idx, up_), ha='center',
                    fontsize=8, color='#222', xytext=(0, 20),
                    textcoords='offset points')
    ax.set_xlim(-1, len(bars))
    ax.set_xticks([])
    ax.tick_params(labelsize=7)
    if ax.get_legend_handles_labels()[0]:
        ax.legend(loc='upper left', fontsize=7)
    fig.tight_layout(pad=0.5)
    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    plt.close(fig)
    return buf.getvalue()


def _trade_price_mismatch(trade, hold):
    """對帳單價格與市場日 K 對不上（OCR 錯價/認錯股票）就判定不匹配，
    否則買賣點標記會浮在 K 棒外的半空中。
    規則：買價需落在買進日 K 棒高低區間、賣價需落在賣出日區間
    （±3% 容忍）；該日無 bar 時退回「中間 bar 收盤 vs 價格差 >50%」粗檢。"""
    by = {b['date']: b for b in hold}
    for d, p in ((trade['buy_date'], trade['buy_price']),
                 (trade['sell_date'], trade['sell_price'])):
        if not p or p <= 0:
            continue
        b = by.get(d)
        if b and b['low'] > 0:
            if not (b['low'] * 0.97 <= p <= b['high'] * 1.03):
                return True
        else:
            ref = hold[len(hold) // 2]['close']
            if ref > 0 and abs(ref / p - 1) > 0.5:
                return True
    return False


_KLINE_EXIT_CACHE = {}


def _claude_kline_exit(trade, hist):
    """Claude replays the holding period on K-line chart snapshots.

    One Bedrock call per trade: image i shows the chart as of holding
    day i's close (20-bar lookback + bars so far). Claude decides the
    first day it would exit; 0 = hold to the user's actual sell.
    """
    key = (trade['stock_code'], trade['buy_date'], trade['sell_date'],
           trade['buy_price'])
    if key in _KLINE_EXIT_CACHE:
        return _KLINE_EXIT_CACHE[key]
    fallback = {'price': trade['sell_price'], 'date': trade['sell_date'],
                'reason': '無歷史資料，沿用實際賣出價'}
    hold = [b for b in hist
            if trade['buy_date'] <= b['date'] <= trade['sell_date']
            and b['close'] > 0]
    if not hold:
        return fallback
    if not _has_bedrock():
        fallback['reason'] = '無 Bedrock API，沿用實際賣出價'
        return fallback
    if _trade_price_mismatch(trade, hold):
        fallback['reason'] = '價格資料不匹配，沿用實際賣出價'
        return fallback
    lookback = [b for b in hist if b['date'] < trade['buy_date']][-20:]
    days = hold[:10]
    imgs = [_render_kline_png(lookback + hold[:i + 1], len(lookback),
                              trade['buy_price'])
            for i in range(len(days))]
    prompt = (
        f'你是嚴謹的台股技術分析交易員。附上 {len(imgs)} 張同一檔股票'
        f'（{trade.get("stock_name", trade["stock_code"])}）的日 K 線圖：'
        '紅棒漲、綠棒跌，橘實線 MA5、藍虛線 MA10，藍色▲與灰色虛水平線是買進點'
        f'（買進價 {trade["buy_price"]}）。\n'
        '第 i 張圖 = 持有第 i 天收盤後看到的線圖（每張比前一張多一根 K 棒）。\n'
        '請依時間順序模擬：從第 1 張開始逐日判斷，若當天收盤後的型態'
        '（跌破 MA5、長黑爆量、乖離過大、漲多轉弱等技術訊號）讓你決定出場，'
        '就以那天收盤價出場並停止；不可利用後面圖片的資訊回頭修改前面的決定。\n'
        '若全部看完仍值得續抱就填 0。\n'
        '只輸出 JSON：{"exit_day": 1~N 或 0, "reason": "20字內理由"}'
    )
    try:
        out = _bedrock_converse(prompt, model_id=BEDROCK_PARSE_MODEL,
                                max_tokens=500, timeout=180, images=imgs)
        ans = None
        for m in reversed(re.findall(r'\{[^{}]*\}', out)):
            try:
                ans = json.loads(m)
                break
            except ValueError:
                continue
        n = int(ans.get('exit_day', 0)) if isinstance(ans, dict) else 0
        reason = str((ans or {}).get('reason', '')).strip()
        if 1 <= n <= len(days):
            sell_i, sell_p = n - 1, days[n - 1]['close']
            res = {'price': sell_p,
                   'date': days[n - 1]['date'],
                   'reason': f'Claude 第{n}天出場：{reason}' if reason
                             else f'Claude 第{n}天出場'}
        else:
            sell_i, sell_p = len(hold) - 1, trade['sell_price']
            res = {'price': trade['sell_price'],
                   'date': trade['sell_date'],
                   'reason': f'Claude 續抱到底：{reason}' if reason
                             else 'Claude 續抱至原賣出日'}
        import base64
        png = _render_kline_png(lookback + hold, len(lookback),
                                trade['buy_price'],
                                sell_idx=len(lookback) + sell_i,
                                sell_price=sell_p,
                                user_sell_idx=len(lookback) + len(hold) - 1,
                                user_sell_price=trade['sell_price'])
        res['chart'] = 'data:image/png;base64,' + base64.b64encode(png).decode('ascii')
    except Exception as e:
        print(f'[kline] claude exit failed: {e}', flush=True)
        fallback['reason'] = 'API 失敗，沿用實際賣出價'
        res = fallback
    _KLINE_EXIT_CACHE[key] = res
    return res


_EREM_SERIES_CACHE = {}


def _erem_v3_series(stock_code, hist):
    """移植同事 TWse-stock-crawler 的 EREM v3 / LES v3 / ATR14 逐日分數
    （expected_return_exit_v3.py + low_entry_score_v3.py 的數學）。
    無 TAIEX 資料 → 相對強弱 0 分（與原策略缺欄位時行為一致）。
    回傳 {'raw': [...], 'les': [...], 'atr': [...]}；raw 不含進場品質分
    （該 ≤5 分依各筆交易的進場日 LES 另外加上）。"""
    key = (stock_code, len(hist), hist[0]['date'], hist[-1]['date'])
    if key in _EREM_SERIES_CACHE:
        return _EREM_SERIES_CACHE[key]
    import numpy as np, pandas as pd
    high = pd.Series([b['high'] for b in hist], dtype='float64')
    low = pd.Series([b['low'] for b in hist], dtype='float64')
    close = pd.Series([b['close'] for b in hist], dtype='float64')
    volume = pd.Series([b['volume'] for b in hist], dtype='float64').fillna(0)
    eps = 1e-09
    ema20 = close.ewm(span=20, adjust=False, min_periods=1).mean()
    ema50 = close.ewm(span=50, adjust=False, min_periods=1).mean()
    ema200 = close.ewm(span=200, adjust=False, min_periods=1).mean()
    ema_align = (ema20 > ema50) & (ema50 > ema200)
    above20 = close > ema20
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = (-delta).clip(lower=0)
    avg_gain = gain.rolling(14, min_periods=1).mean()
    avg_loss = loss.rolling(14, min_periods=1).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = (100 - 100 / (1 + rs)).where(avg_loss != 0, np.where(avg_gain > 0, 100, 50)).fillna(50)
    ema12 = close.ewm(span=12, adjust=False, min_periods=1).mean()
    ema26 = close.ewm(span=26, adjust=False, min_periods=1).mean()
    macd = ema12 - ema26
    macd_sig = macd.ewm(span=9, adjust=False, min_periods=1).mean()
    macd_hist = macd - macd_sig
    hist_rising = macd_hist > macd_hist.shift(1)
    falling2d = macd_hist.diff().lt(0).rolling(2, min_periods=2).sum().eq(2)
    prev_price_high = high.shift(1).rolling(20, min_periods=2).max()
    prev_hist_high = macd_hist.shift(1).rolling(20, min_periods=2).max()
    higher_high_px = high > prev_price_high
    bear_div = higher_high_px & (macd_hist < prev_hist_high)
    exhaustion = falling2d | bear_div
    tr = pd.concat([high - low, (high - close.shift(1)).abs(),
                    (low - close.shift(1)).abs()],
                   axis=1).max(axis=1)
    atr14 = tr.rolling(14, min_periods=1).mean()
    atr20ma = atr14.rolling(20, min_periods=1).mean()
    mid = close.rolling(20, min_periods=1).mean()
    std20 = close.rolling(20, min_periods=2).std(ddof=0)
    upper = mid + 2 * std20
    lower = mid - 2 * std20
    vol_ma20 = volume.rolling(20, min_periods=1).mean()
    direction = np.select([close > close.shift(1), close < close.shift(1)],
                          [1, -1], default=0)
    obv = (pd.Series(direction, index=close.index) * volume).cumsum()
    obv_rising = obv > obv.shift(1)
    price_rising = close > close.shift(1)
    price_falling = close < close.shift(1)
    vol_above = volume > vol_ma20
    t_strength = (volume / vol_ma20).where(vol_ma20.abs() > eps)
    obv_fall5 = obv.diff().lt(0).rolling(5, min_periods=5).sum().eq(5)
    obv_div = higher_high_px & (obv < obv.shift(1).rolling(20, min_periods=2).max())
    dist_warn = vol_above & price_falling | (t_strength >= 1.2) & price_falling | obv_fall5 | obv_div
    hi120 = high.rolling(120, min_periods=1).max()
    lo120 = low.rolling(120, min_periods=1).min()
    mean120 = close.rolling(120, min_periods=1).mean()
    std120 = close.rolling(120, min_periods=2).std(ddof=0)
    ub120 = mean120 + 2 * std120
    rr = ((hi120 - close) / (close - lo120)).where(close - lo120 > eps)
    cur_sh = high.rolling(20, min_periods=20).max()
    prev_sh = high.shift(20).rolling(20, min_periods=20).max()
    cur_sl = low.rolling(20, min_periods=20).min()
    prev_sl = low.shift(20).rolling(20, min_periods=20).min()
    pv = (close * volume).rolling(60, min_periods=1).sum()
    vv = volume.rolling(60, min_periods=1).sum()
    vwap60 = (pv / vv).where(vv > eps)
    trend = np.where(ema_align, 12, 0) + np.where(above20, 8, 0)
    momentum = np.clip(np.where((rsi >= 45) & (rsi <= 70), 5, 0) + np.where(macd > macd_sig, 5, 0) + np.where(hist_rising, 5, 0) - np.where(exhaustion, 5, 0), 0, 15)
    volat = np.clip(np.where(atr14 <= atr20ma, 5, 0) + np.where(upper.notna() & (close < upper), 5, 0) - np.where(atr14 > atr20ma * 1.2, 5, 0) - np.where(upper.notna() & (close >= upper) & exhaustion, 5, 0), 0, 10)
    distrib = np.clip(np.where(obv_rising, 5, 0) + np.where(vol_above & price_rising, 5, 0) + np.where(~dist_warn, 5, 0), 0, 15)
    remain = np.clip(np.select([rr > 2, (rr >= 1) & (rr <= 2)], [10, 5], default=0) + np.where(ub120.notna() & (close < ub120), 5, 0), 0, 15)
    structure = np.where((cur_sh > prev_sh) & (cur_sl > prev_sl), 5, 0)
    turnover_sc = np.where((t_strength >= 1.2) & (close >= close.shift(1)), 5, 0)
    vwap_sc = np.where(vwap60.notna() & (close < vwap60), 5, 0)
    raw_wo_eq = trend + momentum + volat + distrib + remain + structure + turnover_sc + vwap_sc
    band_pos = ((close - lower) / (upper - lower)).where((upper - lower).abs() > eps)
    low5 = low.rolling(5, min_periods=1).min()
    les = np.clip(np.where(ema_align, 15, 0) + np.where(above20, 10, 0) + np.select([(rsi > 40) & (rsi < 60), rsi < 40], [10, 5], default=0) + np.where(macd > macd_sig, 10, 0) + np.where(lower.notna() & (band_pos <= 0.2), 10, 0) + np.where(atr14 < atr20ma, 10, 0) + np.where(vol_above, 10, 0) + np.where(obv_rising, 10, 0) + np.where(low >= low.shift(1).rolling(20, min_periods=1).min(), 10, 0) + np.where(low5 > low5.shift(5), 5, 0), 0, 100)
    out = {'raw': [float(x) for x in raw_wo_eq],
           'les': [float(x) for x in les],
           'atr': [float(x) if x == x else 0.0 for x in atr14]}
    _EREM_SERIES_CACHE[key] = out
    return out


_DEALER_EXIT_CACHE = {}


def _ai_dealer_exit(trade, hist):
    """同事 BestDeal（bestdeal_trader.py）真實出場機制：
    1) 禁當沖：買進當天不出場
    2) v3 ATR 風控（每日盤前以前一日資料更新）：
       停利 = 前收 + 3×ATR14、停損 = 前收 − 2×ATR14，停利先於停損檢查；
       無 ATR 資料時 fallback 買價 -4% 硬停損
    3) EREM v3 訊號（收盤判斷，每日最多一次）：
       持有信心 HC = 0.6×當日 EREM 分數 + 0.4×進場日 LES 分數；
       HC<40 全部出場、40–54 減碼 25%、≥55 續抱
    未觸發則期末以使用者實際賣價強平剩餘部位（回傳加權平均出場價）。"""
    key = (trade['stock_code'], trade['buy_date'], trade['sell_date'],
           trade['buy_price'])
    if key in _DEALER_EXIT_CACHE:
        return _DEALER_EXIT_CACHE[key]
    fallback = {'price': trade['sell_price'], 'date': trade['sell_date'],
                'reason': '無歷史資料，沿用實際賣出價'}
    hold = [b for b in hist
            if trade['buy_date'] <= b['date'] <= trade['sell_date']
            and b['close'] > 0]
    if not hold:
        return fallback
    buy_price = trade['buy_price']
    if _trade_price_mismatch(trade, hold):
        fallback['reason'] = '價格資料不匹配，沿用實際賣出價'
        return fallback
    try:
        s = _erem_v3_series(trade['stock_code'], hist)
    except Exception as e:
        print(f'[dealer] erem series failed: {e}', flush=True)
        fallback['reason'] = 'AI Dealer：指標計算失敗，沿用實際賣出價'
        _DEALER_EXIT_CACHE[key] = fallback
        return fallback
    hold_start = hist.index(hold[0])
    entry_les = s['les'][hold_start]
    eq = 5 if entry_les >= 75 else (3 if entry_les >= 60 else 0)
    remaining = 1.0
    fills = []
    for j in range(1, len(hold)):
        b = hold[j]
        gi = hold_start + j
        prev_close = hist[gi - 1]['close']
        atr = s['atr'][gi - 1]
        if atr > 0:
            v3_target = prev_close + 3 * atr
            v3_stop = prev_close - 2 * atr
        else:
            v3_target = None
            v3_stop = buy_price * 0.96
        if v3_target and b['high'] >= v3_target:
            p = b['open'] if b['open'] >= v3_target else v3_target
            fills.append((remaining, p, b['date'], j,
                          f'v3 停利（{v3_target:.1f}）'))
            remaining = 0.0
            break
        if b['low'] <= v3_stop:
            p = b['open'] if 0 < b['open'] <= v3_stop else v3_stop
            tag = f'v3 停損（{v3_stop:.1f}）' if atr > 0 else '硬停損 -4%'
            fills.append((remaining, p, b['date'], j, tag))
            remaining = 0.0
            break
        erem = min(max(s['raw'][gi] + eq, 0.0), 105.0) * 100.0 / 105.0
        hc = 0.6 * erem + 0.4 * entry_les
        if hc < 40:
            fills.append((remaining, b['close'], b['date'], j,
                          f'EREM EXIT（HC {hc:.0f}）'))
            remaining = 0.0
            break
        if hc < 55:
            q = remaining * 0.25
            remaining -= q
            fills.append((q, b['close'], b['date'], j,
                          f'減碼25%（HC {hc:.0f}）'))
    if remaining > 1e-09:
        fills.append((remaining, trade['sell_price'], trade['sell_date'],
                      len(hold) - 1, '期末強平'))
    eff_price = sum(q * p for q, p, _, _, _ in fills)
    sell_i, sell_p = fills[-1][3], fills[-1][1]
    parts = ' → '.join(f'D{f[3]} {f[4]}' for f in fills)
    res = {'price': round(eff_price, 2),
           'date': fills[-1][2],
           'reason': f'AI Dealer：{parts}'}
    try:
        import base64
        lookback = [x for x in hist if x['date'] < trade['buy_date']][-20:]
        png = _render_kline_png(lookback + hold, len(lookback), buy_price,
                                sell_idx=len(lookback) + sell_i,
                                sell_price=sell_p,
                                user_sell_idx=len(lookback) + len(hold) - 1,
                                user_sell_price=trade['sell_price'])
        res['chart'] = 'data:image/png;base64,' + base64.b64encode(png).decode('ascii')
    except Exception:
        pass
    _DEALER_EXIT_CACHE[key] = res
    return res


def _simulate_persona_exit(trade, persona, bars):
    """Replay daily bars to find when a persona would exit.

    Returns {'price': float, 'date': str, 'reason': str}.
    """
    buy_price = trade['buy_price']
    sl_price = buy_price * (1 + persona['stop_loss'] / 100)
    tp_pct = persona.get('take_profit')
    tp_price = buy_price * (1 + tp_pct / 100) if tp_pct else None
    ma_period = persona.get('ma_period')

    if not bars:
        return {'price': trade['sell_price'], 'date': trade['sell_date'],
                'reason': '無歷史資料，沿用實際賣出價'}

    # Sanity check: bar prices must be in the same ballpark as the trade
    # (sample data may use fictional prices far from real market).
    mid_bar = bars[len(bars) // 2]
    ref = mid_bar['close'] if mid_bar['close'] > 0 else mid_bar['open']
    if ref > 0 and abs(ref / buy_price - 1) > 0.5:
        return {'price': trade['sell_price'], 'date': trade['sell_date'],
                'reason': '價格資料不匹配，沿用實際賣出價'}

    closes = []
    for bar in bars:
        o, h, lo, c = bar['open'], bar['high'], bar['low'], bar['close']
        if o <= 0 or h <= 0 or lo <= 0 or c <= 0:
            closes.append(c if c > 0 else buy_price)
            continue

        # Gap-down open below stop-loss
        if o <= sl_price:
            return {'price': o, 'date': bar['date'], 'reason': '跳空停損'}

        # Gap-up open above take-profit
        if tp_price and o >= tp_price:
            return {'price': o, 'date': bar['date'], 'reason': '跳空停利'}

        # Intra-day: both could trigger — use conservative order
        # (check stop-loss first on bearish day, take-profit first on bullish)
        if c < o:  # bearish day
            if lo <= sl_price:
                return {'price': sl_price, 'date': bar['date'], 'reason': '停損'}
            if tp_price and h >= tp_price:
                return {'price': tp_price, 'date': bar['date'], 'reason': '停利'}
        else:  # bullish day
            if tp_price and h >= tp_price:
                return {'price': tp_price, 'date': bar['date'], 'reason': '停利'}
            if lo <= sl_price:
                return {'price': sl_price, 'date': bar['date'], 'reason': '停損'}

        closes.append(c)

        # MA-cross exit for 波段型
        if ma_period and len(closes) >= ma_period:
            ma = sum(closes[-ma_period:]) / ma_period
            if c < ma and c < buy_price:
                return {'price': c, 'date': bar['date'],
                        'reason': f'跌破{ma_period}日均線'}

    # Never triggered — hold to user's actual sell date/price
    return {'price': trade['sell_price'], 'date': trade['sell_date'],
            'reason': '持有至原賣出日'}


def _calc_ai_pnl(buy_price, exit_price, shares, is_unrealized=False):
    """Compute net P&L for an AI exit, including friction."""
    buy_amount = buy_price * shares
    sell_amount = exit_price * shares
    buy_fee = buy_amount * BROKER_FEE_RATE
    sell_fee = sell_amount * BROKER_FEE_RATE
    sell_tax = sell_amount * SECURITIES_TAX_RATE
    friction = buy_fee if is_unrealized else (buy_fee + sell_fee + sell_tax)
    return round(sell_amount - buy_amount - friction)


def run_parallel_universe_backtest(trades_with_stats):
    """Simulate 4 AI personas using real daily price bar-by-bar replay."""
    personas = [
        {
            'name': 'Claude 看盤型 AI',
            'icon': '🧠',
            'description': 'Claude 逐日看 K 線技術圖（K 棒 + MA5/MA10），'
                           '自行判斷哪天出場。',
            'kline': True,
        },
        {
            'name': 'AI Dealer',
            'icon': '💼',
            'description': 'BestDeal 真實出場機制：禁當沖、每日 ATR 風控'
                           '（停利 = 前收 +3×ATR14、停損 = 前收 −2×ATR14）、'
                           'EREM v3 持有信心 <40 全出／40–54 減碼 25%，'
                           '否則期末強平。',
            'dealer': True,
        },
    ]

    # Exclude unrealized holdings from backtest
    realized = [t for t in trades_with_stats if not t.get('is_unrealized')]
    if not realized:
        realized = trades_with_stats

    # Pre-fetch full daily history per stock (enough warm-up for EREM v3)
    _hist_cache = {}
    today = datetime.now().date()
    for t in realized:
        key = t['stock_code']
        try:
            bd = datetime.strptime(t['buy_date'], '%Y-%m-%d').date()
            span = (today - bd).days + 300
        except (ValueError, TypeError):
            span = t.get('hold_days', 60) + 300
        _hist_cache[key] = max(_hist_cache.get(key, 0), span)
    for key in list(_hist_cache):
        _hist_cache[key] = _fetch_history_bars(key, _hist_cache[key])

    user_total_pnl = sum(t['pnl'] for t in realized)
    results = []

    for persona in personas:
        ai_total_pnl = 0
        ai_trades = []
        for t in realized:
            hist = _hist_cache.get(t['stock_code'], [])
            if persona.get('kline'):
                exit_info = _claude_kline_exit(t, hist)
            elif persona.get('dealer'):
                exit_info = _ai_dealer_exit(t, hist)
            else:
                trade_bars = [b for b in hist
                              if b['date'] >= t['buy_date'] and b['date'] <= t['sell_date']]
                exit_info = _simulate_persona_exit(t, persona, trade_bars)
            ai_pnl = _calc_ai_pnl(t['buy_price'], exit_info['price'], t['shares'])
            ai_exit_pct = ((exit_info['price'] - t['buy_price'])
                           / t['buy_price'] * 100) if t['buy_price'] else 0
            ai_total_pnl += ai_pnl
            ai_trades.append({
                'stock_name': t['stock_name'],
                'stock_code': t['stock_code'],
                'pnl': ai_pnl,
                'pnl_pct': round(ai_exit_pct, 2),
                'exit_reason': exit_info['reason'],
                'exit_date': exit_info['date'],
                'chart': exit_info.get('chart'),
            })

        diff = ai_total_pnl - user_total_pnl
        results.append({
            **persona,
            'total_pnl': round(ai_total_pnl),
            'diff': round(diff),
            'diff_pct': round(diff / max(abs(user_total_pnl), 1) * 100, 1),
            'trades': ai_trades,
        })

    # Generate cumulative P&L curves for chart
    chart_data = {'labels': [t['stock_name'] for t in realized]}
    user_cum = []
    cum = 0
    for t in realized:
        cum += t['pnl']
        user_cum.append(round(cum))
    chart_data['user'] = user_cum

    for r in results:
        ai_cum = []
        cum = 0
        for at in r['trades']:
            cum += at['pnl']
            ai_cum.append(round(cum))
        chart_data[r['name']] = ai_cum

    best = max(results, key=lambda x: x['total_pnl'])

    return {
        'user_total_pnl': round(user_total_pnl),
        'personas': results,
        'chart_data': chart_data,
        'best': {
            'name': best['name'],
            'diff': best['diff'],
            'diff_pct': best['diff_pct'],
        },
    }


# ---------------------------------------------------------------------------
# Try to import News_DB modules (graceful fallback)
# ---------------------------------------------------------------------------

try:
    from directional_particle_model import get_stock_history
    from directional_particle_model import get_institutional_data as _raw_inst
    HAS_STOCK_HISTORY = True

    # Cache institutional data (refreshes every 30 min, avoids hammering TWSE)
    _inst_cache = {'data': None, 'ts': 0}

    def get_institutional_data():
        now = datetime.now().timestamp()
        if _inst_cache['data'] is None or now - _inst_cache['ts'] > 1800:
            _inst_cache['data'] = _raw_inst()
            _inst_cache['ts'] = now
        return _inst_cache['data']

except ImportError:
    HAS_STOCK_HISTORY = False
    get_institutional_data = None

    def get_stock_history(stock_code, days=20):
        """Fallback: generate simulated price data."""
        base_price = {'2330': 900, '2454': 1200, '2881': 78, '0050': 150, '2603': 170}.get(stock_code, 100)
        data = []
        today = datetime.now()
        for i in range(days, 0, -1):
            dt = today - timedelta(days=i)
            noise = random.uniform(-0.03, 0.03) * base_price
            close = base_price + noise
            data.append({
                'date': dt.strftime('%Y-%m-%d'),
                'open': round(close - random.uniform(-5, 5), 1),
                'high': round(close + random.uniform(0, 10), 1),
                'low': round(close - random.uniform(0, 10), 1),
                'close': round(close, 1),
                'volume': random.randint(5000, 50000),
            })
            base_price = close
        return data

try:
    from hybrid_predictor import hybrid_predict, analyze_news
    HAS_HYBRID = True
except ImportError:
    HAS_HYBRID = False

NEWS_DATA_DIR = os.path.join(NEWS_DB_PATH, 'news_data')


def load_news_from_csv(stock_code, limit=20):
    """Load historical news for a stock from News_DB CSV files."""
    news = []
    history_file = os.path.join(NEWS_DATA_DIR, 'news_history.csv')
    if os.path.exists(history_file):
        try:
            with open(history_file, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row.get('stock_code', '').strip() == str(stock_code) \
                            and _news_title_relevant(row.get('title', ''),
                                                     stock_code,
                                                     row.get('stock_name', '')):
                        news.append({
                            'date': row.get('date', ''),
                            'title': row.get('title', ''),
                            'source': row.get('source', ''),
                            'url': row.get('url', ''),
                        })
        except Exception:
            pass

    if not news:
        # Fallback: generate sample news
        stock_names = {'2330': '台積電', '2454': '聯發科', '2881': '富邦金', '0050': '元大台灣50', '2603': '長榮'}
        name = stock_names.get(stock_code, f'股票{stock_code}')
        sample_titles = [
            f'{name}法說會釋正向訊號，外資連三日買超',
            f'{name}本季營收優於預期，分析師上調目標價',
            f'{name}受惠 AI 需求，訂單能見度提升',
            f'外資報告看好{name}長線布局價值',
            f'{name}股價突破月線壓力，技術面轉強',
        ]
        for i, title in enumerate(sample_titles):
            d = (datetime.now() - timedelta(days=i * 3)).strftime('%Y%m%d')
            news.append({'date': d, 'title': title, 'source': 'Demo', 'url': '#'})

    return news[:limit]


UPLOAD_LOG_DIR = os.path.join(os.path.dirname(__file__), 'upload_logs')
os.makedirs(UPLOAD_LOG_DIR, exist_ok=True)


def log_upload(filename, file_bytes, trades, source='upload'):
    """Save uploaded file + parsed trades to upload_logs/."""
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    prefix = f'{ts}_{source}'

    # Save original file
    ext = os.path.splitext(filename)[1] if filename else '.bin'
    raw_path = os.path.join(UPLOAD_LOG_DIR, f'{prefix}_raw{ext}')
    with open(raw_path, 'wb') as f:
        f.write(file_bytes if isinstance(file_bytes, bytes) else file_bytes.encode('utf-8'))

    # Save parsed trades as JSON
    json_path = os.path.join(UPLOAD_LOG_DIR, f'{prefix}_trades.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump({
            'timestamp': ts,
            'source': source,
            'original_file': filename,
            'trade_count': len(trades),
            'trades': trades,
        }, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/features')
def features_page():
    return render_template('features.html')


@app.route('/login')
def login_page():
    if current_user():
        return redirect(url_for('index'))
    return render_template('login.html')


@app.route('/upload', methods=['POST'])
@login_required
def upload():
    """Legacy form submit — redirect to index (use /api/upload instead)."""
    return redirect(url_for('index'))


@app.route('/api/upload', methods=['POST'])
@login_required
def api_upload():
    """AJAX upload: accepts CSV, PDF, or image. Returns JSON."""
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'error': '請選擇檔案'}), 400

    f = request.files['file']
    filename = f.filename.lower()
    ext = os.path.splitext(filename)[1]

    try:
        file_bytes = f.read()
        skipped = []

        # Convert HEIC to JPEG (Pillow doesn't support HEIC natively)
        if ext in ('.heic', '.heif'):
            from PIL import Image
            try:
                import pillow_heif
                pillow_heif.register_heif_opener()
            except ImportError:
                pass
            try:
                img = Image.open(io.BytesIO(file_bytes)).convert('RGB')
                buf = io.BytesIO()
                img.save(buf, format='JPEG', quality=95)
                file_bytes = buf.getvalue()
                ext = '.jpg'
            except Exception:
                return jsonify({'error': 'HEIC 格式無法解析，請先轉成 JPG 或 PNG 再上傳。'}), 400

        mode = request.form.get('mode', 'statement')

        if ext == '.csv':
            trades = parse_csv(io.BytesIO(file_bytes))
        elif ext in VISION_MIME_TYPES:
            mime_type = VISION_MIME_TYPES[ext]
            if mime_type == 'application/pdf' and len(file_bytes) > MAX_PDF_BYTES:
                return jsonify({'error': 'PDF 超過 4.5MB 上限（Bedrock 文件限制），'
                                         '請壓縮或改上傳截圖。'}), 400
            if mode == 'holdings':
                trades, skipped = parse_with_vision(
                    file_bytes, mime_type,
                    structure_hint=HOLDINGS_STRUCTURE_HINT,
                    rows_rules=HOLDINGS_ROWS_RULES)
            else:
                trades, skipped = parse_with_vision(file_bytes, mime_type)
        else:
            return jsonify({'error': f'不支援的檔案格式：{ext}'}), 400

        if not trades:
            err_msg = ('AI 無法從檔案中辨識出持股資料，請確認截圖包含持股明細。'
                       if mode == 'holdings'
                       else 'AI 無法從檔案中辨識出交易資料，請確認檔案內容。')
            return jsonify({'error': err_msg}), 400

        log_upload(f.filename, file_bytes, trades, source='upload')
        trades_with_stats = calc_trade_stats(trades)
        _save_session_data(trades_with_stats, skipped)
        return jsonify({'ok': True, 'count': len(trades), 'redirect': url_for('analysis')})
    except UploadError as e:
        return jsonify({'error': str(e)}), 400
    except json.JSONDecodeError:
        return jsonify({'error': 'AI 回傳的資料格式異常，請重試或換一張更清晰的圖片。'}), 400
    except Exception as e:
        return jsonify({'error': f'辨識失敗：{str(e)}'}), 500


@app.route('/api/sample')
@login_required
def api_sample():
    with open(SAMPLE_CSV_PATH, 'rb') as f:
        file_bytes = f.read()
    trades = parse_csv(io.BytesIO(file_bytes))
    log_upload('sample_statement.csv', file_bytes, trades, source='sample_csv')
    trades_with_stats = calc_trade_stats(trades)
    _save_session_data(trades_with_stats)
    return jsonify({'ok': True, 'redirect': url_for('analysis')})


SAMPLE_IMG_PATH = os.path.join(os.path.dirname(__file__), 'sample_data', 'sample_statement.png')


@app.route('/api/sample_photo', methods=['POST'])
@login_required
def api_sample_photo():
    """Upload the sample statement image through vision pipeline."""
    with open(SAMPLE_IMG_PATH, 'rb') as f:
        file_bytes = f.read()
    try:
        trades, skipped = parse_with_vision(file_bytes, 'image/png')
        log_upload('sample_statement.png', file_bytes, trades, source='sample_photo')
        trades_with_stats = calc_trade_stats(trades)
        _save_session_data(trades_with_stats, skipped)
        return jsonify({'ok': True, 'count': len(trades), 'redirect': url_for('analysis')})
    except Exception as e:
        return jsonify({'error': f'辨識失敗：{str(e)}'}), 500


@app.route('/analysis')
@login_required
def analysis():
    trades = _load_session_trades()
    if not trades:
        return redirect(url_for('index'))

    # Generate turning points + news for each trade
    for t in trades:
        t['turning_points'] = generate_turning_points(t)
        used_titles = set()  # 同一檔股票的時間軸內不重複同一篇新聞
        for pt in t['turning_points']:
            pt['news'] = generate_news_for_point(t['stock_name'], t['stock_code'],
                                                 pt['type'], pt['date'], used_titles)

    profile = generate_investor_profile(trades)
    return render_template('analysis.html', trades=trades, profile=profile,
                           skipped_sells=_load_session_skipped())


@app.route('/api/news/<stock_code>')
@login_required
def api_news(stock_code):
    news = load_news_from_csv(stock_code)
    return jsonify(news)


@app.route('/api/stock_history/<stock_code>')
@login_required
def api_stock_history(stock_code):
    try:
        days = int(request.args.get('days', 60))
    except ValueError:
        days = 60
    data = get_stock_history(stock_code, days=days)
    return jsonify(data)


@app.route('/api/backtest', methods=['POST'])
@login_required
def api_backtest():
    trades = _load_session_trades()
    if not trades:
        return jsonify({'error': 'No trades in session'}), 400
    result = run_parallel_universe_backtest(trades)
    return jsonify(result)


@app.route('/api/profile', methods=['POST'])
@login_required
def api_profile():
    trades = _load_session_trades()
    if not trades:
        return jsonify({'error': 'No trades in session'}), 400
    profile = generate_investor_profile(trades)
    return jsonify(profile)


@app.route('/chat/<stock_code>')
@login_required
def chat(stock_code):
    trades = _load_session_trades()
    trade = next((t for t in trades if t['stock_code'] == stock_code), None)
    stock_names = {'2330': '台積電', '2454': '聯發科', '2881': '富邦金', '0050': '元大台灣50', '2603': '長榮'}
    stock_name = trade['stock_name'] if trade else stock_names.get(stock_code, stock_code)
    return render_template('chat.html', stock_code=stock_code, stock_name=stock_name, trade=trade)


# 投顧老師話術庫：讓 AI 教練講話有第四台投顧節目的味道（demo 娛樂效果）。
GURU_PHRASES = '''一、造勢煽動類（拉抬情緒）
老師帶你上車／這檔準備噴出／漲停鎖死，買不到了／起漲點就在今天／錯過這波，再等十年／財富重分配的機會來了／現在不買，以後買不起／十年一遇的大行情／台股上看三萬點／主升段要來了／末升段噴出行情／別人恐懼我貪婪／空手的請追進／手腳要快，慢了就沒了／行情總在絕望中誕生
二、技術分析包裝類（聽起來很專業）
均線多頭排列／黃金交叉，買點浮現／帶量突破前高／量價齊揚／底部量縮打底完成／W底成型／頭肩底頸線突破／杯柄型態，教科書等級／假跌破、真上漲／洗盤結束，準備發動／均線糾結後選擇向上／沿五日線強勢上攻／站上季線，多頭確立／拉回就是買點／逢低承接，分批佈局／型態漂亮，箭在弦上／短線滿足點還沒到／缺口不補，行情不止／紅K吞噬，反轉訊號／強者恆強
三、籌碼故事類（暗示有內線感）
主力已經進場卡位／主力吃貨完畢／主力洗盤，甩轎中／散戶都被洗出去了／外資悄悄回補／投信認養股／千張大戶持股連三週增加／籌碼沉澱得很漂亮／董監改選行情／集團年底作帳行情／隱形冠軍，市場還沒發現／內資主力鎖碼／這檔有人在照顧／大戶進、散戶出，你說會怎樣？／籌碼會說話
四、會員招募類（商業核心）
加入會員，飆股報你知／會員專屬名單／這支老師只講給會員聽／現在打電話進來，0800——／名額有限，額滿為止／免費體驗一個月／這支上禮拜就發給會員了／會員已經賺一根停板／老師的關門弟子班／千線萬線，不如一條電話線
五、事後諸葛類（收割信任）
老師早就說過了／你看，是不是跟老師講的一模一樣／上次叫你買，你不買／有跟到的請扣1／老師什麼時候騙過你／這根漲停，老師昨天就畫給你看了／不是老師神，是方法對／會過的股票才會過／會漲的股票，怎麼壓都壓不下來／盤面自己會說話
六、罵散戶類（建立權威）
老師在講，你有沒有在聽！／你們就是不聽話才賠錢／散戶就是愛追高殺低／韭菜就是這樣被割的／抱不住就不要怪老師／賺錢要有方法，不是用猜的／拿筆記下來！／重點來了，眼睛看好／你不理財，財不理你／輸家想休息，贏家看時機
七、避責免死金牌類（法務指定）
投資一定有風險／買賣自負，老師只是分享／停損停利要自己設好／紀律比預測重要／過去績效不代表未來獲利／老師講的是「觀察」，不是「報明牌」／這不是投資建議
八、目標價畫餅類
目標價上看翻倍／保守估兩根停板／波段起漲點，空間先看三成／落後補漲，輪動到它了／這檔有飆股基因／本夢比比本益比重要／妖股不講基本面
九、節目經典氛圍類
進廣告前先講一支／電話線全開，小姐等你／各位觀眾朋友，見證奇蹟的時刻／無腦多，空軍投降／多頭總司令回來了／咬住！抱緊處理！'''


@app.route('/api/chat', methods=['POST'])
@login_required
def api_chat():
    data = request.get_json()
    message = data.get('message', '')
    stock_code = data.get('stock_code', '')
    stock_name = data.get('stock_name', '')
    trade = data.get('trade', {})

    # --- Build news + turning points context ---
    news_context = ''
    # 1) Turning points from session (already computed in /analysis)
    session_trades = _load_session_trades()
    session_trade = next((t for t in session_trades if t.get('stock_code') == stock_code), None)
    if session_trade and session_trade.get('turning_points'):
        pts = session_trade['turning_points']
        lines = []
        for pt in pts:
            line = f'  {pt["date"]} {pt["label"]} ${pt["price"]}'
            if pt.get('news') and pt['news'].get('title'):
                line += f'  — 新聞：{pt["news"]["title"]}'
                if pt['news'].get('source'):
                    line += f'（{pt["news"]["source"]}）'
            lines.append(line)
        news_context += '持股期間關鍵轉折點：\n' + '\n'.join(lines) + '\n'

    # 2) Additional news from all sources
    all_news = _load_all_news_for_stock(stock_code)
    if all_news:
        headlines = []
        for date_key in sorted(all_news.keys(), reverse=True):
            for article in all_news[date_key][:3]:
                label = date_key if date_key.isdigit() and len(date_key) == 8 else ''
                if label:
                    label = f'{label[:4]}-{label[4:6]}-{label[6:]}'
                headlines.append(f'  {label} {article["title"]}（{article.get("source", "")}）')
                if len(headlines) >= 15:
                    break
            if len(headlines) >= 15:
                break
        if headlines:
            news_context += '\n近期相關新聞：\n' + '\n'.join(headlines) + '\n'

    # 3) 三大法人買賣超 (institutional investor data)
    if get_institutional_data:
        try:
            inst = get_institutional_data()
            si = inst.get(stock_code)
            if si:
                news_context += (
                    f'\n最近一個交易日三大法人買賣超（{stock_name}）：\n'
                    f'  外資：{"買超" if si["foreign"] > 0 else "賣超"}'
                    f' {abs(si["foreign"]):,} 張\n'
                    f'  投信：{"買超" if si["investment"] > 0 else "賣超"}'
                    f' {abs(si["investment"]):,} 張\n'
                    f'  自營商：{"買超" if si["dealer"] > 0 else "賣超"}'
                    f' {abs(si["dealer"]):,} 張\n'
                    f'  合計：{"買超" if si["total"] > 0 else "賣超"}'
                    f' {abs(si["total"]):,} 張\n'
                )
        except Exception:
            pass

    # 4) Recent price data (last 5 trading days)
    try:
        recent = get_stock_history(stock_code, days=10)
        if recent:
            price_lines = []
            for p in recent[-5:]:
                d = p.get('date', '')
                if '/' in d:
                    dt = _roc_to_date(d)
                    if dt:
                        d = dt.strftime('%Y-%m-%d')
                chg = ''
                if p.get('close') and p.get('open'):
                    pct = (p['close'] - p['open']) / p['open'] * 100
                    chg = f' ({"+" if pct > 0 else ""}{pct:.1f}%)'
                price_lines.append(
                    f'  {d} 開{p.get("open",0):.1f} 高{p.get("high",0):.1f}'
                    f' 低{p.get("low",0):.1f} 收{p.get("close",0):.1f}{chg}'
                    f' 量{p.get("volume",0):,}')
            if price_lines:
                news_context += (
                    f'\n近 5 個交易日行情（{stock_name}）：\n'
                    + '\n'.join(price_lines) + '\n'
                )
    except Exception:
        pass

    # Try Claude CLI
    try:
        system_context = (
            f'你是「AI 持股教練」，人設是台灣第四台投顧節目的資深老師，'
            f'專門分析台灣股市。'
            f'用戶正在詢問關於 {stock_name}（{stock_code}）的問題。\n\n'
            f'以下是你的招牌話術庫，回答時從中挑「最貼合當下情境」的 2~4 句'
            f'自然穿插進去（不要一次塞太多、不要照抄整段），'
            f'讓語氣有投顧老師的臨場感：\n{GURU_PHRASES}\n\n'
            f'話術規則：\n'
            f'1. 依情境選類別：用戶獲利→可用「事後諸葛類」邀功；'
            f'虧損→用「罵散戶類」或「技術分析包裝類」點出問題（罵完要給建設性建議）；'
            f'問後市→用「技術分析包裝類」「籌碼故事類」增加專業感。\n'
            f'2. 分析內容本身必須誠實、根據實際數據，話術只是「表達風格」，'
            f'不可為了話術扭曲事實或慫恿用戶重押。\n'
            f'3. 每次回答結尾一定帶一句「避責免死金牌類」的免責話術。'
        )
        if news_context:
            system_context += (
                f'\n\n以下是系統自動收集的真實新聞與轉折點資料，'
                f'回答時請引用具體新聞標題和日期來佐證你的分析，'
                f'讓用戶感覺你真的有在追蹤這檔股票：\n{news_context}'
            )
        if trade:
            system_context += (
                f'\n用戶的交易紀錄：買入日 {trade.get("buy_date")}、買入價 {trade.get("buy_price")}、'
                f'賣出日 {trade.get("sell_date")}、賣出價 {trade.get("sell_price")}、'
                f'損益 {trade.get("pnl_pct", "N/A")}%。'
                f'\n請根據這些資訊給予具體的分析和建議。用繁體中文回答，語氣專業但親切。'
            )

        full_prompt = f'{system_context}\n\n用戶問題：{message}'

        reply = _bedrock_converse(full_prompt, model_id=BEDROCK_CHAT_MODEL)

        if not reply:
            raise RuntimeError('empty reply from model')
    except Exception as e:
        # Fallback: scripted responses
        print(f'[chat] bedrock failed, scripted fallback: {e}', flush=True)
        reply = generate_fallback_chat(message, stock_name, stock_code, trade)

    return jsonify({'reply': reply})


def generate_fallback_chat(message, stock_name, stock_code, trade):
    """Generate a contextual response without API."""
    if trade:
        pnl_pct = trade.get('pnl_pct', 0)
        if pnl_pct > 0:
            pnl_comment = f'你在 {stock_name} 的交易獲利 {pnl_pct}%，表現不錯！'
        else:
            pnl_comment = f'你在 {stock_name} 的交易虧損 {abs(pnl_pct)}%，讓我們來分析原因。'
    else:
        pnl_comment = f'讓我來分析 {stock_name} 的近況。'

    if '為什麼' in message or '原因' in message:
        return (
            f'{pnl_comment}\n\n'
            f'根據分析，{stock_name}（{stock_code}）在你的持股期間受到以下因素影響：\n\n'
            f'1. **外資動向**：外資在此期間的買賣超對股價產生顯著影響\n'
            f'2. **產業趨勢**：整體產業景氣變化影響公司基本面\n'
            f'3. **技術面**：股價在關鍵均線附近出現支撐或壓力\n\n'
            f'建議你下次操作時，可以多關注這些指標來輔助決策。'
        )
    elif '建議' in message or '怎麼' in message or '應該' in message:
        return (
            f'{pnl_comment}\n\n'
            f'針對 {stock_name} 的操作建議：\n\n'
            f'1. **進場時機**：建議在股價回測季線支撐且外資轉買時布局\n'
            f'2. **停損設定**：建議設定 -3% 至 -5% 的停損點\n'
            f'3. **停利策略**：可考慮分批出場，先賣一半鎖定利潤\n'
            f'4. **持有週期**：根據你的交易風格，建議持有 20-40 天的波段操作\n\n'
            f'記住：紀律是投資獲利的關鍵！'
        )
    else:
        return (
            f'{pnl_comment}\n\n'
            f'{stock_name}（{stock_code}）是台股中備受關注的標的。'
            f'根據近期的新聞與技術面分析，這檔股票目前的市場情緒偏向中性。\n\n'
            f'你可以問我更具體的問題，例如：\n'
            f'- 「我這筆交易為什麼會虧損？」\n'
            f'- 「下次應該怎麼操作比較好？」\n'
            f'- 「目前的技術面如何？」'
        )


# ---------------------------------------------------------------------------

if __name__ == '__main__':
    print('[app] code version: 2026-07-12 filter-v2', flush=True)
    app.run(debug=True, host='0.0.0.0', port=8080, use_reloader=False)
