# AI 持股教練 — 完整技術規格書

> **版本**：2026-07-15 ai-dealer-v2.3（§10.5 全面改版：AI 人格改為「Claude 看盤型 AI」vs「AI Dealer（BestDeal 真實出場機制）」、K 線圖渲染與買賣點標記、EREM v3 / LES v3 指標移植、TWSE/TPEX 按月歷史抓取；v2.1 新增 §10.5.3b 買賣價 vs 當日 K 棒區間嚴格檢查；v2.2 新增 §12.5 BestDeal 實單頁 `static/bestdeal.html` 與回測區「⚡ 實單」按鈕；v2.3 新增 Claude 實單頁 `static/claude.html`，回測區改為兩顆實單按鈕並標明人格）
> **用途**：本文件為完整軟體重建規格書，AI 可直接從此文件生成完整可運行的應用程式。
> **Hackathon**：CMoney 黑客松 Demo

---

## 目錄

1. [專案概述](#1-專案概述)
2. [目錄結構](#2-目錄結構)
3. [技術棧與相依套件](#3-技術棧與相依套件)
4. [啟動方式與環境設定](#4-啟動方式與環境設定)
5. [後端路由總覽](#5-後端路由總覽)
6. [核心模組：檔案上傳與 OCR 辨識管線](#6-核心模組檔案上傳與-ocr-辨識管線)
7. [核心模組：交易配對引擎 `_rows_to_trades`](#7-核心模組交易配對引擎-_rows_to_trades)
8. [核心模組：股票名稱模糊比對與字形相似度](#8-核心模組股票名稱模糊比對與字形相似度)
9. [核心模組：Vision 多輪驗證 `_verify_names_with_vision`](#9-核心模組vision-多輪驗證-_verify_names_with_vision)
10. [分析引擎：轉折點、新聞、投資風格、平行宇宙回測](#10-分析引擎轉折點新聞投資風格平行宇宙回測)
11. [AI 對話教練（投顧老師人設）](#11-ai-對話教練投顧老師人設)
12. [前端模板與頁面規格](#12-前端模板與頁面規格)
13. [CSS 設計系統](#13-css-設計系統)
14. [錯誤處理與 Fallback 策略](#14-錯誤處理與-fallback-策略)
15. [上傳日誌系統](#15-上傳日誌系統)
16. [附錄 A：Prompt 完整內容](#附錄-aprompt-完整內容)
17. [附錄 B：投顧老師金句話術庫 GURU_PHRASES](#附錄-b投顧老師金句話術庫-guru_phrases)
18. [附錄 C：範例資料](#附錄-c範例資料)
19. [附錄 D：CSS 變數與完整樣式表](#附錄-dcss-變數與完整樣式表)

---

## 1. 專案概述

**AI 持股教練** 是一個全端 Flask Web 應用程式，核心功能：

1. **對帳單/持股截圖 → 結構化交易資料**：使用者上傳券商對帳單截圖（或 CSV），系統透過雙管線 OCR + Claude Vision 辨識，自動解析為結構化的買賣交易紀錄。
2. **關鍵轉折點新聞**：找出持股期間最高點、最低點，自動關聯真實新聞事件。
3. **投資風格雷達圖**：分析集中度、換手率、持有天數、追高頻率、產業分散度。
4. **平行宇宙回測**：兩個 AI 用真實日 K 重播操作同一批持股並 PK——「Claude 看盤型 AI」逐日看渲染出的 K 線技術圖（K 棒 + MA5/MA10）自行判斷出場；「AI Dealer」採用 BestDeal 真實出場機制（禁當沖 + 每日 ATR14 風控 + EREM v3 持有信心訊號）。每筆交易附 K 線圖並標記 BUY / AI SELL / MY SELL。
5. **AI 對話教練**：以台灣第四台投顧老師人設，針對個別交易進行即時 AI 對話分析。

**核心標語**：「你的平行宇宙損益引擎」

---

## 2. 目錄結構

```
hackathon/
├── app.py                          # 主程式（約 1750 行）
├── requirements.txt                # Python 相依套件
├── spec.md                         # 本規格書
├── sample_data/
│   ├── sample_statement.csv        # 範例 CSV（5 筆交易）
│   └── sample_statement.png        # 範例券商對帳單截圖（900×520）
├── templates/
│   ├── base.html                   # Jinja2 母版（navbar + footer）
│   ├── index.html                  # 首頁（上傳區）
│   ├── analysis.html               # 分析結果頁
│   └── chat.html                   # AI 教練對話頁
├── static/
│   ├── bestdeal.html               # BestDeal 實單頁（獨立單檔，見 §12.5）
│   ├── claude.html                 # Claude 實單頁（獨立單檔，見 §12.5）
│   ├── css/
│   │   └── style.css               # 完整暗色主題（813 行）
│   └── js/
│       └── main.js                 # 共用 JS 工具（18 行）
└── upload_logs/                    # 自動建立，儲存上傳原始檔與解析結果
```

---

## 3. 技術棧與相依套件

### 3.1 後端

| 套件 | 版本需求 | 用途 |
|------|---------|------|
| Flask | ≥ 3.0 | Web 框架 |
| requests | ≥ 2.31 | HTTP 請求（TWSE API、PaddleOCR、Google News RSS） |
| pandas | ≥ 2.0 | 股票清單 HTML 表格解析 |
| anthropic | ≥ 0.40 | Claude API（目前未直接使用，透過 CLI） |
| Pillow | ≥ 10.0 | 圖片處理（裁切、放大、HEIC 轉換、字形渲染） |
| opencc（可選） | 任意版本 | 簡體→繁體轉換（PaddleOCR 常將繁體辨識為簡體） |
| pillow-heif（可選） | 任意版本 | HEIC 格式支援 |
| numpy | 隨 Pillow 安裝 | 字形點陣圖相似度計算、EREM v3 指標向量化計算 |
| matplotlib | ≥ 3.5 | K 線圖渲染（Agg backend，回測買賣點標記圖） |

### 3.2 外部服務

| 服務 | 端點 | 用途 |
|------|------|------|
| AWS Bedrock Converse API | `bedrock-runtime.{region}.amazonaws.com`（手動 SigV4 簽章，`_bedrock_converse()`） | AI 推理主路徑（OCR 解析、名稱驗證、K 線出場判斷、聊天）。憑證讀自 `bedrock.env` |
| Claude CLI | `/opt/homebrew/bin/claude` | Bedrock 憑證不存在時的 fallback（`_has_bedrock()` 判斷） |
| PaddleOCR API | `http://192.168.10.166:5050/ocr`（可選） | 快速 OCR，回傳 bounding box + 文字 |
| TWSE ISIN | `https://isin.twse.com.tw/isin/C_public.jsp?strMode=2` | 上市股票代碼/名稱清單 |
| TPEX ISIN | `https://isin.twse.com.tw/isin/C_public.jsp?strMode=4` | 上櫃股票代碼/名稱清單 |
| TWSE 月成交 | `https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date={YYYYMM01}&stockNo={code}` | 上市股日 OHLCV（按月抓，回測歷史） |
| TPEX 月成交 | `https://www.tpex.org.tw/www/zh-tw/afterTrading/tradingStock?code={code}&date={YYYY/MM/01}` | 上櫃股日 OHLCV（注意參數是 `code=`，舊版 `id=` 已失效） |
| Google News RSS | `https://news.google.com/rss/search?q=...&hl=zh-TW` | 即時新聞抓取（fallback） |

**Bedrock 模型常數**：

```python
BEDROCK_CHAT_MODEL  = 'openai.gpt-oss-120b-1:0'                     # 聊天
BEDROCK_PARSE_MODEL = 'us.anthropic.claude-sonnet-4-5-20250929-v1:0' # OCR 解析、K 線出場判斷
BEDROCK_GLYPH_MODEL = 'us.anthropic.claude-opus-4-6-v1'              # 名稱字形驗證
```

### 3.3 前端

| 資源 | 版本 | 用途 |
|------|------|------|
| Chart.js | 4.4.1（CDN） | 雷達圖、折線圖 |
| Font Awesome | 6.5.1（CDN） | 圖示 |
| Google Fonts — Noto Sans TC | 400/500/700/900 | 中文字體 |
| 原生 JavaScript ES6 | — | 無框架，vanilla JS |

### 3.4 `requirements.txt`

```
flask>=3.0
requests>=2.31
pandas>=2.0
anthropic>=0.40
pillow>=10.0
matplotlib>=3.5
```

---

## 4. 啟動方式與環境設定

### 4.1 Flask 設定

```python
app = Flask(__name__)
app.secret_key = os.urandom(24)                    # 每次啟動隨機產生
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB 上傳上限
```

### 4.2 啟動指令

```bash
python app.py
# 等同於：
# app.run(debug=True, host='0.0.0.0', port=8080, use_reloader=False)
```

AWS Bedrock 憑證放在專案根目錄 `bedrock.env`（`AWS_ACCESS_KEY_ID` /
`AWS_SECRET_ACCESS_KEY` / `AWS_SESSION_TOKEN` / `AWS_REGION`），
存在時所有 AI 呼叫走 Bedrock Converse API，否則 fallback 到 claude CLI。

啟動時印出版本號：`[app] code version: 2026-07-12 filter-v2`

### 4.3 外部路徑依賴

```python
NEWS_DB_PATH = '/Users/rubylintu/code/News_DB/Data'   # News_DB 模組路徑
NEWS_DATA_DIR = os.path.join(NEWS_DB_PATH, 'news_data')  # 新聞 CSV 目錄
```

如果 `News_DB` 不存在，系統會自動 fallback 到模擬資料（詳見 §14）。

### 4.4 可選模組匯入

```python
# 股價歷史（用於轉折點分析）
try:
    from directional_particle_model import get_stock_history
    HAS_STOCK_HISTORY = True
except ImportError:
    HAS_STOCK_HISTORY = False
    # 自動產生模擬價格資料

# 混合預測器
try:
    from hybrid_predictor import hybrid_predict, analyze_news
    HAS_HYBRID = True
except ImportError:
    HAS_HYBRID = False
```

---

## 5. 後端路由總覽

| 方法 | 路徑 | 功能 | 回傳 |
|------|------|------|------|
| GET | `/` | 首頁（上傳區） | HTML |
| POST | `/api/upload` | 檔案上傳（CSV/圖片/PDF）+ 解析 | JSON `{ok, count, redirect}` |
| GET | `/api/sample` | 載入範例 CSV | JSON `{ok, redirect}` |
| POST | `/api/sample_photo` | 載入範例截圖（走 Vision 管線） | JSON `{ok, count, redirect}` |
| GET | `/analysis` | 分析結果頁 | HTML |
| GET | `/chat/<stock_code>` | AI 教練對話頁 | HTML |
| POST | `/api/chat` | 傳送聊天訊息 | JSON `{reply}` |
| GET | `/api/news/<stock_code>` | 取得股票新聞列表 | JSON `[{date, title, source, url}]` |
| GET | `/api/stock_history/<stock_code>` | 取得股價歷史 | JSON `[{date, open, high, low, close, volume}]` |
| POST | `/api/backtest` | 啟動平行宇宙回測 | JSON `{user_total_pnl, personas, chart_data, best}` |
| POST | `/api/profile` | 生成投資風格 | JSON `{radar, description}` |

---

## 6. 核心模組：檔案上傳與 OCR 辨識管線

### 6.1 支援格式

```python
VISION_MIME_TYPES = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.webp': 'image/webp',
    '.heic': 'image/heic',
    '.pdf': 'application/pdf',
}
```

### 6.2 `api_upload()` 上傳流程

```
使用者上傳檔案
    │
    ├─ 副檔名 .heic？ → Pillow + pillow_heif 轉 JPEG（quality=95）
    │
    ├─ 讀取 form data 中的 mode 欄位（"statement" 或 "holdings"）
    │
    ├─ .csv → parse_csv() 直接解析
    │
    └─ 圖片/PDF → parse_with_vision(file_bytes, mime_type, structure_hint?, rows_rules?)
                     │
                     │  mode="holdings" 時傳入 HOLDINGS_STRUCTURE_HINT + HOLDINGS_ROWS_RULES
                     │  mode="statement"（預設）使用 STATEMENT_STRUCTURE_HINT + STATEMENT_ROWS_RULES
                     │
                     ├─ 回傳 (trades, skipped)
                     │
                     └─ trades 為空 → 回傳錯誤訊息（依 mode 不同）
    │
    ├─ log_upload() 記錄
    ├─ calc_trade_stats() 計算損益
    └─ 存入 session → 重導到 /analysis
```

### 6.3 `parse_with_vision()` 雙策略管線

函式簽名：

```python
def parse_with_vision(file_bytes, mime_type, structure_hint=None, rows_rules=None):
```

`structure_hint` 和 `rows_rules` 預設使用 `STATEMENT_STRUCTURE_HINT` 和 `STATEMENT_ROWS_RULES`，持股模式時傳入對應的 `HOLDINGS_*` 版本。

#### 策略 1：PaddleOCR + Claude Sonnet（快速路徑，約 60 秒）

```
file_bytes → POST 到 PaddleOCR API
    │
    ├─ 回傳 boxes（bounding box 陣列）
    │   └─ _boxes_to_grid(boxes) → 以 y 座標聚類為列、x 排序 → 用 " | " 連接
    │
    ├─ _ocr_text_quality(text) ≥ 0.93？
    │   │
    │   ├─ YES → 組合 prompt（OCR 結果 + STRUCTURE_HINT + ROWS_RULES）
    │   │        → claude -p --model sonnet → 解析 JSON array
    │   │        → _dedupe_rows() 去重
    │   │        → _verify_names_with_vision() 視覺驗證股票名稱
    │   │        → _rows_to_trades() 配對
    │   │
    │   └─ NO → 跳到策略 2
    │
    └─ 如果 trades 數量 ≥ 5 → 完成
```

#### 策略 2：Claude Vision 直讀（精確路徑，約 120-300 秒）

只在策略 1 結果 < 5 筆交易時啟動：

```
file_bytes → _split_image_bands(band_px=600, overlap=100, scale=2)
    │           └─ 裁切為 600px 高的橫段，相鄰段重疊 100px
    │           └─ 每段 2 倍放大（確保文字清晰）
    │           └─ 存為暫時 PNG 檔
    │
    ├─ PDF → 直接存暫時檔（不切割）
    │
    └─ 組合 prompt：
        "以下 N 個檔案是同一份券商持股或對帳單截圖
        （圖片已切成多個橫段，相鄰段有部分重疊）。
        請依序用 Read 工具讀取每一個檔案，重疊區域的重複列只轉錄一次。"
        + 檔案路徑清單
        + STRUCTURE_HINT + ROWS_RULES
        │
        → claude -p --model sonnet --allowedTools Read --dangerously-skip-permissions
        → 解析 JSON array
        → _rows_to_trades(_dedupe_rows(rows))
```

#### 後處理安全網

```python
# 1. 修正 sell_price 被 OCR 讀成「成交金額」而非「單價」的問題
if shares > 1 and buy_price > 0:
    ratio = sell_price / buy_price
    per_share = sell_price / shares
    per_ratio = per_share / buy_price
    if (ratio > 3 and 0.5 < per_ratio < 2) or (ratio >= 1.5 and 0.93 < per_ratio < 1.07):
        sell_price = round(per_share, 2)

# 2. 刪除退化列（同日同價 = 無資訊）
if buy_date == sell_date and buy_price == sell_price:
    continue

# 3. 移除重複的 breakeven 列
# 未配對的明細買入會被重新 emit 為庫存（sell_price=buy_price），
# 如果同股已有真實庫存列（不同 sell_price），移除 breakeven 版本
```

### 6.4 `_boxes_to_grid()` — OCR Bbox 重建表格

```python
def _boxes_to_grid(boxes, min_conf=0.5):
    """
    輸入：[{text, x1, y1, x2, y2, conf}, ...]
    處理：
      1. 過濾 conf < 0.5
      2. 計算中位高度，row_tol = max(8, median_height × 0.6)
      3. 依 y_center 聚類為列
      4. 每列依 x 排序，用 " | " 連接
    輸出：多行字串，每行代表表格一列
    """
```

### 6.5 `_ocr_text_quality()` — OCR 品質判定

```python
def _ocr_text_quality(text):
    """
    計算非空白字元中「合理字元」的比例。
    合理字元 = CJK + 數字 + 英文 + 常見標點
    乾淨 OCR > 0.95；雜亂 OCR ~ 0.80
    閾值 0.93 以上才信任 OCR 結果。
    """
```

### 6.6 `_split_image_bands()` — 長截圖切割

```python
def _split_image_bands(file_bytes, band_px=600, overlap=100, scale=2):
    """
    Claude Vision 會將圖片縮小至 ~1568px，密集表格會變得不可讀。
    解法：
      1. 將原圖裁切為 600px 高的橫段（相鄰段重疊 100px）
      2. 每段放大 2 倍
      3. 存為暫時 PNG
    回傳：暫時檔案路徑陣列
    """
```

### 6.7 CSV 解析

```python
def parse_csv(file_stream):
    """
    預期欄位（CSV header）：
      stock_code, stock_name, buy_date, buy_price, sell_date, sell_price, shares

    回傳 list[dict]，每個 dict 包含上述 7 個欄位。
    日期格式：YYYY-MM-DD
    """
```

---

## 7. 核心模組：交易配對引擎 `_rows_to_trades`

這是整個系統最關鍵的函式，負責將 AI 轉錄的 JSON 列轉換為已配對的交易。

### 7.1 輸入格式（rows）

AI 回傳的 JSON array 中，每個元素是以下三種 type 之一：

```json
// 庫存列
{"type": "holding", "name": "南亞", "code": "1303", "shares": 8, "avg_cost": 151.5, "market_price": 166.5}

// 明細列（單邊）
{"type": "buy", "date": "2026-06-02", "name": "長榮", "code": "", "shares": 4, "price": 227.0, "amount": 908, "net": 905}
{"type": "sell", "date": "2026-06-15", "name": "長榮", "code": "", "shares": 4, "price": 235.0, "amount": 940, "net": 935}

// 已配對交易列（少數券商格式）
{"type": "trade", "name": "台積電", "code": "2330", "buy_date": "2026-01-15", "buy_price": 850, "sell_date": "2026-03-20", "sell_price": 920, "shares": 1000}
```

### 7.2 處理流程

```
1. 遍歷所有 rows：
   ├─ type="trade" → 直接加入 trades（buy_date/buy_price/sell_date/sell_price 完整）
   ├─ type="holding" → 加入 holdings 暫存（稍後轉為開倉交易）
   └─ type="buy"/"sell" → 加入 events[stock_code] 分股暫存

2. 名稱解析：每列都經過 _resolve_stock(name, code) 比對官方清單

3. 價格校正：
   如果 price × shares 與 amount 偏差 > 5%，改用 amount / shares 作為 price
   （OCR 常將「單價」和「成交金額」搞混）

4. 買賣方向校正：
   買/賣 OCR 常認錯（普賣→普寶、晋買...），改用 net vs amount 判斷：
   - net > amount → buy（客戶應付＝成交金額+手續費）
   - net < amount → sell（客戶應收＝成交金額-手續費-稅）

5. 孤兒賣單歸屬（orphan sells）：
   OCR 有時整個名稱欄都沒辨識到。
   如果恰好只有一檔股票的淨餘量（buys - sells - 庫存股數）等於該孤兒賣單的股數，
   且該股票有同股數的買入在賣出日之前，就歸屬之。

6. FIFO 配對：
   每檔股票的 events 依日期排序（同日買先於賣），
   每筆 sell 從 queue 頭開始配對 buy：
   - 如果 sell 的 shares > 當前 buy 的剩餘 shares → 部分配對，繼續消耗下一筆 buy
   - 如果 sell 配完仍有剩餘 → 該部分視為期初持有（skipped sell），無成本基礎

7. 庫存轉開倉：
   holdings 中的每檔股票 → 一筆交易：
   - buy_date = 該股最早的未配對 buy 日期，或 period_start
   - buy_price = avg_cost
   - sell_date = today
   - sell_price = market_price

8. skipped sells 排序後回傳
```

### 7.3 輸出格式

```python
# trades: list[dict]
{
    'stock_code': '2330',
    'stock_name': '台積電',
    'buy_date': '2026-03-15',
    'buy_price': 850.0,
    'sell_date': '2026-05-20',
    'sell_price': 920.0,
    'shares': 1000,
}

# skipped: list[dict]  (期初已持有的賣出，無成本基礎)
{
    'stock_code': '2330',
    'stock_name': '台積電',
    'sell_date': '2026-06-01',
    'sell_price': 900.0,
    'shares': 500,
}
```

---

## 8. 核心模組：股票名稱模糊比對與字形相似度

### 8.1 官方股票清單載入 `_load_stock_names()`

```
1. 從 TWSE ISIN 取得上市股票清單（strMode=2），big5 編碼，pandas.read_html 解析
2. 從 TPEX ISIN 取得上櫃股票清單（strMode=4）
3. 解析格式：每行第一格為 "代碼\u3000名稱"（全形空格分隔）
4. 建立全域快取 _stock_name_cache: {code: name}
5. Fallback 常用股票硬編碼（2330=台積電、2454=聯發科 等 20+ 檔）
```

### 8.2 名稱正規化

```python
def _s2t(text):
    """簡體→繁體臺灣標準（opencc s2tw）"""
    # 群创→群創、圆硕→國碩

def _match_key(name):
    """正規化比對鍵：_s2t() + 臺→台"""
    # 臺建電 → 台達電
```

### 8.3 `_resolve_stock(name, code)` — 名稱解析

```
1. code 在 cache 中？→ 直接回傳 (code, name)
2. _match_key(name) 在 key_to_name 中？→ 精確匹配
3. len(key) < 2？→ 放棄（單字殘留會亂 match）
4. difflib.get_close_matches(key, keys, n=1, cutoff=0.5)
5. 都沒中 → 回傳 ('', '')
```

### 8.4 `_glyph_sim(a, b)` — 字形視覺相似度

```
原理：OCR 混淆的字通常「長得像」（中國/中鋼/中砂，difflib 分數相同），
      只有字形像素比較能區分。

實作：
1. 使用 Pillow 渲染每個 CJK 字元到 40×40 灰度圖（字體 32pt）
2. 閾值 > 96 轉為布林點陣圖
3. 計算 Jaccard 相似度 = |A ∩ B| / |A ∪ B|
4. 結果快取（_glyph_sim_cache、_glyph_bitmap_cache）

字體搜尋順序（macOS）：
- /System/Library/Fonts/PingFang.ttc
- /System/Library/Fonts/STHeiti Light.ttc
- /System/Library/Fonts/Hiragino Sans GB.ttc
```

### 8.5 `_name_candidates(key, key_to_name, n=8)` — 候選排名

```
對每個官方名稱 k：
1. 如果 key ⊂ k 或 k ⊂ key（長度 ≥ 3）→ 直接加入（ETF 截斷情況）
2. 長度差 > 1 → 跳過
3. 計算逐字位置得分：
   vis = Σ (1.0 if 同字 else _glyph_sim(a, b))  for (a,b) in zip(key, k)
   score = vis / max(len) + difflib.ratio
4. 取 top-n（預設 8）
```

---

## 9. 核心模組：Vision 多輪驗證 `_verify_names_with_vision`

### 9.1 觸發條件

OCR 辨識出的名稱若不在官方股票清單中，且沒有有效代碼，就是「可疑名稱」。

### 9.2 排除條件（不需 Vision 驗證）

- 該列已攜帶有效股票代碼
- `_match_key(name)` 在官方清單中
- 模糊比對結果恰好是另一列精確匹配的名稱（「举航 buy ↔ clean 華航 sell」情境）

### 9.3 圖片裁切策略

對每個可疑名稱：
1. 在 OCR boxes 中找到對應的 bounding box
2. **列全景**：裁切 box 所在列的左 65% 寬度（±6px 高度 padding），放大至 ~2300px 寬（最多 4 倍）
3. **名稱特寫**：裁切 name cell（±3px padding），放大 8 倍

### 9.4 Re-OCR `_reocr_name_cell()`

將 name cell 放大 4 倍後重新送 PaddleOCR，取信心度最高的結果。
常見情況：`效随科` re-OCR 為 `敦随科`，`敦` 對了但 `随科` 仍錯。
將兩次 OCR 的候選名稱 union 起來，增加正確答案出現的機率。

### 9.5 跨行候選池化

如果兩個可疑名稱長度相同且至少一個位置的字相同（代表可能是同一檔股票的不同 OCR 變體），
合併它們的候選清單。

### 9.6 Claude Vision 批次驗證

```
每次最多 4 列（避免注意力分散），最多 2 輪重試：

Prompt 結構：
"以下是台灣券商對帳單表格中裁切出來的 N 個橫列，
每列有兩張圖：列全景（4倍放大）與股票名稱欄特寫（8倍放大）。
明細列：成交日期 | 交易別 | 股票名稱 | 股數 | 單價 | 成交金額…
庫存列：代碼 | 股票名稱 | 股數 | 平均成本 | 市價…

0. 列全景 /path/row.png 名稱特寫 /path/cell.png 候選：[...]
1. ...

注意：
1. 候選可能不含正確答案；若能清楚辨識就填你的答案
2. 名稱字數必須與圖片一致
3. 逐字比對字形部件（積=禾+責, 達=⻌部件有底部長捺, 鋼=金部）
4. 不確定就填 ""

只輸出 JSON：{"0":"名稱","1":"名稱",...}"

→ claude -p --model opus --allowedTools Read --dangerously-skip-permissions
```

### 9.7 結果接受條件

Vision 回傳的名稱必須：
1. 在 official 清單中（`name in official`），且
2. 在候選名單中，或「合理解釋 OCR 誤讀」：
   - 長度與原始/re-OCR 名稱相同
   - 至少一個位置字元相同

通過後更新 `row['name']` 和 `row['code']`。

---

## 10. 分析引擎：轉折點、新聞、投資風格、平行宇宙回測

### 10.1 `calc_trade_stats(trades)` — 損益計算

```python
for each trade:
    pnl = (sell_price - buy_price) * shares
    pnl_pct = (sell_price - buy_price) / buy_price * 100   # 百分比
    hold_days = (sell_date - buy_date).days
```

### 10.2 `generate_turning_points(trade)` — 轉折點

```
1. 用 get_stock_history(stock_code, days=hold_days+30) 取得實際股價
2. 過濾出 buy_date ≤ date ≤ sell_date 的交易日
3. 如果有 ≥ 3 個交易日：
   - high_pt = max(prices, key=high)
   - low_pt = min(prices, key=low)
   - 如果 high 和 low 同一天 → 從剩餘日期中重新選 low
   - 回傳 4 點（按日期排序）：buy → high → drawdown → sell
4. 不足 3 日 → 回傳 2 點：buy → sell

每個 point:
{date, type: "buy"|"high"|"drawdown"|"sell", price, label: "買入"|"最高點"|"最大回撤"|"賣出"}
```

ROC 日期轉換（民國→西元）：

```python
def _roc_to_date(roc_str):  # "115/07/03" → datetime(2026, 7, 3)
    parts = roc_str.split('/')
    y = int(parts[0]) + 1911
    return datetime(y, int(parts[1]), int(parts[2]))
```

### 10.3 新聞關聯系統

#### `_news_title_relevant()` — 新聞相關性篩選

```
1. 標題包含股票代碼 → 相關
2. 移除已知名稱碰撞（如 "金寶山" 對 "金寶" 股票 2312）
3. 標題包含股票名稱（或前 3 字截斷） → 相關
4. 標題包含任何財經關鍵字 → 相關
```

財經關鍵字清單（`_FINANCE_NEWS_KEYWORDS`）：

```python
('股', '盤', '漲', '跌', '營收', '財報', '法說', '外資', '投信', '自營商',
 'EPS', '每股', '盈餘', '獲利', '虧損', '訂單', '出貨', '產能', '毛利',
 '上市', '上櫃', '除息', '除權', '配息', '股利', '目標價', '評等',
 '買超', '賣超', '籌碼', '營運', '業績', '接單', '擴廠', '產線',
 '集團', '投資', '市值', '台股', '證交所', '董事會', '併購', '受惠')
```

#### `_load_all_news_for_stock()` — 三級新聞來源

```
1. news_history.csv（有 date, title, source, url）
2. training_data.csv（有 text, stock_code — 無日期，取前 80 字作標題）
3. Google News RSS（即時抓取，關鍵字 = "{stock_name} {stock_code} 股票"）
```

#### `generate_news_for_point()` — 轉折點新聞匹配

```
1. 精確/±3天 日期匹配
2. 無日期匹配 → 找最近可用新聞
3. 完全無新聞 → 回傳 None
```

### 10.4 `generate_investor_profile()` — 投資風格雷達圖

5 軸雷達（0-100 分）：

| 軸 | 計算方式 |
|---|---------|
| 集中度 | `min(100, 100 / unique_stocks × 1.5)` |
| 換手率 | `max(10, min(95, 100 - avg_hold_days × 1.5))` |
| 平均持有天數 | `min(95, avg_hold_days × 1.2)` |
| 追高頻率 | `count(pnl_pct < -3%) / n × 100` |
| 產業分散度 | `min(90, unique_stocks × 20)` |

文字描述邏輯：

```
avg_hold < 15 天 → "短線交易者，偏好快進快出"
avg_hold < 60 天 → "波段操作者，持股週期適中"
avg_hold ≥ 60 天 → "中長線投資者，耐心持有"

+ 集中度 > 60 → "持股集中度偏高，建議適度分散風險。"
+ 追高頻率 > 40% → "追高頻率較高，容易在高點買進造成虧損。"
+ 換手率 > 70 → "交易頻率偏高，注意手續費對報酬的侵蝕。"
+ 勝率 ≥ 60% → "整體勝率不錯，但仍需注意虧損交易的控制。"
+ 勝率 < 60% → "勝率有提升空間，建議加強進場時機的判斷。"
```

### 10.5 `run_parallel_universe_backtest()` — 平行宇宙回測（Claude vs AI Dealer PK）

兩個 AI 人格，用真實日 K 重播同一批持股並與使用者實際操作比較：

| 人格 | 圖示 | 出場機制 | 旗標 |
|------|------|----------|------|
| Claude 看盤型 AI | 🧠 | Claude 逐日看 K 線技術圖（K 棒 + MA5/MA10），自行判斷哪天出場 | `kline: True` |
| AI Dealer | 💼 | BestDeal 真實出場機制：禁當沖、每日 ATR 風控（停利 = 前收 +3×ATR14、停損 = 前收 −2×ATR14）、EREM v3 持有信心 <40 全出／40–54 減碼 25%，否則期末強平 | `dealer: True` |

每筆交易回傳 `chart`（base64 data URI PNG），K 線圖上標記 BUY（藍▲）、
AI SELL（紫▼）、MY SELL（黑▼，使用者實際賣點）。

#### 10.5.1 `_fetch_history_bars(stock_code, days)` — 按月抓歷史日 K

news_db 的 `get_stock_history` 寫死只抓最近 2 個月，長週期指標
（EMA200 / 120 日區間 / VWAP60）暖機不足會讓 EREM 分數失真，
所以改為自行按月抓：

- `months = max(2, min(days//30 + 1, 12))`，由當月往回逐月請求
- 上市走 TWSE `STOCK_DAY`；該月無資料則試 TPEX（參數是 `code=`，
  news_db 舊版用的 `id=` 已失效會回 `參數輸入錯誤`）；一旦判定
  上市/上櫃就鎖定來源不再互試
- TPEX 成交量單位是仟股，×1000 正規化
- 民國日期 `_roc_to_date()` 轉西元、`close ≤ 0` 列丟棄、每次請求間
  `sleep(0.15)`、結果依 ISO 日期排序
- 模組層快取 `_BARS_FETCH_CACHE[(stock_code, months)]`
- 輸出 `{date, open, high, low, close, volume}`（float）

主流程 pre-fetch：每檔股票 span = `(today − 最早買進日).days + 300`
（+300 天暖機），存 `_hist_cache[stock_code]`（完整未過濾歷史）。

#### 10.5.2 `_render_kline_png(bars, buy_idx, buy_price, sell_idx, sell_price, user_sell_idx, user_sell_price)` — K 線圖渲染

matplotlib（Agg backend），回傳 PNG bytes：

- K 棒：台股慣例紅漲（`#d33`）綠跌（`#1a9850`），vlines 影線 + Rectangle 實體
- MA5 橘實線、MA10 藍虛線
- 買進價灰色點狀水平線；BUY 藍▲（label 下移 14pt）；
  AI SELL 紫▼ `#9400d3`（上移 8pt）；MY SELL 黑▼ `#222`（上移 20pt，
  與 AI SELL 同一根 K 棒時 label 錯開）
- 圖上不放中文（避免字體問題），figsize (7, 3.2)、dpi 110

#### 10.5.3 `_claude_kline_exit(trade, hist)` — Claude 看盤出場

- 快取 `_KLINE_EXIT_CACHE[(code, buy_date, sell_date, buy_price)]`
- 持有期 bars + 買進日前 20 根 lookback，逐日渲染快照
  （第 i 張 = 持有第 i 天收盤後看到的圖，最多 10 張控制 payload）
- 一次 `_bedrock_converse(prompt, model_id=BEDROCK_PARSE_MODEL,
  max_tokens=500, timeout=180, images=imgs)`，prompt 要求依時間順序
  逐日判斷、不可用未來資訊回頭改答案，回
  `{"exit_day": 1~N 或 0, "reason": "20字內"}`（0 = 續抱到底）
- 出場價 = 該日收盤；未出場沿用使用者實際賣價
- 最後渲染完整持有期 + 買賣點標記圖存入 `res['chart']`
- 無 Bedrock / 無資料 / `_trade_price_mismatch()`（見下）→
  fallback 沿用實際賣出（不畫圖、不模擬）

#### 10.5.3b `_trade_price_mismatch(trade, hold)` — 價格資料不匹配檢查

對帳單解析出的價格若與市場日 K 對不上（OCR 錯價或認錯股票），
買賣點標記會浮在 K 棒外的半空中，因此改用嚴格檢查
（`_claude_kline_exit` 與 `_ai_dealer_exit` 共用）：

- **買價必須落在買進日 K 棒的 `[low×0.97, high×1.03]` 區間**，
  賣價同理落在賣出日 K 棒區間（±3% 容忍）
- 該日無對應 bar（非交易日/資料缺漏）時，退回粗檢：
  持有期中間 bar 收盤價與該價格差 >50% 才判定不匹配
- 任一價格檢查失敗 → 回傳不匹配 → 該筆交易 fallback
  沿用實際賣出價、`exit_reason='價格資料不匹配，沿用實際賣出價'`、
  不附 chart

（歷史教訓：舊版只用「中間 bar 收盤 vs 買價差 >50%」粗檢，
差 10–50% 的錯價交易會照畫圖，BUY/SELL 標記整組浮在 K 棒下方。）

#### 10.5.4 `_erem_v3_series(stock_code, hist)` — EREM v3 / LES v3 指標移植

移植自同事 TWse-stock-crawler `domain/strategies/` 的
`expected_return_exit_v3.py` + `low_entry_score_v3.py`（純 pandas/numpy
OHLCV 數學，**不需要跑爬蟲**）。快取
`_EREM_SERIES_CACHE[(code, len(hist), 首日, 末日)]`，回傳逐日序列：

- `raw`：EREM v3 原始分（**不含**進場品質分）＝趨勢(EMA20/50/200 排列
  12 + 站上 EMA20 8) + 動能(RSI 45–70 5 + MACD 多頭 5 + 柱狀圖走揚 5 −
  動能衰竭 5，衰竭＝柱狀圖連 2 日下降或價創 20 日高但 MACD 背離，
  clip 0–15) + 波動(ATR14≤ATR20MA 5 + 收盤低於布林上緣 5 − ATR 過度放大
  5 − 觸上緣且衰竭 5，clip 0–10) + 出貨偵測(OBV 走揚 5 + 量增價漲 5 +
  無出貨警訊 5，警訊＝量增價跌/高換手價跌/OBV 連 5 日降/OBV 背離，
  clip 0–15) + 剩餘漲幅(120 日區間 reward/risk >2 得 10、1–2 得 5 +
  低於 120 日布林上緣 5，clip 0–15) + 結構(20 日 swing 高低點同步墊高
  5) + 換手健康(量比≥1.2 且價不跌 5) + VWAP60(收盤低於 60 日 VWAP 5)。
  相對強弱 0–10 分需 TAIEX 資料，無資料 → 0（與原策略缺欄位行為一致）
- `les`：LES v3 低點分數 0–100（進場日品質評分：趨勢 25 + 動能 20 +
  波動 20 + 量能 20 + 結構 15）
- `atr`：ATR14（TR 14 日滾動均值）

#### 10.5.5 `_ai_dealer_exit(trade, hist)` — BestDeal 真實出場機制

複刻同事 `bestdeal_trader.py` 的 `_check_exit`，快取
`_DEALER_EXIT_CACHE`。逐日模擬（`fills` 記錄每筆出場）：

1. **禁當沖**：買進當天（持有第 0 天）不出場，所有機制隔日生效
2. **v3 ATR 風控**（每日「盤前」以前一交易日資料更新）：
   `v3_target = 前日收盤 + 3×ATR14(前日)`、
   `v3_stop = 前日收盤 − 2×ATR14(前日)`；
   無 ATR 資料時 fallback `買價 × 0.96`（-4% 硬停損）。
   **停利先於停損檢查**（原版順序）：當日 `high ≥ v3_target` → 以
   target 價出場（開盤已跳過 target 則用開盤價）；否則
   `low ≤ v3_stop` → 以 stop 價出場（跳空開低用開盤價）
3. **EREM v3 訊號**（收盤判斷，每日最多一次）：
   - 進場品質分 eq：進場日 LES ≥75 → +5、≥60 → +3、否則 0
   - `當日 EREM = clip(raw + eq, 0, 105) × 100 / 105`
   - **持有信心 HC = 0.6×當日 EREM + 0.4×進場日 LES**
   - `HC < 40` → EXIT 全部出場（收盤價）；`40 ≤ HC < 55` → 當日減碼
     25%（賣出剩餘部位的 1/4，收盤價）；`HC ≥ 55` → 續抱
4. **期末強平**：持有到使用者實際賣出日仍有剩餘部位 → 以使用者
   實際賣價平倉
5. 回傳 `price` = 各筆出場的**加權平均價**（Σ 數量×價格）、
   `date` = 最後一筆出場日、`reason` = 完整決策鏈
   （例：`AI Dealer：D1 減碼25%（HC 52） → D2 EREM EXIT（HC 38）`），
   並附標記圖 `chart`

與原版的已知簡化：原版盤中逐 tick 觸發，這裡用日 K（ATR 停損利以
當日高低價判斷觸價、EREM 以收盤判斷）；原版 REDUCE 每日限一次
（`erem_action_date`），此處逐日模擬天然滿足。

#### 10.5.6 `_calc_ai_pnl(buy_price, exit_price, shares, is_unrealized=False)`

損益含交易摩擦成本（與使用者統計同一套費率）：

```
買進手續費 = 買進金額 × 0.1425%
賣出手續費 = 賣出金額 × 0.1425%
證交稅     = 賣出金額 × 0.3%（僅賣出）
net_pnl = 賣出金額 − 買進金額 − 摩擦
（is_unrealized=True 時只扣買進手續費）
```

#### 10.5.7 主流程

- **排除未實現持股**：`is_unrealized` 的交易不進回測
  （若全部都是未實現則退回全用）
- pre-fetch `_hist_cache`（見 10.5.1），人格分派：
  `kline` → `_claude_kline_exit`、`dealer` → `_ai_dealer_exit`
- 每個人格輸出：`total_pnl`（round）、`diff`、
  `diff_pct = diff / max(|user_total_pnl|, 1) × 100`、
  `trades[]`（含 `exit_reason`、`exit_date`、`pnl`、`pnl_pct`、`chart`）
- `chart_data`：labels 為股票名稱序列，`user` 與各人格名稱
  對應累積損益曲線
- `best`：`total_pnl` 最高的人格（name/diff/diff_pct）
- 前端 `analysis.html`：`#klineSection` 顯示
  「🧠 Claude vs 💼 AI Dealer 看盤 PK（K 線 + 買賣點）」，
  `.kline-grid` 以卡片列出每筆交易的 K 線圖 + 損益 + 出場理由

---

## 11. AI 對話教練（投顧老師人設）

### 11.1 `/api/chat` 路由

```python
POST /api/chat
Body: {message, stock_code, stock_name, trade}
回傳: {reply: "markdown 格式回覆"}
```

### 11.2 Claude 呼叫

```python
system_context = (
    '你是「AI 持股教練」，人設是台灣第四台投顧節目的資深老師，'
    '專門分析台灣股市。'
    '用戶正在詢問關於 {stock_name}（{stock_code}）的問題。\n\n'
    '以下是你的招牌話術庫，回答時從中挑「最貼合當下情境」的 2~4 句'
    '自然穿插進去（不要一次塞太多、不要照抄整段），'
    '讓語氣有投顧老師的臨場感：\n{GURU_PHRASES}\n\n'
    '話術規則：\n'
    '1. 依情境選類別：用戶獲利→事後諸葛類邀功；'
    '虧損→罵散戶類/技術分析包裝類（罵完要給建設性建議）；'
    '問後市→技術分析包裝類/籌碼故事類增加專業感。\n'
    '2. 分析內容本身必須誠實、根據實際數據，話術只是「表達風格」，'
    '不可為了話術扭曲事實或慫恿用戶重押。\n'
    '3. 每次回答結尾一定帶一句「避責免死金牌類」的免責話術。'
)

# 加入交易紀錄（如有）
if trade:
    system_context += (
        '\n用戶的交易紀錄：買入日 {buy_date}、買入價 {buy_price}、'
        '賣出日 {sell_date}、賣出價 {sell_price}、損益 {pnl_pct}%。'
        '\n請根據這些資訊給予具體的分析和建議。用繁體中文回答，語氣專業但親切。'
    )

→ claude -p --model sonnet --output-format text
```

### 11.3 Fallback 回覆 `generate_fallback_chat()`

Claude CLI 失敗時使用模板回覆：

```
偵測問題類型：
- "為什麼"/"原因" → 三因素分析（外資、產業、技術面）
- "建議"/"怎麼"/"應該" → 四點建議（進場時機、停損、停利、持有週期）
- 其他 → 通用分析 + 建議問題
```

---

## 12. 前端模板與頁面規格

### 12.1 `base.html` — 母版

```html
結構：
<nav class="navbar">
    <a class="nav-brand">🤖 AI 持股教練</a>     <!-- 金色 -->
    <div class="nav-links">
        <a href="/">首頁</a>
        <a href="/analysis">分析結果</a>          <!-- 只在 session 有 trades 時顯示 -->
    </div>
</nav>
<main class="container">{% block content %}</main>
<footer class="footer">CMoney 黑客松 Demo — AI 持股教練 © 2026</footer>

CDN：
- Google Fonts: Noto Sans TC (400/500/700/900)
- Font Awesome 6.5.1
- Chart.js 4.4.1
```

### 12.2 `index.html` — 首頁

```
Hero 區：
  h1 "AI 持股教練"（漸層金→橘）
  副標 "你的平行宇宙損益引擎"
  說明文字

上傳卡片：
  ┌─────────────────────────────────────┐
  │  ☁️ 上傳對帳單                       │
  │  拖放檔案到此處，或點擊選擇檔案       │
  │  支援 PDF、照片截圖（JPG/PNG）、CSV   │
  │                                      │
  │  ○ 對帳單    ○ 持股明細              │  ← Radio 切換
  │                                      │
  │  [選擇檔案]                          │
  └─────────────────────────────────────┘

  Loading overlay（上傳後顯示）：
    🤖（旋轉）
    "AI 正在辨識你的對帳單/持股明細..."
    階段訊息（依秒數切換）：
      0s: "正在上傳檔案..."
      3s: "正在使用 Claude Vision 分析檔案內容"
      15s: "AI 正在辨識表格結構與股票名稱..."
      30s: "正在比對官方股票清單與修正 OCR 錯字..."
      60s: "快好了，正在配對買賣紀錄..."
    計時器："已等待 N 秒"

  錯誤訊息（紅底，15 秒後自動隱藏）

  ── 或 ──
  [試用範例對帳單]              ← /api/sample（CSV 直接解析）
  [試用範例對帳單（照片 AI 辨識）] ← /api/sample_photo（Vision 管線）

Feature Grid（4 格）：
  📰 關鍵轉折新聞
  📊 投資風格畫像
  🔀 平行宇宙回測
  💬 AI 對話教練
```

JavaScript 行為：
- `uploadFile(file)`: 讀取 radio mode → FormData append file + mode → POST `/api/upload` → 成功導向 `/analysis`
- 拖放支援（dragover/dragleave/drop 事件）
- 範例按鈕載入中動畫

### 12.3 `analysis.html` — 分析結果頁

```
Section A — 關鍵轉折點新聞：
  每檔股票一個 timeline-card：
    [2330] 台積電  +8.2%
    ●────────●────────●────────●
    買入     最高點    最大回撤   賣出
    $850     $950      $880      $920
    📰新聞   📰新聞    📰新聞    📰新聞
    （點擊展開摘要和原文連結）

Section B — 持股卡片：
  Grid 排列，每張卡片：
    [代碼] 名稱
    +70,000 元
    +8.2%
    📅 持有 66 天
    💬 與 AI 教練對話  → /chat/{code}

Section C — 投資風格畫像：
  左：Chart.js 雷達圖（5 軸）
  右：文字描述

Section D — 平行宇宙回測：
  標題列（flex，space-between）：
    左：「平行宇宙回測」標題
    右：兩顆實單按鈕（<a> 樣式 .btn .btn-accent，開新分頁，並以文字＋顏色標明人格）：
      [⚡ 實單：💼 BestDeal]（青色 #00ced1 邊框/文字，title 提示「v3 ATR 風控 + EREM v3」）
        → href="/static/bestdeal.html"
      [⚡ 實單：🧠 Claude]（紫色 #bc8cff 邊框/文字，title 提示「逐日 K 線快照看盤出場」）
        → href="/static/claude.html"
  [啟動回測] 按鈕 → POST /api/backtest → 動態渲染：
    結論卡片（"AI Dealer 比你多賺 +501 元"）
    2 張人格卡片（Claude 看盤型 AI / AI Dealer，各自損益 + vs 使用者差異）
    #klineSection「🧠 Claude vs 💼 AI Dealer 看盤 PK（K 線 + 買賣點）」：
      .kline-grid 卡片（auto-fill minmax(360px,1fr)），每筆交易一張
      K 線圖（t.chart data URI）+ 標題（icon 人格｜股名（代碼））
      + pnl + 出場理由/出場日
    累積損益折線圖（Chart.js，使用者 vs 2 AI）
```

Skipped sells 提示（如有）：
```html
<div class="scope-note">
  分析區間說明：以下統計僅涵蓋對帳單期間內「買進→賣出」完整回合與目前庫存；
  另有 N 筆賣出屬於期初已持有的部位，未納入損益統計：
  2026-06-01 台積電 500股 @ 900
</div>
```

### 12.4 `chat.html` — AI 教練對話頁

```
Header：
  [← 返回分析]  [2330] 台積電  +8.2%

Chat messages area：
  🤖 AI 初始訊息：
    "你好！我是你的 AI 持股教練。
    我看到你在 2026-03-15 以 $850 買入台積電，
    在 2026-05-20 以 $920 賣出，獲利 8.2%。
    你想了解什麼呢？"

    [這筆交易為什麼會賺錢？]  ← suggestion chips
    [下次應該怎麼操作比較好？]
    [幫我分析台積電的近期走勢]

  👤 使用者訊息（藍底靠右）
  🤖 AI 回覆（灰底靠左）
  ⋯ Typing indicator（三點動畫）

Input area：
  [輸入你的問題...] [📤]
```

JavaScript：
- `sendMessage(text)`: POST `/api/chat` → 移除 loading → 顯示回覆
- `escapeHtml()`: XSS 防護
- `formatMarkdown()`: 簡易 markdown（**bold**、換行、列表）
- Enter 鍵送出（不含 Shift+Enter）

### 12.5 `static/bestdeal.html` / `static/claude.html` — 實單頁（獨立單檔 ×2）

由同事的 BestDeal Trader 頁面（News_DB `Data/bestdeal.html`）匯出改造而成的**獨立單檔 HTML**（CSS/JS 全內嵌，無外部相依），由 Flask 以靜態檔提供。分析頁回測區的兩顆「⚡ 實單」按鈕（§12.3 Section D）分別開新分頁連到對應頁面。兩頁格式完全相同（沿用 BestDeal 原版版面），差異如下：

| | `/static/bestdeal.html` 💼 | `/static/claude.html` 🧠 |
|---|---|---|
| 標題 | 🎯 BestDeal Trader（TWSE Low-Entry + Claude Agent） | 🧠 Claude Trader（K-line Snapshot + Claude Agent） |
| 主色 | 青色 `#00ced1`（.value.cyan、primary 按鈕、spinner） | 紫色 `#bc8cff`（.value.purple、primary 按鈕、spinner） |
| 持倉副標 | v3 ATR 停損/停利 · EREM v3 訊號出場（禁當沖，隔日生效） | 逐日 K 線快照（K 棒 + MA5/MA10）· Claude 看圖自行判斷出場（禁當沖） |
| 訊號欄位 | EREM訊號（讀 `erem_decision`/`erem_score`） | Claude訊號（優先讀 `claude_decision`/`claude_score`，fallback 到 erem 欄位） |
| 執行中文案 | TWSE爬蟲→Claude分析→下單 | K 線快照→Claude 看圖→下單 |
| Portfolio/Run API | `/api/bestdeal/portfolio`、POST `/api/bestdeal/run` | `/api/claude/portfolio`、POST `/api/claude/run` |
| 匯出檔名 | `bestdeal_state_YYYY-MM-DD.json` | `claude_state_YYYY-MM-DD.json` |

共用：`/api/pk`、`/api/health`（皆指向 `window.location.origin`）。

```
版面（暗色 #0a0e17，青色 #00ced1 主色，等寬字型）：
  Header：🎯 BestDeal Trader ＋ 市場狀態燈（開盤中/休市/API 離線）
  4 張摘要卡：現金 / 總資產 / 累計損益 / 勝率
  控制列：
    產業選單（ELEC/SEMI/VEH/AIR/BIO/COMM）
    [▶ 執行交易] [🔍 模擬 Dry Run] [↻ 刷新]
    [📥 匯入] [📤 匯出]（本次匯出新增）
    ＋隱藏 <input type="file" accept=".json">
  📊 持倉明細表（11 欄：代碼/名稱/張數/成本/現價/損益/損益%/v3停損/v3停利/EREM訊號/持有天數）
  📋 選股候選表（12 欄，Low-Entry BUY）
  🔧 交易結果表（5 欄）
  🏆 Trader PK 排行表（6 欄）
```

與原版差異（匯出時的三項要求）：
1. **移除執行日誌**：整個「📝 執行日誌」區塊、`.log-box` CSS、`log()` 函式與所有呼叫點全部刪除。
2. **資金 reset 為 0**：摘要卡初始值寫死 `$0` / `0.0% (0筆)`；頁面載入時**不**自動呼叫 `refreshPortfolio()` / `loadPK()`（只保留 `checkMarket()` 每 30 秒輪詢），因此打開檔案不會帶入任何實際資金；按 [↻ 刷新] 才連 API（`fetch` 失敗時靜默，維持 $0，離線可用）。
3. **匯入/匯出按鈕**：
   - 渲染邏輯抽成純函式 `renderPortfolio(d)` / `renderPK(d)` / `renderCandidates(list)` / `renderResults(list)`，API 載入與 JSON 匯入共用。
   - 模組變數 `lastPortfolio` / `lastPK` / `lastCandidates` / `lastResults` 保存最近一次資料。
   - `exportState()`：把上述四份資料 ＋ `exported_at` 包成 JSON，以 Blob 下載為 `bestdeal_state_YYYY-MM-DD.json`。
   - `importState()`：觸發檔案選擇 → `FileReader` 讀 JSON → 逐項還原四份資料並重繪；格式錯誤顯示「❌ 匯入失敗」。

後端 API 掛在本 app 下時不存在，屬預期行為——頁面為離線展示用（`fetch` 失敗靜默，維持 $0）。run 的 body 皆為 `{sector, dry_run}`。

另有兩份相同檔案於 `~/Desktop/bestdeal_export.html`、`~/Desktop/claude_export.html`（供直接傳給同事）。

---

## 13. CSS 設計系統

### 13.1 色彩系統（暗色主題）

```css
--bg-primary: #0d1117      /* 頁面底色 */
--bg-secondary: #161b22    /* 卡片底色 */
--bg-card: #1c2128         /* 巢狀卡片 */
--bg-hover: #252c35        /* Hover 底色 */
--border: #30363d          /* 邊框 */
--text-primary: #e6edf3    /* 主文字 */
--text-secondary: #8b949e  /* 次要文字 */
--text-muted: #6e7681      /* 弱化文字 */
--accent-blue: #58a6ff     /* 連結、主按鈕 */
--accent-green: #00d26a    /* 獲利 */
--accent-red: #f85149      /* 虧損 */
--accent-orange: #f0883e   /* 賣出點 */
--accent-purple: #bc8cff   /* 輔助 */
--accent-gold: #e3b341     /* 品牌色、icon */
--radius: 12px             /* 大圓角 */
--radius-sm: 8px           /* 小圓角 */
```

### 13.2 關鍵 CSS 類別

| 類別 | 用途 |
|------|------|
| `.navbar` | Sticky 頂部導航列 |
| `.hero-title` | 漸層金橘大標題（gradient text） |
| `.upload-area` | 虛線框拖放區域 |
| `.upload-loading` | 上傳中 overlay |
| `.timeline` | 水平時間軸（4 點） |
| `.timeline-dot` | 時間軸圓點（依 type 變色） |
| `.stock-card` | 持股卡片（hover 上浮 + 金框） |
| `.persona-card` | AI 人格回測卡片 |
| `.message-ai` / `.message-user` | 聊天氣泡 |
| `.chip` | 建議問題按鈕 |
| `.pnl-up` / `.pnl-down` | 損益顏色（綠/紅） |

### 13.3 動畫

```css
@keyframes typing { /* 聊天 typing indicator 三點動畫 */ }
@keyframes fadeIn { /* 淡入 + 上移 */ }
```

### 13.4 RWD 響應式（768px 斷點）

```
桌面                      → 手機
─────                     ─────
hero 3.2rem               → 2rem
profile 兩欄              → 單欄
timeline 水平             → 垂直（左線）
card-grid 多欄            → 單欄
persona-grid 多欄         → 單欄
navbar padding 32px       → 16px
upload-card padding 40px  → 24px
```

---

## 14. 錯誤處理與 Fallback 策略

| 情境 | Fallback |
|------|---------|
| PaddleOCR 無法連線 | 跳到策略 2（Claude Vision 直讀） |
| OCR 品質 < 93% | 跳到策略 2 |
| 策略 1 結果 < 5 筆 | 執行策略 2 |
| Claude CLI 失敗 | 聊天用 `generate_fallback_chat()` 模板回覆 |
| `directional_particle_model` 不存在 | 產生模擬股價資料 |
| `hybrid_predictor` 不存在 | `HAS_HYBRID = False`，跳過相關功能 |
| 新聞 CSV 不存在 | 產生範例新聞（"法說會釋正向訊號"等模板） |
| Google News RSS 失敗 | 回傳空新聞 |
| 股票名稱無法解析 | `_resolve_stock` 回傳 `('', '')`，該列從 trades 中移除 |
| HEIC 轉換失敗 | 回傳 400 錯誤 + 提示轉 JPG/PNG |
| 圖片無法辨識任何交易 | 依 mode 回傳對應錯誤訊息 |
| JSON 解析失敗 | 回傳 400 + "AI 回傳的資料格式異常" |

---

## 15. 上傳日誌系統

```python
UPLOAD_LOG_DIR = os.path.join(os.path.dirname(__file__), 'upload_logs')
os.makedirs(UPLOAD_LOG_DIR, exist_ok=True)

def log_upload(filename, file_bytes, trades, source='upload'):
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    prefix = f'{ts}_{source}'

    # 儲存原始檔案
    raw_path = f'{prefix}_raw{ext}'  # 例：20260713_143022_upload_raw.jpg

    # 儲存解析結果 JSON
    json_path = f'{prefix}_trades.json'
    # 內容：{filename, source, timestamp, trade_count, trades: [...]}
```

---

## 附錄 A：Prompt 完整內容

### A.1 `STATEMENT_STRUCTURE_HINT`（對帳單結構說明）

```
台灣券商對帳單結構說明：
1. 「證券庫存」表：每列是一筆目前持股（庫存股數、平均成交價格、參考市價）。
2. 「證券交易明細」表：每列是「單邊」的買進或賣出（看交易別欄，普買=買進、普賣=賣出）。
   股數欄是實際股數（零股不要乘以 1000），單價欄是每股價格，成交金額≈股數×單價。
```

### A.2 `STATEMENT_ROWS_RULES`（對帳單轉錄規則）

```
請把每一列忠實轉錄成 JSON，不要配對買賣、不要計算、不要跳列：
庫存列 → {"type":"holding","name":"南亞","code":"1303","shares":8,"avg_cost":151.5,"market_price":166.5}
明細列 → {"type":"buy" 或 "sell","date":"2026-06-02","name":"長榮","code":"","shares":4,"price":227.0,"amount":908,"net":905}
（date=成交日期，民國年+1911 轉西元 YYYY-MM-DD；price=單價欄；amount=成交金額欄；
net=該列最後的「客戶應收」或「客戶應付」金額，找不到就填 0）
交易別的「買/賣」字常被 OCR 認錯，照你的最佳判斷填 type 即可，正確買賣方向會由 net 金額在程式端重新判定。
例外：若表格每列本身就同時有買入與賣出的日期和價格（已配對的格式），
改輸出 {"type":"trade","name":"台積電","code":"2330","buy_date":"2026-01-15","buy_price":850,
"sell_date":"2026-03-20","sell_price":920,"shares":1000}
注意：name 一律照畫面原文逐字轉錄，即使看起來是 OCR 錯字也絕對不要改
（例如畫面寫 数期科 就輸出 数期科）——錯字會由程式端比對官方股票清單與原圖修正，你自行「修正」反而會配錯公司。
code 只在畫面上有代碼數字時才填，否則填 ""，絕對不要用名稱猜代碼。
只回傳 JSON array，不要其他文字。
```

### A.3 `HOLDINGS_STRUCTURE_HINT`（持股明細結構說明）

```
這是台灣券商 APP 的「持股明細」或「庫存」畫面截圖。
每一列代表一檔目前持有的股票，常見欄位包含：
股票名稱（或代碼）、持有股數、平均成本（均價）、現價（市價/參考價）、未實現損益、報酬率等。
不同券商的欄位順序與名稱可能不同，請依據畫面內容判斷。
```

### A.4 `HOLDINGS_ROWS_RULES`（持股明細轉錄規則）

```
請把每一列持股忠實轉錄成 JSON，不要計算、不要跳列：
{"type":"holding","name":"台積電","code":"2330","shares":1000,"avg_cost":850.0,"market_price":920.0}
欄位說明：
- name: 股票名稱，照畫面原文逐字轉錄（即使是 OCR 錯字也不要改）
- code: 股票代碼，畫面上有才填，否則填 ""
- shares: 持有股數（整數）
- avg_cost: 平均成本/均價（每股）
- market_price: 現價/市價/參考價（每股），找不到就填 0
只回傳 JSON array，不要其他文字。
```

### A.5 名稱驗證 Prompt

```
以下是台灣券商對帳單表格中裁切出來的 N 個橫列，
每列有兩張圖：列全景（4倍放大）與股票名稱欄特寫（8倍放大），原圖解析度低。
明細列大約是：成交日期 | 交易別 | 股票名稱 | 股數 | 單價 | 成交金額…；
庫存列大約是：代碼 | 股票名稱 | 股數 | 平均成本 | 市價…。
請用 Read 工具讀取所有圖片，判斷每列「股票名稱」欄位實際顯示的名稱：
0. 列全景 {path} 名稱特寫 {path} 候選：[...]
...

注意：
1. 候選清單來自模糊比對，可能不含正確答案；若候選都不符但你能清楚辨識出其他真實台股上市櫃公司簡稱，就填你辨識的名稱，不要遷就候選裡「比較像」的名稱。
2. 名稱「字數」必須和圖片裡顯示的字數一致。
3. 逐字比對字形部件再判斷（例如 積=禾+責 左右結構、達=⻌部件有底部長捺、鋼=金部、砂=石部）。
4. 不確定就填 ""。
只輸出 JSON，格式 {"0":"名稱","1":"名稱",...}（鍵是上面清單的編號）。
```

### A.6 聊天系統 Prompt

```
你是「AI 持股教練」，人設是台灣第四台投顧節目的資深老師，專門分析台灣股市。
用戶正在詢問關於 {stock_name}（{stock_code}）的問題。

以下是你的招牌話術庫，回答時從中挑「最貼合當下情境」的 2~4 句自然穿插進去
（不要一次塞太多、不要照抄整段），讓語氣有投顧老師的臨場感：
{GURU_PHRASES}

話術規則：
1. 依情境選類別：用戶獲利→可用「事後諸葛類」邀功；
   虧損→用「罵散戶類」或「技術分析包裝類」點出問題（罵完要給建設性建議）；
   問後市→用「技術分析包裝類」「籌碼故事類」增加專業感。
2. 分析內容本身必須誠實、根據實際數據，話術只是「表達風格」，
   不可為了話術扭曲事實或慫恿用戶重押。
3. 每次回答結尾一定帶一句「避責免死金牌類」的免責話術。

用戶的交易紀錄：買入日 {buy_date}、買入價 {buy_price}、
賣出日 {sell_date}、賣出價 {sell_price}、損益 {pnl_pct}%。
請根據這些資訊給予具體的分析和建議。用繁體中文回答，語氣專業但親切。
```

---

## 附錄 B：投顧老師金句話術庫 GURU_PHRASES

```
一、造勢煽動類（拉抬情緒）
老師帶你上車／這檔準備噴出／漲停鎖死，買不到了／起漲點就在今天／錯過這波，再等十年／
財富重分配的機會來了／現在不買，以後買不起／十年一遇的大行情／台股上看三萬點／
主升段要來了／末升段噴出行情／別人恐懼我貪婪／空手的請追進／手腳要快，慢了就沒了／
行情總在絕望中誕生

二、技術分析包裝類（聽起來很專業）
均線多頭排列／黃金交叉，買點浮現／帶量突破前高／量價齊揚／底部量縮打底完成／
W底成型／頭肩底頸線突破／杯柄型態，教科書等級／假跌破、真上漲／洗盤結束，準備發動／
均線糾結後選擇向上／沿五日線強勢上攻／站上季線，多頭確立／拉回就是買點／
逢低承接，分批佈局／型態漂亮，箭在弦上／短線滿足點還沒到／缺口不補，行情不止／
紅K吞噬，反轉訊號／強者恆強

三、籌碼故事類（暗示有內線感）
主力已經進場卡位／主力吃貨完畢／主力洗盤，甩轎中／散戶都被洗出去了／外資悄悄回補／
投信認養股／千張大戶持股連三週增加／籌碼沉澱得很漂亮／董監改選行情／集團年底作帳行情／
隱形冠軍，市場還沒發現／內資主力鎖碼／這檔有人在照顧／
大戶進、散戶出，你說會怎樣？／籌碼會說話

四、會員招募類（商業核心）
加入會員，飆股報你知／會員專屬名單／這支老師只講給會員聽／
現在打電話進來，0800——／名額有限，額滿為止／免費體驗一個月／
這支上禮拜就發給會員了／會員已經賺一根停板／老師的關門弟子班／
千線萬線，不如一條電話線

五、事後諸葛類（收割信任）
老師早就說過了／你看，是不是跟老師講的一模一樣／上次叫你買，你不買／
有跟到的請扣1／老師什麼時候騙過你／這根漲停，老師昨天就畫給你看了／
不是老師神，是方法對／會過的股票才會過／會漲的股票，怎麼壓都壓不下來／
盤面自己會說話

六、罵散戶類（建立權威）
老師在講，你有沒有在聽！／你們就是不聽話才賠錢／散戶就是愛追高殺低／
韭菜就是這樣被割的／抱不住就不要怪老師／賺錢要有方法，不是用猜的／
拿筆記下來！／重點來了，眼睛看好／你不理財，財不理你／
輸家想休息，贏家看時機

七、避責免死金牌類（法務指定）
投資一定有風險／買賣自負，老師只是分享／停損停利要自己設好／
紀律比預測重要／過去績效不代表未來獲利／
老師講的是「觀察」，不是「報明牌」／這不是投資建議

八、目標價畫餅類
目標價上看翻倍／保守估兩根停板／波段起漲點，空間先看三成／
落後補漲，輪動到它了／這檔有飆股基因／本夢比比本益比重要／妖股不講基本面

九、節目經典氛圍類
進廣告前先講一支／電話線全開，小姐等你／各位觀眾朋友，見證奇蹟的時刻／
無腦多，空軍投降／多頭總司令回來了／咬住！抱緊處理！
```

---

## 附錄 C：範例資料

### C.1 `sample_statement.csv`

```csv
stock_code,stock_name,buy_date,buy_price,sell_date,sell_price,shares
2330,台積電,2026-03-15,850,2026-05-20,920,1000
2454,聯發科,2026-04-01,1280,2026-06-10,1150,500
2881,富邦金,2026-02-10,75,2026-06-30,82,2000
0050,元大台灣50,2026-01-05,145,2026-05-15,155,3000
2603,長榮,2026-03-20,180,2026-04-25,165,1000
```

### C.2 Fallback 股票清單

```python
{
    '1303': '南亞', '1402': '遠東新', '2303': '聯電', '2330': '台積電',
    '2344': '華邦電', '2379': '瑞昱', '2382': '廣達', '2409': '友達',
    '2454': '聯發科', '3189': '景碩', '3481': '群創', '6770': '力積電',
    '2408': '南亞科', '3231': '緯創', '2881': '富邦金', '2317': '鴻海',
    '2412': '中華電', '00878': '國泰永續高股息', '0050': '元大台灣50',
    '0056': '元大高股息', '2603': '長榮', '3008': '大立光',
}
```

### C.3 Fallback 股價生成（無 News_DB 時）

```python
def get_stock_history(stock_code, days=20):
    base_price = {'2330': 900, '2454': 1200, '2881': 78, '0050': 150, '2603': 170}.get(stock_code, 100)
    data = []
    for i in range(days, 0, -1):
        dt = today - timedelta(days=i)
        noise = random.uniform(-0.03, 0.03) * base_price
        close = base_price + noise
        data.append({
            'date': dt.strftime('%Y-%m-%d'),
            'open': round(close + random.uniform(-5, 5), 1),
            'high': round(close + random.uniform(0, 10), 1),
            'low': round(close - random.uniform(0, 10), 1),
            'close': round(close, 1),
            'volume': random.randint(5000, 50000),
        })
        base_price = close
    return data
```

### C.4 Fallback 新聞模板

```python
sample_titles = [
    f'{name}法說會釋正向訊號，外資連三日買超',
    f'{name}本季營收優於預期，分析師上調目標價',
    f'{name}受惠 AI 需求，訂單能見度提升',
    f'外資報告看好{name}長線布局價值',
    f'{name}股價突破月線壓力，技術面轉強',
]
```

---

## 附錄 D：CSS 變數與完整樣式表

### D.1 完整 CSS 變數

```css
:root {
    --bg-primary: #0d1117;
    --bg-secondary: #161b22;
    --bg-card: #1c2128;
    --bg-hover: #252c35;
    --border: #30363d;
    --text-primary: #e6edf3;
    --text-secondary: #8b949e;
    --text-muted: #6e7681;
    --accent-blue: #58a6ff;
    --accent-green: #00d26a;
    --accent-red: #f85149;
    --accent-orange: #f0883e;
    --accent-purple: #bc8cff;
    --accent-gold: #e3b341;
    --font: 'Noto Sans TC', -apple-system, BlinkMacSystemFont, sans-serif;
    --radius: 12px;
    --radius-sm: 8px;
    --shadow: 0 4px 24px rgba(0,0,0,0.4);
}
```

### D.2 關鍵 UI 元件樣式摘要

**Navbar**：sticky top, bg-secondary, border-bottom, 品牌名金色

**按鈕系統**：
- `.btn-primary`：accent-blue 底白字
- `.btn-accent`：金→橘漸層底黑字
- `.btn-ghost`：透明底 + border
- `.btn-lg`：大尺寸（14px 32px）

**上傳區**：dashed border, hover 變 accent-blue + 淡藍底

**Timeline dots 顏色**：buy=blue, high=green, drawdown=red, sell=orange

**Stock cards**：hover translateY(-4px) + gold border + shadow

**Chat bubbles**：AI=bg-secondary, User=淡藍背景

**Scrollbar**：自訂 8px 寬，border 色

---

## 附錄 E：名稱碰撞排除清單

```python
_NEWS_NAME_COLLISIONS = {
    '2312': ('金寶山',),   # 金寶股票 vs 金寶山殯葬
}
```

新增其他碰撞時，在此 dict 加入 `stock_code: (排除詞,)` 即可。

---

## 附錄 F：`_dedupe_rows()` 與 `_dedupe_trades()` 去重邏輯

### `_dedupe_rows(rows)` — 轉錄列去重

```python
# 重疊影像段會產生重複列
# 以整個 dict 的 JSON 序列化作為 key 去重
key = json.dumps(r, sort_keys=True, ensure_ascii=False)
```

### `_dedupe_trades(trades)` — 配對交易去重

```python
# 以 (stock_code, buy_date, buy_price, sell_date, sell_price, shares) 為 key
key = (stock_code, buy_date, buy_price, sell_date, sell_price, shares)
```

---

*文件結束。本規格書完整涵蓋 AI 持股教練的所有技術細節，可直接用於 AI 重建完整應用程式。*
