/* AI 持股教練 — Frontend Logic */
/* Most page-specific logic is in inline <script> tags in templates. */
/* This file contains shared utilities. */

(function() {
    'use strict';

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // Mobile menu toggle (site-header)
    const header = document.getElementById('siteHeader');
    const menuButton = document.getElementById('menuButton');
    const mobileMenu = document.getElementById('mobileMenu');

    if (header && menuButton && mobileMenu) {
        function setOpen(open) {
            header.classList.toggle('site-header--open', open);
            mobileMenu.classList.toggle('mobile-menu--open', open);
            menuButton.setAttribute('aria-expanded', String(open));
            menuButton.setAttribute('aria-label', open ? '關閉選單' : '開啟選單');
            menuButton.innerHTML = open
                ? '<i class="fas fa-xmark fa-lg" aria-hidden="true"></i>'
                : '<i class="fas fa-bars fa-lg" aria-hidden="true"></i>';
        }

        menuButton.addEventListener('click', function() {
            setOpen(!header.classList.contains('site-header--open'));
        });

        mobileMenu.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('click', function() { setOpen(false); });
        });
    }

    // 登出按鈕
    document.querySelectorAll('[data-logout]').forEach(function(button) {
        button.addEventListener('click', function() {
            button.disabled = true;
            fetch('/api/auth/logout', { method: 'POST' })
                .then(function() { window.location.href = '/'; })
                .catch(function() {
                    button.disabled = false;
                    window.location.href = '/';
                });
        });
    });
})();
