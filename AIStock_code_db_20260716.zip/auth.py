#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AIStock 認證系統 — 移植自 AIHackathon Node.js authServer

功能：
- 本地帳密註冊/登入（PBKDF2-HMAC-SHA256、600,000 次迭代，與 Node 版格式相容）
- 防帳號列舉（dummy hash + 恆定時間比較）
- 登入速率限制（10 分鐘 5 次失敗 → 指數鎖定 60s 起、上限 900s）
- 記憶體 Session（HttpOnly + SameSite=Strict cookie，8 小時）
- AWS Cognito OAuth2 PKCE（S256、state/nonce、JWKS RS256 驗證）
- Google Sign-In（GSI credential JWT 後端驗證）
- 環境未設定時優雅降級（/api/auth/config 回報 disabled）
"""

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
import uuid
from datetime import datetime
from functools import wraps
from urllib.parse import urlencode, urlparse, quote

import requests as _requests
from flask import Blueprint, g, jsonify, redirect, request

# ---------------------------------------------------------------------------
# 常數（與 AIHackathon authCore / authServer 一致）
# ---------------------------------------------------------------------------

PBKDF2_ITERATIONS = 600_000
PASSWORD_MIN_LENGTH = 12
PASSWORD_MAX_LENGTH = 128
MINIMUM_SALT_BYTES = 16
HASH_LENGTH_BYTES = 32

MAX_LOGIN_ATTEMPTS = 5
ATTEMPT_WINDOW_MS = 10 * 60 * 1000
BASE_LOCK_MS = 60 * 1000
MAX_LOCK_MS = 15 * 60 * 1000

SESSION_COOKIE = 'aistock_session'
AWS_FLOW_COOKIE = 'aistock_aws_flow'
SESSION_DURATION_MS = 8 * 60 * 60 * 1000
AWS_FLOW_DURATION_MS = 5 * 60 * 1000
MAX_AWS_FLOWS = 1000
MAX_SESSIONS = 2000
MAX_SESSIONS_PER_USER = 5

DUMMY_SALT = 'AAECAwQFBgcICQoLDA0ODw=='
DUMMY_HASH = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA='

GOOGLE_CERTS_URL = 'https://www.googleapis.com/oauth2/v3/certs'
GOOGLE_ISSUERS = ('accounts.google.com', 'https://accounts.google.com')
GOOGLE_CLIENT_ID_PATTERN = re.compile(r'^\d+-[A-Za-z0-9_-]+\.apps\.googleusercontent\.com$')

_DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.data', 'auth-accounts.json')

# ---------------------------------------------------------------------------
# 記憶體狀態
# ---------------------------------------------------------------------------

_lock = threading.RLock()
_accounts = {}            # email -> account record
_sessions = {}            # token -> {'user':..., 'created_at':..., 'expires_at':...}
_aws_flows = {}           # flow token -> {'state','nonce','code_verifier','expires_at'}
_login_attempts = {}      # key -> AttemptState
_google_attempts = {}
_register_attempts = {}
_jwks_cache = {}          # url -> {'keys': [...], 'expires_at': ms}

auth_bp = Blueprint('auth', __name__)


class AuthHttpError(Exception):
    def __init__(self, status, message, extra=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra or {}


# ---------------------------------------------------------------------------
# 驗證與雜湊（移植 authCore.ts）
# ---------------------------------------------------------------------------

def _now_ms():
    return int(time.time() * 1000)


def normalize_email(email):
    return email.strip().lower()


def validate_email(email):
    normalized = normalize_email(email)
    if len(normalized) > 254 or ' ' in normalized:
        return False
    separator = normalized.rfind('@')
    if separator <= 0 or separator != normalized.find('@'):
        return False
    local = normalized[:separator]
    domain = normalized[separator + 1:]
    if (len(local) > 64 or local.startswith('.') or local.endswith('.')
            or '..' in local
            or not re.match(r"^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+$", local, re.I)):
        return False
    labels = domain.split('.')
    return len(labels) >= 2 and all(
        0 < len(label) <= 63 and re.match(r'^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$', label, re.I)
        for label in labels
    )


def normalize_name(name):
    return re.sub(r'\s+', ' ', name.strip())


def validate_name(name):
    normalized = normalize_name(name)
    errors = []
    count = len(normalized)
    if count < 2:
        errors.append('名稱至少需要 2 個字元。')
    if count > 80:
        errors.append('名稱請勿超過 80 個字元。')
    for ch in normalized:
        code = ord(ch)
        if code <= 8 or code in (11, 12, 127) or 14 <= code <= 31:
            errors.append('名稱包含不支援的控制字元。')
            break
    return errors


def validate_password(password):
    errors = []
    if len(password) < PASSWORD_MIN_LENGTH:
        errors.append('密碼至少需要 %d 個字元。' % PASSWORD_MIN_LENGTH)
    if len(password) > PASSWORD_MAX_LENGTH:
        errors.append('密碼請勿超過 %d 個字元。' % PASSWORD_MAX_LENGTH)
    if not re.search(r'[a-z]', password):
        errors.append('請加入一個小寫字母。')
    if not re.search(r'[A-Z]', password):
        errors.append('請加入一個大寫字母。')
    if not re.search(r'[0-9]', password):
        errors.append('請加入一個數字。')
    if not re.search(r'[^A-Za-z0-9\s]', password):
        errors.append('請加入一個符號。')
    return errors


def random_salt():
    return base64.b64encode(secrets.token_bytes(MINIMUM_SALT_BYTES)).decode('ascii')


def derive_password_hash(password, salt_base64, iterations=PBKDF2_ITERATIONS):
    salt = base64.b64decode(salt_base64, validate=True)
    if len(salt) < MINIMUM_SALT_BYTES:
        raise ValueError('salt too short')
    derived = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt,
                                  iterations, dklen=HASH_LENGTH_BYTES)
    return base64.b64encode(derived).decode('ascii')


def constant_time_equal(left, right):
    return hmac.compare_digest(left.encode('utf-8'), right.encode('utf-8'))


# ---------------------------------------------------------------------------
# 速率限制（移植 recordFailedAttempt / remainingLockoutMs）
# ---------------------------------------------------------------------------

def _sanitize_attempt_state(state, now):
    if not state:
        state = {}
    failed_at = [t for t in state.get('failed_at', [])
                 if 0 <= t <= now and now - t < ATTEMPT_WINDOW_MS]
    return {
        'failed_at': failed_at,
        'blocked_until': state.get('blocked_until', 0) or 0,
        'lock_level': state.get('lock_level', 0) or 0,
    }


def remaining_lockout_ms(state, now):
    if not state:
        return 0
    return max(0, state.get('blocked_until', 0) - now)


def record_failed_attempt(state, now):
    current = _sanitize_attempt_state(state, now)
    if remaining_lockout_ms(current, now) > 0:
        return current
    previous = current['failed_at']
    continuing = current['lock_level'] > 0 and len(previous) > 0
    failed_at = previous + [now]
    if len(failed_at) < MAX_LOGIN_ATTEMPTS and not continuing:
        return {'failed_at': failed_at, 'blocked_until': 0, 'lock_level': 0}
    lock_level = current['lock_level'] + 1
    delay = min(BASE_LOCK_MS * (2 ** max(0, lock_level - 1)), MAX_LOCK_MS)
    return {'failed_at': failed_at, 'blocked_until': now + delay, 'lock_level': lock_level}


def _remaining_for_keys(store, keys, now):
    return max([0] + [remaining_lockout_ms(store.get(k), now) for k in keys])


def _fail_keys(store, keys, now):
    for key in keys:
        store[key] = record_failed_attempt(store.get(key), now)


def _request_ip():
    forwarded = request.headers.get('X-Forwarded-For', '')
    if forwarded:
        parts = [p.strip() for p in forwarded.split(',') if p.strip()]
        if parts:
            return parts[-1]
    return request.remote_addr or 'unknown'


# ---------------------------------------------------------------------------
# 帳號儲存（.data/auth-accounts.json，version:1、0600、原子寫入）
# ---------------------------------------------------------------------------

def _valid_account_record(account):
    return (isinstance(account, dict)
            and isinstance(account.get('id'), str)
            and isinstance(account.get('email'), str)
            and isinstance(account.get('name'), str)
            and isinstance(account.get('salt'), str)
            and isinstance(account.get('passwordHash'), str)
            and isinstance(account.get('iterations'), int)
            and account['iterations'] > 0
            and isinstance(account.get('createdAt'), str))


def _load_account_store():
    try:
        with open(_DATA_FILE, 'r', encoding='utf-8') as f:
            parsed = json.load(f)
    except (IOError, OSError, ValueError):
        return {}
    if not isinstance(parsed, dict) or parsed.get('version') != 1 \
            or not isinstance(parsed.get('accounts'), list):
        return {}
    return {a['email']: a for a in parsed['accounts'] if _valid_account_record(a)}


def _persist_account_store():
    directory = os.path.dirname(_DATA_FILE)
    if not os.path.isdir(directory):
        os.makedirs(directory, mode=0o700, exist_ok=True)
    temp_path = '%s.%d.tmp' % (_DATA_FILE, os.getpid())
    body = json.dumps({'version': 1, 'accounts': list(_accounts.values())},
                      ensure_ascii=False, indent=2)
    fd = os.open(temp_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(body + '\n')
        os.replace(temp_path, _DATA_FILE)
        os.chmod(_DATA_FILE, 0o600)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

def _public_user(user):
    return {'id': user['id'], 'email': user['email'],
            'name': user['name'], 'provider': user['provider']}


def _create_session(user, response):
    now = _now_ms()
    with _lock:
        for token in [t for t, s in _sessions.items() if s['expires_at'] <= now]:
            del _sessions[token]
        user_tokens = [t for t, s in _sessions.items()
                       if s['user']['provider'] == user['provider'] and s['user']['id'] == user['id']]
        while len(user_tokens) >= MAX_SESSIONS_PER_USER:
            _sessions.pop(user_tokens.pop(0), None)
        while len(_sessions) >= MAX_SESSIONS:
            oldest = next(iter(_sessions), None)
            if oldest is None:
                break
            del _sessions[oldest]
        token = secrets.token_urlsafe(32)
        _sessions[token] = {'user': user, 'created_at': now,
                            'expires_at': now + SESSION_DURATION_MS}
    response.set_cookie(SESSION_COOKIE, token, max_age=SESSION_DURATION_MS // 1000,
                        httponly=True, samesite='Strict', path='/')
    return token


def _clear_session_cookie(response):
    response.set_cookie(SESSION_COOKIE, '', max_age=0,
                        httponly=True, samesite='Strict', path='/')


def get_active_session():
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        return None
    with _lock:
        session = _sessions.get(token)
        if not session or session['expires_at'] <= _now_ms():
            _sessions.pop(token, None)
            return None
    return {'token': token, 'session': session}


def current_user():
    active = get_active_session()
    return active['session']['user'] if active else None


def login_required(view):
    """頁面路由 → 302 /login?next=...；/api/ 路由 → 401 JSON。"""
    @wraps(view)
    def wrapped(*args, **kwargs):
        active = get_active_session()
        if not active:
            if request.path.startswith('/api/'):
                return jsonify({'error': '請先登入'}), 401
            return redirect('/login?' + urlencode({'next': request.full_path.rstrip('?')}))
        g.auth_user = active['session']['user']
        return view(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------------------
# 共用 helpers
# ---------------------------------------------------------------------------

def _b64url_decode(value):
    padding = '=' * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def _b64url_encode(raw):
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def _require_trusted_origin():
    """CSRF 防護：若瀏覽器有送 Origin header，必須與本站 host 相符。"""
    origin = request.headers.get('Origin')
    if not origin:
        return
    try:
        origin_host = urlparse(origin).netloc
    except ValueError:
        raise AuthHttpError(403, '這個請求並非來自允許的網站來源。')
    if not origin_host or origin_host != request.host:
        raise AuthHttpError(403, '這個請求並非來自允許的網站來源。')


def _read_json_body():
    if not (request.content_type or '').lower().startswith('application/json'):
        raise AuthHttpError(415, '這個端點只接受 JSON 請求。')
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        raise AuthHttpError(400, '請求內容不是有效的 JSON。')
    return body


def _fetch_jwks(url):
    now = _now_ms()
    with _lock:
        cached = _jwks_cache.get(url)
        if cached and cached['expires_at'] > now and cached['keys']:
            return cached['keys']
    resp = _requests.get(url, headers={'Accept': 'application/json'}, timeout=5)
    resp.raise_for_status()
    payload = resp.json()
    keys = payload.get('keys')
    if not isinstance(keys, list) or not keys:
        raise ValueError('JWKS response invalid')
    cache_ms = 60 * 60 * 1000
    match = re.search(r'(?:^|,)\s*max-age=(\d+)', resp.headers.get('Cache-Control', ''), re.I)
    if match:
        cache_ms = min(int(match.group(1)) * 1000, 6 * 60 * 60 * 1000)
    with _lock:
        _jwks_cache[url] = {'keys': keys, 'expires_at': now + max(1000, cache_ms)}
    return keys


def _verify_rs256(jwk, signing_input, signature):
    from cryptography.hazmat.primitives.asymmetric import padding as _padding, rsa
    from cryptography.hazmat.primitives import hashes
    from cryptography.exceptions import InvalidSignature
    try:
        n = int.from_bytes(_b64url_decode(jwk['n']), 'big')
        e = int.from_bytes(_b64url_decode(jwk['e']), 'big')
        public_key = rsa.RSAPublicNumbers(e, n).public_key()
        public_key.verify(signature, signing_input, _padding.PKCS1v15(), hashes.SHA256())
        return True
    except (InvalidSignature, ValueError, KeyError, TypeError):
        return False


def _decode_jwt_part(value, error):
    if (not isinstance(value, str) or not value
            or len(value) > 8192 or not re.match(r'^[A-Za-z0-9_-]+$', value)):
        raise error
    try:
        parsed = json.loads(_b64url_decode(value).decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        raise error
    if not isinstance(parsed, dict):
        raise error
    return parsed


def _verify_jwt_signature(token, jwks_url, error):
    """共用：解析 JWT、以 JWKS 驗證 RS256 簽章，回傳 payload。"""
    parts = token.split('.')
    if len(parts) != 3 or any(not p for p in parts):
        raise error
    encoded_header, encoded_payload, encoded_signature = parts
    header = _decode_jwt_part(encoded_header, error)
    payload = _decode_jwt_part(encoded_payload, error)
    if header.get('alg') != 'RS256' or not isinstance(header.get('kid'), str):
        raise error
    if not re.match(r'^[A-Za-z0-9_-]+$', encoded_signature):
        raise error
    try:
        signature = _b64url_decode(encoded_signature)
    except ValueError:
        raise error
    signing_input = ('%s.%s' % (encoded_header, encoded_payload)).encode('ascii')

    def _find_key(keys):
        for key in keys:
            if (isinstance(key, dict) and key.get('kid') == header['kid']
                    and key.get('kty') == 'RSA'
                    and key.get('use', 'sig') == 'sig'
                    and key.get('alg', 'RS256') == 'RS256'):
                return key
        return None

    try:
        keys = _fetch_jwks(jwks_url)
    except Exception:
        raise error
    jwk = _find_key(keys)
    valid = jwk is not None and _verify_rs256(jwk, signing_input, signature)
    if not valid:
        # 金鑰輪替：強制重新抓取一次
        with _lock:
            _jwks_cache.pop(jwks_url, None)
        try:
            keys = _fetch_jwks(jwks_url)
        except Exception:
            raise error
        jwk = _find_key(keys)
        valid = jwk is not None and _verify_rs256(jwk, signing_input, signature)
    if not valid:
        raise error
    return payload


# ---------------------------------------------------------------------------
# Google Sign-In 驗證
# ---------------------------------------------------------------------------

def _google_client_id():
    value = os.environ.get('GOOGLE_CLIENT_ID', '')
    return value if GOOGLE_CLIENT_ID_PATTERN.match(value) else ''


def _verify_google_credential(credential):
    error = AuthHttpError(401, 'Google 登入驗證失敗。')
    client_id = _google_client_id()
    if not client_id:
        raise AuthHttpError(503, 'Google 登入尚未設定。')
    if not isinstance(credential, str) or len(credential) < 100 or len(credential) > 8192:
        raise error
    payload = _verify_jwt_signature(credential, GOOGLE_CERTS_URL, error)

    now = int(time.time())
    aud = payload.get('aud')
    audiences = aud if isinstance(aud, list) else [aud]
    azp = payload.get('azp')
    exp = payload.get('exp')
    iat = payload.get('iat')
    if (client_id not in audiences
            or (azp and azp != client_id)
            or (len(audiences) != 1 and azp != client_id)
            or payload.get('iss') not in GOOGLE_ISSUERS
            or not isinstance(exp, int) or exp <= now or exp > now + 24 * 3600
            or not isinstance(iat, int) or iat > now + 300 or iat < now - 24 * 3600
            or exp <= iat or exp - iat > 24 * 3600
            or payload.get('email_verified') not in (True, 'true')
            or not isinstance(payload.get('sub'), str)
            or not 0 < len(payload['sub']) <= 255
            or not validate_email(payload.get('email') or '')):
        raise error

    email = normalize_email(payload['email'])
    supplied = normalize_name(payload['name']) if isinstance(payload.get('name'), str) else ''
    name = supplied if supplied and not validate_name(supplied) else email.split('@')[0]
    return {'id': 'google:%s' % payload['sub'], 'email': email,
            'name': name, 'provider': 'google'}


# ---------------------------------------------------------------------------
# AWS Cognito OAuth2 PKCE
# ---------------------------------------------------------------------------

_REGION_PATTERN = re.compile(r'^[a-z]{2}(?:-[a-z]+){1,2}-\d+$')
_CLIENT_ID_PATTERN = re.compile(r'^[a-z0-9]{10,128}$', re.I)


def _cognito_config():
    """驗證環境變數；不完整或無效 → None（優雅降級）。"""
    domain = os.environ.get('AWS_COGNITO_DOMAIN', '').strip()
    region = os.environ.get('AWS_COGNITO_REGION', '').strip().lower()
    user_pool_id = os.environ.get('AWS_COGNITO_USER_POOL_ID', '').strip()
    client_id = os.environ.get('AWS_COGNITO_CLIENT_ID', '').strip()
    client_secret = os.environ.get('AWS_COGNITO_CLIENT_SECRET', '').strip()
    callback_uri = os.environ.get('AWS_COGNITO_REDIRECT_URI', '').strip()
    if not (domain and region and user_pool_id and client_id and callback_uri):
        return None
    if not _REGION_PATTERN.match(region):
        return None
    if not user_pool_id.startswith(region + '_'):
        return None
    if not _CLIENT_ID_PATTERN.match(client_id):
        return None
    parsed_domain = urlparse(domain)
    if parsed_domain.scheme != 'https' or not parsed_domain.netloc \
            or parsed_domain.path not in ('', '/'):
        return None
    parsed_callback = urlparse(callback_uri)
    local_ok = parsed_callback.scheme == 'http' and \
        parsed_callback.hostname in ('localhost', '127.0.0.1', '::1')
    if not (parsed_callback.scheme == 'https' or local_ok):
        return None
    origin = '%s://%s' % (parsed_domain.scheme, parsed_domain.netloc)
    issuer = 'https://cognito-idp.%s.amazonaws.com/%s' % (region, user_pool_id)
    return {
        'domain': origin,
        'region': region,
        'user_pool_id': user_pool_id,
        'client_id': client_id,
        'client_secret': client_secret,
        'callback_uri': callback_uri,
        'issuer': issuer,
        'jwks_uri': issuer + '/.well-known/jwks.json',
        'authorization_endpoint': origin + '/oauth2/authorize',
        'token_endpoint': origin + '/oauth2/token',
    }


def _create_aws_flow():
    return {
        'state': _b64url_encode(secrets.token_bytes(32)),
        'nonce': _b64url_encode(secrets.token_bytes(32)),
        'code_verifier': _b64url_encode(secrets.token_bytes(64)),
    }


def _build_authorization_url(config, flow):
    challenge = _b64url_encode(hashlib.sha256(flow['code_verifier'].encode('ascii')).digest())
    params = urlencode({
        'response_type': 'code',
        'client_id': config['client_id'],
        'redirect_uri': config['callback_uri'],
        'scope': 'openid email profile',
        'state': flow['state'],
        'nonce': flow['nonce'],
        'code_challenge': challenge,
        'code_challenge_method': 'S256',
    })
    return '%s?%s' % (config['authorization_endpoint'], params)


def _exchange_aws_code(config, code, code_verifier):
    headers = {'Accept': 'application/json',
               'Content-Type': 'application/x-www-form-urlencoded'}
    if config['client_secret']:
        basic = base64.b64encode(
            ('%s:%s' % (config['client_id'], config['client_secret'])).encode('utf-8')
        ).decode('ascii')
        headers['Authorization'] = 'Basic ' + basic
    body = urlencode({
        'grant_type': 'authorization_code',
        'client_id': config['client_id'],
        'code': code,
        'redirect_uri': config['callback_uri'],
        'code_verifier': code_verifier,
    })
    resp = _requests.post(config['token_endpoint'], data=body, headers=headers, timeout=5)
    if resp.status_code != 200:
        raise ValueError('token exchange failed')
    payload = resp.json()
    id_token = payload.get('id_token')
    if not isinstance(id_token, str) or len(id_token) < 100 or len(id_token) > 16384:
        raise ValueError('token exchange failed')
    return id_token


def _verify_aws_id_token(config, id_token, nonce):
    error = AuthHttpError(401, 'AWS 登入驗證失敗。')
    if not isinstance(id_token, str) or len(id_token) < 100:
        raise error
    payload = _verify_jwt_signature(id_token, config['jwks_uri'], error)
    now = int(time.time())
    skew = 60
    exp = payload.get('exp')
    iat = payload.get('iat')
    valid_times = (isinstance(exp, int) and isinstance(iat, int)
                   and exp > now - skew and iat <= now + skew
                   and iat <= exp and exp - iat <= 24 * 3600 + skew)
    verified_email = payload.get('email_verified') in (True, 'true')
    if (not valid_times
            or payload.get('iss') != config['issuer']
            or payload.get('aud') != config['client_id']
            or payload.get('token_use') != 'id'
            or not isinstance(payload.get('nonce'), str)
            or not constant_time_equal(payload['nonce'], nonce)
            or not isinstance(payload.get('sub'), str)
            or not 0 < len(payload['sub']) <= 255
            or not verified_email
            or not validate_email(payload.get('email') or '')):
        raise error
    email = payload['email'].lower()
    name = ''
    if isinstance(payload.get('name'), str):
        name = normalize_name(payload['name'])[:80]
    if not name or validate_name(name):
        name = email.split('@')[0][:80]
    return {'id': 'aws:%s' % payload['sub'], 'email': email,
            'name': name, 'provider': 'aws'}


# ---------------------------------------------------------------------------
# 端點
# ---------------------------------------------------------------------------

@auth_bp.errorhandler(AuthHttpError)
def _handle_auth_error(error):
    payload = {'error': error.message}
    payload.update(error.extra)
    response = jsonify(payload)
    response.status_code = error.status
    if error.extra.get('retryAfter'):
        response.headers['Retry-After'] = str(error.extra['retryAfter'])
    return response


@auth_bp.route('/api/auth/config')
def auth_config():
    cognito = _cognito_config()
    google_id = _google_client_id()
    return jsonify({
        'awsEnabled': bool(cognito),
        'awsProviderName': 'AWS Cognito',
        'awsStartUrl': '/api/auth/aws/start' if cognito else None,
        'googleClientId': google_id or None,
        'googleEnabled': bool(google_id),
        'localEnabled': True,
    })


@auth_bp.route('/api/auth/session')
def auth_session():
    user = current_user()
    return jsonify({'user': _public_user(user) if user else None})


@auth_bp.route('/api/auth/register', methods=['POST'])
def auth_register():
    _require_trusted_origin()
    now = _now_ms()
    ip_key = 'register:%s' % _request_ip()
    with _lock:
        wait_ms = _remaining_for_keys(_register_attempts, [ip_key], now)
        if wait_ms > 0:
            retry_after = -(-wait_ms // 1000)
            raise AuthHttpError(429, '近期建立帳號的次數過多，請稍後再試。',
                                {'retryAfter': retry_after})
        _fail_keys(_register_attempts, [ip_key], now)

    body = _read_json_body()
    email = normalize_email(body.get('email')) if isinstance(body.get('email'), str) else ''
    name = normalize_name(body.get('name')) if isinstance(body.get('name'), str) else ''
    password = body.get('password') if isinstance(body.get('password'), str) else ''
    field_errors = {}
    if not validate_email(email):
        field_errors['email'] = ['請輸入有效的電子郵件地址。']
    name_errors = validate_name(name)
    if name_errors:
        field_errors['name'] = name_errors
    password_errors = validate_password(password)
    if password_errors:
        field_errors['password'] = password_errors
    if field_errors:
        raise AuthHttpError(400, '請修正標示的欄位後再試一次。', {'fieldErrors': field_errors})

    salt = random_salt()
    password_hash = derive_password_hash(password, salt)
    with _lock:
        if email in _accounts:
            raise AuthHttpError(409, '無法建立這個帳號。請改用登入，或換一個電子郵件。')
        account = {
            'id': str(uuid.uuid4()),
            'email': email,
            'name': name,
            'salt': salt,
            'passwordHash': password_hash,
            'iterations': PBKDF2_ITERATIONS,
            'createdAt': datetime.utcfromtimestamp(now / 1000).strftime('%Y-%m-%dT%H:%M:%S.000Z'),
        }
        _accounts[email] = account
        try:
            _persist_account_store()
        except Exception:
            del _accounts[email]
            raise AuthHttpError(503, '服務暫時無法使用，請稍後再試。')

    user = {'id': account['id'], 'email': email, 'name': name, 'provider': 'local'}
    response = jsonify({'user': _public_user(user)})
    response.status_code = 201
    _create_session(user, response)
    return response


@auth_bp.route('/api/auth/login', methods=['POST'])
def auth_login():
    _require_trusted_origin()
    body = _read_json_body()
    email = normalize_email(body.get('email')) if isinstance(body.get('email'), str) else ''
    raw_password = body.get('password')
    password = raw_password if isinstance(raw_password, str) and len(raw_password) <= 128 else ''
    keys = ['email:%s' % email, 'ip:%s' % _request_ip()]
    now = _now_ms()
    with _lock:
        wait_ms = _remaining_for_keys(_login_attempts, keys, now)
    if wait_ms > 0:
        retry_after = -(-wait_ms // 1000)
        raise AuthHttpError(429, '嘗試次數過多，請於 %d 秒後再試。' % retry_after,
                            {'retryAfter': retry_after})

    with _lock:
        account = _accounts.get(email)
    salt = account['salt'] if account else DUMMY_SALT
    iterations = account['iterations'] if account else PBKDF2_ITERATIONS
    candidate_hash = derive_password_hash(password, salt, iterations)
    expected = account['passwordHash'] if account else DUMMY_HASH
    matches = constant_time_equal(candidate_hash, expected)
    if not account or not validate_email(email) or not password or not matches:
        with _lock:
            _fail_keys(_login_attempts, keys, now)
        raise AuthHttpError(401, '帳號或密碼錯誤。')

    with _lock:
        for key in keys:
            _login_attempts.pop(key, None)
    user = {'id': account['id'], 'email': account['email'],
            'name': account['name'], 'provider': 'local'}
    response = jsonify({'user': _public_user(user)})
    _create_session(user, response)
    return response


@auth_bp.route('/api/auth/logout', methods=['POST'])
def auth_logout():
    _require_trusted_origin()
    active = get_active_session()
    if active:
        with _lock:
            _sessions.pop(active['token'], None)
    response = jsonify({'ok': True})
    _clear_session_cookie(response)
    return response


@auth_bp.route('/api/auth/google', methods=['POST'])
def auth_google():
    _require_trusted_origin()
    if not _google_client_id():
        raise AuthHttpError(503, 'Google 登入尚未設定。')
    now = _now_ms()
    key = 'google:%s' % _request_ip()
    with _lock:
        wait_ms = _remaining_for_keys(_google_attempts, [key], now)
    if wait_ms > 0:
        retry_after = -(-wait_ms // 1000)
        raise AuthHttpError(429, 'Google 登入嘗試次數過多，請稍後再試。',
                            {'retryAfter': retry_after})

    body = _read_json_body()
    try:
        user = _verify_google_credential(body.get('credential'))
    except AuthHttpError:
        with _lock:
            _fail_keys(_google_attempts, [key], now)
        raise AuthHttpError(401, 'Google 登入驗證失敗。')
    with _lock:
        _google_attempts.pop(key, None)
    response = jsonify({'user': _public_user(user)})
    _create_session(user, response)
    return response


@auth_bp.route('/api/auth/aws/start')
def auth_aws_start():
    config = _cognito_config()
    if not config:
        raise AuthHttpError(503, 'AWS 登入尚未設定。')
    now = _now_ms()
    with _lock:
        for token in [t for t, f in _aws_flows.items() if f['expires_at'] <= now]:
            del _aws_flows[token]
        if len(_aws_flows) >= MAX_AWS_FLOWS:
            raise AuthHttpError(503, 'AWS 登入暫時忙碌，請稍後再試。', {'retryAfter': 5})
        flow = _create_aws_flow()
        flow_token = secrets.token_urlsafe(32)
        _aws_flows[flow_token] = dict(flow, expires_at=now + AWS_FLOW_DURATION_MS)
    response = redirect(_build_authorization_url(config, flow))
    response.set_cookie(AWS_FLOW_COOKIE, flow_token,
                        max_age=AWS_FLOW_DURATION_MS // 1000,
                        httponly=True, samesite='Lax', path='/api/auth/aws/callback')
    return response


@auth_bp.route('/api/auth/aws/callback')
def auth_aws_callback():
    config = _cognito_config()
    if not config:
        raise AuthHttpError(503, 'AWS 登入尚未設定。')

    def _expire_flow_cookie(resp):
        resp.set_cookie(AWS_FLOW_COOKIE, '', max_age=0, httponly=True,
                        samesite='Lax', path='/api/auth/aws/callback')
        return resp

    try:
        flow_token = request.cookies.get(AWS_FLOW_COOKIE)
        with _lock:
            flow = _aws_flows.pop(flow_token, None) if flow_token else None
        received_state = request.args.get('state', '')
        code = request.args.get('code', '')
        if (not flow or flow['expires_at'] <= _now_ms()
                or len(received_state) > 512
                or not constant_time_equal(received_state, flow['state'])
                or 'error' in request.args or not code):
            raise ValueError('callback validation failed')
        id_token = _exchange_aws_code(config, code, flow['code_verifier'])
        user = _verify_aws_id_token(config, id_token, flow['nonce'])
        response = redirect('/?auth=aws-success')
        _create_session(user, response)
        return _expire_flow_cookie(response)
    except Exception:
        return _expire_flow_cookie(redirect('/login?auth=aws-error'))


# ---------------------------------------------------------------------------
# 初始化
# ---------------------------------------------------------------------------

def init_auth(app):
    global _accounts
    _accounts = _load_account_store()
    app.register_blueprint(auth_bp)

    @app.context_processor
    def _inject_auth_user():
        return {'auth_user': current_user()}

    print('[auth] 認證系統已載入（%d 個本地帳號；Cognito %s；Google %s）' % (
        len(_accounts),
        '已設定' if _cognito_config() else '未設定',
        '已設定' if _google_client_id() else '未設定',
    ), flush=True)
